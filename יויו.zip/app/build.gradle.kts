plugins { id("com.android.application") }

android {
    namespace = "il.yomanhasofer.goldnew"
    compileSdk = 35
    defaultConfig {
        applicationId = "il.yomanhasofer.goldnew"
        minSdk = 26
        targetSdk = 35
        versionCode = 136
        versionName = "12.6.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
