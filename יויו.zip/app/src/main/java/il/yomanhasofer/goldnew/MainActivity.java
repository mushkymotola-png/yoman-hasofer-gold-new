package il.yomanhasofer.goldnew;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;

public class MainActivity extends Activity {
  private GoldJournalView journalView;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    if(Build.VERSION.SDK_INT>=35) getWindow().setDecorFitsSystemWindows(true);
    getWindow().setStatusBarColor(0xFF0B2A43);
    getWindow().setNavigationBarColor(0xFFF8F1E5);
    journalView=new GoldJournalView(this);
    setContentView(journalView);
    requestNotificationPermissionIfNeeded();
  }

  private void requestNotificationPermissionIfNeeded(){
    if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2401);
    }
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==2301 && resultCode==RESULT_OK && data!=null && journalView!=null) journalView.importBackupUri(data.getData());
  }
}

