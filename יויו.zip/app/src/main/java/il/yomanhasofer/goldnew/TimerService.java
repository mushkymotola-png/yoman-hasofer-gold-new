package il.yomanhasofer.goldnew;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;

public class TimerService extends Service {
  public static final String CHANNEL="writing_timer";
  public static final String ACTION_START="il.yomanhasofer.goldnew.TIMER_START";
  public static final String ACTION_STOP="il.yomanhasofer.goldnew.TIMER_STOP";
  public static final String ACTION_PAUSE="il.yomanhasofer.goldnew.TIMER_PAUSE";
  public static final String ACTION_RESUME="il.yomanhasofer.goldnew.TIMER_RESUME";
  public static final String ACTION_OPEN="il.yomanhasofer.goldnew.TIMER_OPEN";
  private final Handler h=new Handler(Looper.getMainLooper());
  private boolean serviceActive=false;
  private ToneGenerator activeTone;
  private Vibrator activeVibrator;
  private final Runnable watch=new Runnable(){ public void run(){ if(check() && serviceActive) h.postDelayed(this,1000); } };
  @Override public void onCreate(){ super.onCreate(); createChannel(); }
  @Override public int onStartCommand(Intent i,int flags,int id){ String action=i==null?null:i.getAction(); if(i==null){ if(!restoreRunningTimer()){ stopSelf(); return START_NOT_STICKY; } action=ACTION_START; } if(ACTION_STOP.equals(action)){ stopTimerState(); stopForeground(true);stopSelf();return START_NOT_STICKY;} if(ACTION_PAUSE.equals(action)){ pauseTimer(); stopForeground(true);stopSelf();return START_NOT_STICKY;} if(ACTION_RESUME.equals(action)){ if(!resumeTimer()){stopForeground(true);stopSelf();return START_NOT_STICKY;} } if(ACTION_OPEN.equals(action)){ } serviceActive=true; startForeground(77,notification()); h.removeCallbacks(watch);h.post(watch);return START_STICKY; }
  private boolean restoreRunningTimer(){ android.content.SharedPreferences p=getSharedPreferences("gold_journal",MODE_PRIVATE); boolean running=p.getBoolean("timerRunning",false); long end=p.getLong("timerEndAt",0L); if(!running||end<=0)return false; if(System.currentTimeMillis()>=end){ p.edit().putBoolean("timerRunning",false).putLong("timerEndAt",0L).putLong("timerMs",0L).putBoolean("timerFinished",true).commit(); alarm(); return false; } return true; }
  private boolean check(){ android.content.SharedPreferences p=getSharedPreferences("gold_journal",MODE_PRIVATE); boolean running=p.getBoolean("timerRunning",false); long end=p.getLong("timerEndAt",0L); if(!running||end<=0){serviceActive=false;stopForeground(true);stopSelf();return false;} if(System.currentTimeMillis()>=end){p.edit().putBoolean("timerRunning",false).putLong("timerEndAt",0L).putLong("timerMs",0L).putBoolean("timerFinished",true).commit(); alarm(); serviceActive=false; stopForeground(true);stopSelf();return false;} NotificationManager nm=getSystemService(NotificationManager.class); if(nm!=null)nm.notify(77,notification()); return true; }
  private void stopTimerState(){ android.content.SharedPreferences p=getSharedPreferences("gold_journal",MODE_PRIVATE); p.edit().putBoolean("timerRunning",false).putLong("timerEndAt",0L).putLong("timerMs",0L).putBoolean("timerFinished",false).apply(); }
  private void pauseTimer(){ android.content.SharedPreferences p=getSharedPreferences("gold_journal",MODE_PRIVATE); long end=p.getLong("timerEndAt",0L); long left=Math.max(0,end-System.currentTimeMillis()); p.edit().putBoolean("timerRunning",false).putLong("timerEndAt",0L).putLong("timerMs",left).apply(); }
  private boolean resumeTimer(){ android.content.SharedPreferences p=getSharedPreferences("gold_journal",MODE_PRIVATE); long left=Math.max(0,p.getLong("timerMs",0L)); if(left<=0)return false; long end=System.currentTimeMillis()+left; p.edit().putBoolean("timerRunning",true).putLong("timerEndAt",end).putBoolean("timerFinished",false).apply(); return true; }
  private Notification notification(){ android.content.SharedPreferences p=getSharedPreferences("gold_journal",MODE_PRIVATE); boolean running=p.getBoolean("timerRunning",false); long left=running?Math.max(0,p.getLong("timerEndAt",0)-System.currentTimeMillis()):Math.max(0,p.getLong("timerMs",0L)); int phase=p.getInt("timerPhase",0); String name=phase==0?"כתיבה":(phase==2?"הפסקה ארוכה":"הפסקה"); String time=String.format(java.util.Locale.US,"%02d:%02d",left/60000,(left/1000)%60); Intent open=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); Intent pause=new Intent(this,TimerService.class); pause.setAction(ACTION_PAUSE); PendingIntent pausePi=PendingIntent.getService(this,1,pause,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); Intent resume=new Intent(this,TimerService.class); resume.setAction(ACTION_RESUME); PendingIntent resumePi=PendingIntent.getService(this,3,resume,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); Intent stop=new Intent(this,TimerService.class); stop.setAction(ACTION_STOP); PendingIntent stopPi=PendingIntent.getService(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); Notification.Builder b=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("יומן הסופר – "+name).setContentText(time+" נותרו").setContentIntent(pi).setOnlyAlertOnce(true); if(running){ b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,"השהה",pausePi).build()).setOngoing(true); } else if(p.getLong("timerMs",0L)>0 && !p.getBoolean("timerFinished",false)){ b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play,"המשך",resumePi).build()).setOngoing(false); } b.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"עצור",stopPi).build()); return b.build(); }
  private void createChannel(){ if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"טיימר כתיבה",NotificationManager.IMPORTANCE_LOW);c.setDescription("שמירת טיימר הכתיבה פעיל ברקע");NotificationManager nm=getSystemService(NotificationManager.class);if(nm!=null)nm.createNotificationChannel(c);} }
  private void alarm(){
    stopAlarm();
    try{
      activeTone=new ToneGenerator(AudioManager.STREAM_ALARM,100);
      activeTone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,10000);
      activeVibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE);
      if(activeVibrator!=null){
        long[] pattern=new long[]{0,500,180,500,180,900,180,500,180,500,180,900,180,500,180,500,180,900};
        if(Build.VERSION.SDK_INT>=26)activeVibrator.vibrate(VibrationEffect.createWaveform(pattern,-1)); else activeVibrator.vibrate(pattern,-1);
      }
      h.postDelayed(this::stopAlarm,10400);
    }catch(Exception ignored){ stopAlarm(); }
  }
  private void stopAlarm(){
    try{ if(activeTone!=null){activeTone.stopTone();activeTone.release();activeTone=null;} }catch(Exception ignored){}
    try{ if(activeVibrator!=null){activeVibrator.cancel();activeVibrator=null;} }catch(Exception ignored){}
  }
  @Override public android.os.IBinder onBind(Intent i){return null;}
  @Override public void onDestroy(){serviceActive=false;h.removeCallbacks(watch);stopAlarm();super.onDestroy();}
}
