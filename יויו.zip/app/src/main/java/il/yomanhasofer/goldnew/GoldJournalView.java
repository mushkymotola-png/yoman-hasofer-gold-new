package il.yomanhasofer.goldnew;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import java.io.*;
import java.nio.charset.StandardCharsets;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.content.SharedPreferences;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.text.InputType;
import java.util.*;

public class GoldJournalView extends View {
  private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final int NAVY=Color.rgb(10,35,57), CREAM=Color.rgb(247,241,230), GOLD=Color.rgb(171,132,72), INK=Color.rgb(27,42,54), WHITE=Color.rgb(255,253,248);
  private int tab=0; // bottom navigation
  private int screen=0; // 0 calendar,1 day,2 orders,3 data,4 more,5 timer,6 update,7 order detail,8 settings,9 summary,10 weekly,11 notebook
  private long timerMs=40*60*1000L; private boolean running=false; private long lastTick; private long timerEndAt=0L; private int timerPhase=0; // 0 work, 1 break, 2 long break
  private boolean timerFinished=false;
  private int actualLines=9; private int startMinutes=600, cycleMinutes=40, breakMinutes=20, longBreakMinutes=60, cycleCount=6; private int actualStartMinutes=-1; private boolean adaptive=true; private String workDate=""; private final SharedPreferences prefs;
  private int currentCycle=0; private int dailyTarget=42; private boolean dayFinished=false; private boolean updateAfterTimedCycle=false; private boolean dayReadyToClose=false; private final int[] cycleLines=new int[6]; private final boolean[] cycleDone=new boolean[6];
  private int calendarOffset=0, selectedCalendarDay=-1; private int activeOrder=0, orderCount=3; private int orderEditField=0; private int ordersPage=0;
  private String[] orderNames={"תפילין – משפחת כהן","מזוזה – משפחת לוי","מגילה – בית הכנסת","","","","",""};
  private String[] orderDues={"כ״ה בחשוון תשפ״ז","י״ח בכסלו תשפ״ז","י׳ בטבת תשפ״ז","","","","",""};
  private String[] orderTypes={"תפילין","מזוזות","מגילה","תפילין","תפילין","תפילין","תפילין","תפילין"};
  private String[] orderCustomers={"משפחת כהן","משפחת לוי","בית הכנסת","","","","",""};
  private final long[] orderDueEpochs=new long[8];
  private final long[] orderStartEpochs=new long[8];
  private final int[] orderExpectedProfits=new int[8];
  private int[] orderTargets={100,21,42,0,0,0,0,0}, orderActualUnits={75,21,17,0,0,0,0,0};
  private int[] orderProgresses={75,100,40,0,0,0,0,0}, orderPrices={4200,900,2600,0,0,0,0,0}, orderPaids={2000,900,800,0,0,0,0,0}; private final long[] orderPaidEpochs=new long[8]; private String orderName="תפילין – משפחת כהן", orderDue="כ״ה בחשוון תשפ״ז"; private int orderProgress=75, orderPrice=4200, orderPaid=2000; private int monthlyExpenses=850; private final String[] expenseNames={"קלף וחומרי כתיבה","הגהה ותיקונים","ציוד וכלים","הוצאות נוספות","","","",""}; private final int[] expenseAmounts={350,200,150,150,0,0,0,0}; private final boolean[] expensePaid={true,false,false,false,false,false,false,false}; private final boolean[] expenseRecurring={true,true,false,false,false,false,false,false}; private final long[] expenseDateEpoch=new long[8]; private int expenseCount=4, expensePage=0; private int notebookNotes=4, proofreadingOpen=2, proofreadingDone=0; private final String[] weeklyPlans={"תפילין – ראש רש״י","תפילין – ראש ר״ת","מזוזות – כהן","מגילה – בית הכנסת","תפילין – יד רש״י","יום חופשי"}; private final int[] weeklyCycles={6,6,6,6,6,0}; private int notebookCount=4; private int notebookPage=0, proofreadingPage=0, weeklyOffset=0, financeMonthOffset=0, reportMonthOffset=0; private final String[] notebookTexts={"מקום כתיבה – פרשת שמע","תיקון לבדיקה בהגהה","רעיון לסדר עבודה חדש","הערה להזמנת משפחת כהן","","","",""}; private final String[] notebookPlaces={"פרשת שמע","","","","","","",""}; private final int[] notebookOrderIndex={0,-1,-1,0,-1,-1,-1,-1}; private final long[] notebookDateEpoch=new long[8]; private int proofreadingCount=2; private final String[] proofreadingNames={"תפילין – בדיקת פרשה","מזוזה – תיקון אות","","","","","",""}; private final boolean[] proofreadingCompleted=new boolean[8]; private final int[] proofreadingOrderIndex={0,1,-1,-1,-1,-1,-1,-1}; private final long[] proofreadingDateEpoch=new long[8]; private final String[] proofreadingNotes={"","","","","","","",""}; private int goalYears=1, goalTarget=1000, goalDone=0, goalRecalcMode=0, goalDailyPace=4; private long goalDueEpoch=0L, goalStartEpoch=0L; private long vacationStartEpoch=0L, vacationEndEpoch=0L; private boolean vacationEnabled=false; private final long[] extraVacationStartEpoch=new long[2], extraVacationEndEpoch=new long[2]; private final boolean[] extraVacationEnabled=new boolean[2]; private boolean backupExists=false; private static final int HISTORY_MAX=6000; private int historyCount=0; private final String[] historyDates=new String[HISTORY_MAX]; private final int[] historyLines=new int[HISTORY_MAX], historyCycles=new int[HISTORY_MAX], historyMinutes=new int[HISTORY_MAX];
  private final Handler h=new Handler(Looper.getMainLooper());
  private final Runnable tick=new Runnable(){ public void run(){
    syncTimerFromPrefs();
    if(!running){ invalidate(); return; }
    long n=System.currentTimeMillis(); timerMs=Math.max(0,timerEndAt-n); lastTick=n;
    if(timerMs<=0){
      // TimerService owns authoritative completion + alarm. Do not clear persisted state here.
      running=false; timerMs=0; timerFinished=true; invalidate(); h.postDelayed(syncTimerUi,900);
    } else { invalidate(); h.postDelayed(this,250); }
  } };
  private final Runnable syncTimerUi=new Runnable(){ public void run(){ syncTimerFromPrefs(); invalidate(); if(running)h.post(tick); } };
  public GoldJournalView(Context c){ super(c); setLayoutDirection(LAYOUT_DIRECTION_RTL); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); setBackgroundColor(CREAM); prefs=c.getSharedPreferences("gold_journal",Context.MODE_PRIVATE); actualLines=prefs.getInt("actualLines",9); timerMs=prefs.getLong("timerMs",40*60*1000L); startMinutes=prefs.getInt("startMinutes",600); cycleMinutes=prefs.getInt("cycleMinutes",40); breakMinutes=prefs.getInt("breakMinutes",20); longBreakMinutes=prefs.getInt("longBreakMinutes",60); cycleCount=6; adaptive=prefs.getBoolean("adaptive",true); actualStartMinutes=prefs.getInt("actualStartMinutes",-1); workDate=prefs.getString("workDate",""); currentCycle=prefs.getInt("currentCycle",0); dailyTarget=prefs.getInt("dailyTarget",42); dayFinished=prefs.getBoolean("dayFinished",false); dayReadyToClose=prefs.getBoolean("dayReadyToClose",false); orderName=prefs.getString("orderName",orderName); orderDue=prefs.getString("orderDue",orderDue); orderProgress=prefs.getInt("orderProgress",75); orderPrice=prefs.getInt("orderPrice",4200); orderPaid=prefs.getInt("orderPaid",2000); orderCount=Math.max(1,Math.min(8,prefs.getInt("orderCount",3))); activeOrder=Math.max(0,Math.min(orderCount-1,prefs.getInt("activeOrder",0))); for(int oi=0;oi<8;oi++){orderNames[oi]=prefs.getString("orderName"+oi,oi==0?orderName:orderNames[oi]); orderDues[oi]=prefs.getString("orderDue"+oi,orderDues[oi]); orderProgresses[oi]=prefs.getInt("orderProgress"+oi,oi==0?orderProgress:orderProgresses[oi]); orderPrices[oi]=prefs.getInt("orderPrice"+oi,oi==0?orderPrice:orderPrices[oi]); orderPaids[oi]=prefs.getInt("orderPaid"+oi,oi==0?orderPaid:orderPaids[oi]); orderPaidEpochs[oi]=prefs.getLong("orderPaidEpoch"+oi,0L); orderTypes[oi]=prefs.getString("orderType"+oi,orderTypes[oi]); orderCustomers[oi]=prefs.getString("orderCustomer"+oi,orderCustomers[oi]); orderDueEpochs[oi]=prefs.getLong("orderDueEpoch"+oi,0L); orderStartEpochs[oi]=prefs.getLong("orderStartEpoch"+oi,0L); orderExpectedProfits[oi]=prefs.getInt("orderExpectedProfit"+oi,0); orderTargets[oi]=prefs.getInt("orderTarget"+oi,orderTargets[oi]); orderActualUnits[oi]=prefs.getInt("orderActualUnits"+oi,orderActualUnits[oi]); if(orderTargets[oi]>0) orderProgresses[oi]=Math.min(100,Math.round(orderActualUnits[oi]*100f/orderTargets[oi]));} syncActiveOrder(); monthlyExpenses=prefs.getInt("monthlyExpenses",850); expenseCount=Math.max(0,Math.min(8,prefs.getInt("expenseCount",4))); for(int ei=0;ei<8;ei++){expenseAmounts[ei]=prefs.getInt("expenseAmount"+ei,expenseAmounts[ei]); expenseNames[ei]=prefs.getString("expenseName"+ei,expenseNames[ei]); expensePaid[ei]=prefs.getBoolean("expensePaid"+ei,expensePaid[ei]); expenseRecurring[ei]=prefs.getBoolean("expenseRecurring"+ei,expenseRecurring[ei]); expenseDateEpoch[ei]=prefs.getLong("expenseDateEpoch"+ei,0L);} recalcMonthlyExpenses(); notebookNotes=prefs.getInt("notebookNotes",4); notebookCount=Math.max(0,Math.min(8,prefs.getInt("notebookCount",notebookNotes))); for(int ni=0;ni<8;ni++){ notebookTexts[ni]=prefs.getString("notebookText"+ni,notebookTexts[ni]); notebookPlaces[ni]=prefs.getString("notebookPlace"+ni,notebookPlaces[ni]); notebookOrderIndex[ni]=prefs.getInt("notebookOrderIndex"+ni,notebookOrderIndex[ni]); notebookDateEpoch[ni]=prefs.getLong("notebookDateEpoch"+ni,0L); if(notebookOrderIndex[ni]<-1||notebookOrderIndex[ni]>=orderCount)notebookOrderIndex[ni]=-1; } notebookNotes=notebookCount; for(int wi=0;wi<6;wi++){weeklyPlans[wi]=prefs.getString("weeklyPlan"+wi,weeklyPlans[wi]);weeklyCycles[wi]=Math.max(0,Math.min(6,prefs.getInt("weeklyCycles"+wi,weeklyCycles[wi])));}  proofreadingOpen=prefs.getInt("proofreadingOpen",2); proofreadingDone=prefs.getInt("proofreadingDone",0); proofreadingCount=Math.max(0,Math.min(8,prefs.getInt("proofreadingCount",2))); for(int pi=0;pi<8;pi++){proofreadingNames[pi]=prefs.getString("proofreadingName"+pi,proofreadingNames[pi]);proofreadingCompleted[pi]=prefs.getBoolean("proofreadingCompleted"+pi,false);proofreadingOrderIndex[pi]=prefs.getInt("proofreadingOrderIndex"+pi,proofreadingOrderIndex[pi]);proofreadingDateEpoch[pi]=prefs.getLong("proofreadingDateEpoch"+pi,0L);proofreadingNotes[pi]=prefs.getString("proofreadingNotes"+pi,""); if(proofreadingOrderIndex[pi]<-1||proofreadingOrderIndex[pi]>=orderCount)proofreadingOrderIndex[pi]=-1;} recalcProofreading(); goalYears=prefs.getInt("goalYears",1); goalTarget=prefs.getInt("goalTarget",1000); goalDone=prefs.getInt("goalDone",0); goalRecalcMode=prefs.getInt("goalRecalcMode",0); goalDailyPace=prefs.getInt("goalDailyPace",4); goalDueEpoch=prefs.getLong("goalDueEpoch",0L); goalStartEpoch=prefs.getLong("goalStartEpoch",0L); if(goalStartEpoch<=0)goalStartEpoch=startOfTodayEpoch(); vacationStartEpoch=prefs.getLong("vacationStartEpoch",0L); vacationEndEpoch=prefs.getLong("vacationEndEpoch",0L); vacationEnabled=prefs.getBoolean("vacationEnabled",false); for(int vi=0;vi<2;vi++){extraVacationStartEpoch[vi]=prefs.getLong("extraVacationStartEpoch"+vi,0L);extraVacationEndEpoch[vi]=prefs.getLong("extraVacationEndEpoch"+vi,0L);extraVacationEnabled[vi]=prefs.getBoolean("extraVacationEnabled"+vi,false);} if(goalDueEpoch<=0){Calendar gd=Calendar.getInstance();gd.add(Calendar.YEAR,goalYears);goalDueEpoch=gd.getTimeInMillis();} backupExists=prefs.getBoolean("backupExists",false); running=prefs.getBoolean("timerRunning",false); timerEndAt=prefs.getLong("timerEndAt",0L); timerPhase=prefs.getInt("timerPhase",0); timerFinished=prefs.getBoolean("timerFinished",false); if(running&&timerEndAt>0){
    timerMs=Math.max(0,timerEndAt-System.currentTimeMillis());
    if(timerMs==0){
      // Keep the persisted running/end state intact so TimerService can authoritatively finalize + alert.
      running=false;
      startTimerService();
      h.postDelayed(syncTimerUi,900);
    }
  }
  if(running){h.removeCallbacks(tick);h.post(tick);startTimerService();} for(int i=0;i<6;i++){cycleLines[i]=prefs.getInt("cycleLines"+i,0);cycleDone[i]=prefs.getBoolean("cycleDone"+i,false);} historyCount=Math.max(0,Math.min(HISTORY_MAX,prefs.getInt("historyCount",0))); for(int hi=0;hi<historyCount;hi++){historyDates[hi]=prefs.getString("historyDate"+hi,"");historyLines[hi]=prefs.getInt("historyLines"+hi,0);historyCycles[hi]=prefs.getInt("historyCycles"+hi,0);historyMinutes[hi]=prefs.getInt("historyMinutes"+hi,0);} ensureCurrentDay(); }
  void saveState(){ SharedPreferences.Editor e=prefs.edit().putInt("actualLines",actualLines).putLong("timerMs",timerMs).putInt("startMinutes",startMinutes).putInt("cycleMinutes",cycleMinutes).putInt("breakMinutes",breakMinutes).putInt("longBreakMinutes",longBreakMinutes).putInt("cycleCount",cycleCount).putBoolean("adaptive",adaptive).putInt("actualStartMinutes",actualStartMinutes).putString("workDate",workDate).putInt("currentCycle",currentCycle).putInt("dailyTarget",dailyTarget).putBoolean("dayFinished",dayFinished).putBoolean("dayReadyToClose",dayReadyToClose).putString("orderName",orderName).putString("orderDue",orderDue).putInt("orderProgress",orderProgress).putInt("orderPrice",orderPrice).putInt("orderPaid",orderPaid).putInt("monthlyExpenses",monthlyExpenses).putInt("notebookNotes",notebookNotes).putInt("proofreadingOpen",proofreadingOpen).putInt("proofreadingDone",proofreadingDone).putInt("goalYears",goalYears).putInt("goalTarget",goalTarget).putInt("goalDone",goalDone).putInt("goalRecalcMode",goalRecalcMode).putInt("goalDailyPace",goalDailyPace).putLong("goalDueEpoch",goalDueEpoch).putLong("goalStartEpoch",goalStartEpoch).putLong("vacationStartEpoch",vacationStartEpoch).putLong("vacationEndEpoch",vacationEndEpoch).putBoolean("vacationEnabled",vacationEnabled).putBoolean("backupExists",backupExists).putBoolean("timerRunning",running).putLong("timerEndAt",timerEndAt).putInt("timerPhase",timerPhase).putBoolean("timerFinished",timerFinished); e.putInt("activeOrder",activeOrder).putInt("orderCount",orderCount).putInt("notebookCount",notebookCount).putInt("proofreadingCount",proofreadingCount).putInt("expenseCount",expenseCount); for(int ni=0;ni<8;ni++)e.putString("notebookText"+ni,notebookTexts[ni]).putString("notebookPlace"+ni,notebookPlaces[ni]).putInt("notebookOrderIndex"+ni,notebookOrderIndex[ni]).putLong("notebookDateEpoch"+ni,notebookDateEpoch[ni]); for(int wi=0;wi<6;wi++)e.putString("weeklyPlan"+wi,weeklyPlans[wi]).putInt("weeklyCycles"+wi,weeklyCycles[wi]); for(int pi=0;pi<8;pi++){e.putString("proofreadingName"+pi,proofreadingNames[pi]).putBoolean("proofreadingCompleted"+pi,proofreadingCompleted[pi]).putInt("proofreadingOrderIndex"+pi,proofreadingOrderIndex[pi]).putLong("proofreadingDateEpoch"+pi,proofreadingDateEpoch[pi]).putString("proofreadingNotes"+pi,proofreadingNotes[pi]);} for(int ei=0;ei<8;ei++){e.putString("expenseName"+ei,expenseNames[ei]).putInt("expenseAmount"+ei,expenseAmounts[ei]).putBoolean("expensePaid"+ei,expensePaid[ei]).putBoolean("expenseRecurring"+ei,expenseRecurring[ei]).putLong("expenseDateEpoch"+ei,expenseDateEpoch[ei]);} for(int oi=0;oi<8;oi++){e.putString("orderName"+oi,orderNames[oi]).putString("orderDue"+oi,orderDues[oi]).putInt("orderProgress"+oi,orderProgresses[oi]).putInt("orderPrice"+oi,orderPrices[oi]).putInt("orderPaid"+oi,orderPaids[oi]).putLong("orderPaidEpoch"+oi,orderPaidEpochs[oi]).putString("orderType"+oi,orderTypes[oi]).putString("orderCustomer"+oi,orderCustomers[oi]).putLong("orderDueEpoch"+oi,orderDueEpochs[oi]).putLong("orderStartEpoch"+oi,orderStartEpochs[oi]).putInt("orderExpectedProfit"+oi,orderExpectedProfits[oi]).putInt("orderTarget"+oi,orderTargets[oi]).putInt("orderActualUnits"+oi,orderActualUnits[oi]);} for(int vi=0;vi<2;vi++)e.putLong("extraVacationStartEpoch"+vi,extraVacationStartEpoch[vi]).putLong("extraVacationEndEpoch"+vi,extraVacationEndEpoch[vi]).putBoolean("extraVacationEnabled"+vi,extraVacationEnabled[vi]); for(int i=0;i<6;i++){e.putInt("cycleLines"+i,cycleLines[i]).putBoolean("cycleDone"+i,cycleDone[i]);} e.putInt("historyCount",historyCount); for(int hi=0;hi<historyCount;hi++)e.putString("historyDate"+hi,historyDates[hi]==null?"":historyDates[hi]).putInt("historyLines"+hi,historyLines[hi]).putInt("historyCycles"+hi,historyCycles[hi]).putInt("historyMinutes"+hi,historyMinutes[hi]); e.apply(); }
  String hm(int m){m=(m%(24*60)+24*60)%(24*60);return String.format(java.util.Locale.US,"%02d:%02d",m/60,m%60);}
  String durationHm(int m){m=Math.max(0,m);return String.format(java.util.Locale.US,"%02d:%02d",m/60,m%60);}
  int plannedEnd(){int total=cycleCount*cycleMinutes; if(cycleCount>1) total+=(cycleCount-2)*breakMinutes+longBreakMinutes; return startMinutes+total;}

  String todayKey(){ Calendar c=Calendar.getInstance(); return String.format(java.util.Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH)); }
  void ensureCurrentDay(){ String t=todayKey(); if(workDate.length()==0){workDate=t; saveState(); return;} if(!workDate.equals(t)){ if(!dayFinished && hasMeaningfulDayActivity()) recordDayHistory(); newDay(); workDate=t; saveState(); } }
  boolean hasMeaningfulDayActivity(){ return totalLines()>0 || completedCycles()>0 || actualStartMinutes>=0; }
  int effectiveStart(){ return (adaptive && actualStartMinutes>=0)?actualStartMinutes:startMinutes; }
  int[] cycleStarts(){ int[] a=new int[cycleCount]; int m=effectiveStart(); for(int i=0;i<cycleCount;i++){a[i]=m; m+=cycleMinutes; if(i<cycleCount-1) m+=(i==3?longBreakMinutes:breakMinutes);} return a; }
  void startTodayNow(){ ensureCurrentDay(); Calendar now=Calendar.getInstance(); workDate=todayKey(); actualStartMinutes=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE); dayFinished=false; saveState(); }
  int totalLines(){int total=0;for(int v:cycleLines)total+=v;return total;}
  int completedCycles(){int d=0;for(boolean v:cycleDone)if(v)d++;return d;}
  int nextOpenCycle(){for(int i=0;i<Math.min(cycleCount,6);i++)if(!cycleDone[i])return i;return Math.max(0,Math.min(cycleCount,6)-1);}
  void recordDayHistory(){ String d=workDate.length()==0?todayKey():workDate; for(int i=0;i<historyCount;i++)if(d.equals(historyDates[i])){historyLines[i]=totalLines();historyCycles[i]=completedCycles();historyMinutes[i]=completedCycles()*cycleMinutes;return;} if(historyCount>=HISTORY_MAX){for(int i=0;i<HISTORY_MAX-1;i++){historyDates[i]=historyDates[i+1];historyLines[i]=historyLines[i+1];historyCycles[i]=historyCycles[i+1];historyMinutes[i]=historyMinutes[i+1];}historyCount=HISTORY_MAX-1;} historyDates[historyCount]=d;historyLines[historyCount]=totalLines();historyCycles[historyCount]=completedCycles();historyMinutes[historyCount]=completedCycles()*cycleMinutes;historyCount++; }
  int historicalLines(){int n=0;for(int i=0;i<historyCount;i++)n+=Math.max(0,historyLines[i]);return n;}
  int historicalMinutes(){int n=0;for(int i=0;i<historyCount;i++)n+=Math.max(0,historyMinutes[i]);return n;}
  boolean historyHasDate(String d){for(int i=0;i<historyCount;i++)if(d.equals(historyDates[i]))return true;return false;}
  int cumulativeLines(){return historicalLines()+(historyHasDate(workDate)?0:totalLines());}
  long startOfTodayEpoch(){ Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis(); }
  long historyDateEpoch(String d){ try{String[] a=d.split("-");Calendar c=Calendar.getInstance();c.clear();c.set(Integer.parseInt(a[0]),Integer.parseInt(a[1])-1,Integer.parseInt(a[2]),12,0,0);return c.getTimeInMillis();}catch(Exception e){return 0L;} }
  int goalProgressLines(){ int n=0; long start=goalStartEpoch<=0?0:goalStartEpoch; for(int i=0;i<historyCount;i++){long he=historyDateEpoch(historyDates[i]);if(he>=start)n+=Math.max(0,historyLines[i]);} long we=historyDateEpoch(workDate); if(!historyHasDate(workDate)&&we>=start)n+=Math.max(0,totalLines()); return n; }
  String goalStartText(){ Calendar c=Calendar.getInstance(); c.setTimeInMillis(goalStartEpoch); return String.format(Locale.US,"%02d/%02d/%04d",c.get(Calendar.DAY_OF_MONTH),c.get(Calendar.MONTH)+1,c.get(Calendar.YEAR)); }
  int goalWorkDaysBetween(long startEpoch,long endEpoch){ Calendar c=Calendar.getInstance();c.setTimeInMillis(startEpoch);c.set(Calendar.HOUR_OF_DAY,12);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0); Calendar end=Calendar.getInstance();end.setTimeInMillis(endEpoch);end.set(Calendar.HOUR_OF_DAY,12);end.set(Calendar.MINUTE,0);end.set(Calendar.SECOND,0);end.set(Calendar.MILLISECOND,0); int n=0; while(!c.after(end)&&n<7500){if(writingWorkDay(c))n++;c.add(Calendar.DAY_OF_MONTH,1);} return Math.max(1,n); }
  int historicalCycles(){int n=0;for(int i=0;i<historyCount;i++)n+=Math.max(0,historyCycles[i]);return n;}
  int averageDailyLines(){return historyCount==0?0:Math.round(historicalLines()/(float)historyCount);}
  int bestDayIndex(){int best=-1;for(int i=0;i<historyCount;i++)if(best<0||historyLines[i]>historyLines[best])best=i;return best;}
  String shortHistoryDate(String d){if(d==null)return "";String[] a=d.split("-");return a.length==3?a[2]+"/"+a[1]:d;}
  void finishDay(){ if(dayFinished)return; if(completedCycles()<6){ Toast.makeText(getContext(),"יש להשלים את ששת המחזורים לפני סגירת היום",Toast.LENGTH_SHORT).show(); return; } if(!dayReadyToClose){ Toast.makeText(getContext(),"סיכום היום עדיין לא מוכן לסגירה",Toast.LENGTH_SHORT).show(); return; } recordDayHistory(); dayFinished=true; dayReadyToClose=false; goalDone=goalProgressLines(); running=false; timerEndAt=0L; h.removeCallbacks(tick); stopTimerService(); timerMs=cycleMinutes*60*1000L; timerPhase=0; timerFinished=false; saveState(); }
  void newDay(){ workDate=todayKey(); dayFinished=false; dayReadyToClose=false; actualStartMinutes=-1; currentCycle=0; running=false; timerEndAt=0L; h.removeCallbacks(tick); stopTimerService(); timerMs=cycleMinutes*60*1000L; timerPhase=0; timerFinished=false; actualLines=0; for(int i=0;i<6;i++){cycleLines[i]=0;cycleDone[i]=false;} saveState(); }
  String phaseName(){ return timerPhase==0?"כתיבה":(timerPhase==2?"הפסקה ארוכה":"הפסקה"); }
  void syncTimerFromPrefs(){
    boolean pr=prefs.getBoolean("timerRunning",false);
    long pe=prefs.getLong("timerEndAt",0L);
    boolean pf=prefs.getBoolean("timerFinished",false);
    if(pr && pe>0L){ running=true; timerEndAt=pe; timerFinished=false; timerMs=Math.max(0L,pe-System.currentTimeMillis()); }
    else { running=false; timerEndAt=0L; timerFinished=pf; timerMs=Math.max(0L,prefs.getLong("timerMs",timerMs)); }
  }
  long phaseDurationMs(){ if(timerPhase==0)return cycleMinutes*60*1000L; return (timerPhase==2?longBreakMinutes:breakMinutes)*60*1000L; }
  void prepareBreak(){
    // The long break comes only after completing cycle 4 (zero-based index 3).
    timerPhase=(currentCycle==3)?2:1;
    timerMs=phaseDurationMs(); timerFinished=false; running=false; timerEndAt=0L;
    saveState(); invalidate();
  }
  void prepareNextWork(){
    // A finished break advances exactly one cycle; cycle count remains fixed at six.
    if(currentCycle<5) currentCycle++;
    timerPhase=0; timerMs=cycleMinutes*60*1000L; timerFinished=false; running=false; timerEndAt=0L;
    saveState(); invalidate();
  }
  int breakMinutesAfterCycle(int cycleIndex){ return cycleIndex==3?longBreakMinutes:breakMinutes; }
  void startTimerService(){ try{ Intent i=new Intent(getContext(),TimerService.class); i.setAction(TimerService.ACTION_START); if(Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i); else getContext().startService(i); }catch(Exception ignored){} }
  void stopTimerService(){ try{ getContext().stopService(new Intent(getContext(),TimerService.class)); }catch(Exception ignored){} }

  // v8.0: one logical phone coordinate system. The approved reference is phone-proportioned;
  // scaling from a 412dp-wide artboard prevents the S23 Ultra pixel resolution from stretching the UI.
  float designScale(){ return Math.max(1f,getWidth()/412f); }
  float W(){ return getWidth()/designScale(); }
  float H(){ return getHeight()/designScale(); }
  float headerH(){ return 118f; }
  float bottomH(){ return 64f; }
  float contentTop(){ return headerH()+10f; }
  float contentBottom(){ return H()-bottomH()-10f; }
  float bodyWidth(){ return W()-36f; }
  float bodyLeft(){ return 18f; }
  float bodyRight(){ return W()-18f; }
  void line(Canvas c,float x1,float y1,float x2,float y2,int color,float sw){p.setColor(color);p.setStrokeWidth(sw);p.setStyle(Paint.Style.STROKE);c.drawLine(x1,y1,x2,y2,p);p.setStyle(Paint.Style.FILL);}

  void fill(Canvas c,int color){c.drawColor(color);} void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align a,boolean bold){p.setColor(color);p.setTextSize(size);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
  void displayText(Canvas c,String s,float x,float y,float size,int color,Paint.Align a,boolean bold){p.setColor(color);p.setTextSize(size);p.setTextAlign(a);p.setTypeface(Typeface.create("serif",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
  void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);p.setStyle(Paint.Style.FILL);}
  void stroke(Canvas c,float l,float t,float r,float b,float rad,int color,float sw){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sw);c.drawRoundRect(l,t,r,b,rad,rad,p);p.setStyle(Paint.Style.FILL);}
  void syncActiveOrder(){ activeOrder=Math.max(0,Math.min(orderCount-1,activeOrder)); orderName=orderNames[activeOrder]; orderDue=orderDues[activeOrder]; orderProgress=orderProgresses[activeOrder]; orderPrice=orderPrices[activeOrder]; orderPaid=orderPaids[activeOrder]; }
  void syncActiveOrderBack(){ orderNames[activeOrder]=orderName; orderDues[activeOrder]=orderDue; orderProgresses[activeOrder]=orderProgress; orderPrices[activeOrder]=orderPrice; orderPaids[activeOrder]=orderPaid; }
  @Override public void onWindowFocusChanged(boolean hasWindowFocus){
    super.onWindowFocusChanged(hasWindowFocus);
    if(hasWindowFocus){
      ensureCurrentDay();
      h.removeCallbacks(tick);
      h.removeCallbacks(syncTimerUi);
      syncTimerFromPrefs();
      if(running) h.post(tick);
      invalidate();
    }
  }
  @Override protected void onAttachedToWindow(){
    super.onAttachedToWindow();
    ensureCurrentDay();
    h.removeCallbacks(tick);
    h.removeCallbacks(syncTimerUi);
    syncTimerFromPrefs();
    if(running) h.post(tick);
  }
  @Override protected void onDetachedFromWindow(){
    h.removeCallbacks(tick);
    h.removeCallbacks(syncTimerUi);
    super.onDetachedFromWindow();
  }
  @Override protected void onDraw(Canvas c){ super.onDraw(c); c.save(); c.scale(designScale(),designScale()); fill(c,CREAM); float header=headerH(), bottom=bottomH(); header(c,header); bottom(c,bottom); float top=header+10, bot=H()-bottom-10; if(screen==0)home(c,top,bot); else if(screen==1)day(c,top,bot); else if(screen==2)orders(c,top,bot); else if(screen==3)data(c,top,bot); else if(screen==4)more(c,top,bot); else if(screen==5)timer(c,top,bot); else if(screen==6)update(c,top,bot); else if(screen==7)orderDetail(c,top,bot); else if(screen==8)settings(c,top,bot); else if(screen==9)summary(c,top,bot); else if(screen==10)weekly(c,top,bot); else if(screen==11) notebook(c,top,bot); else if(screen==12) finance(c,top,bot); else if(screen==13) proofreading(c,top,bot); else if(screen==14) goals(c,top,bot); else if(screen==15) backup(c,top,bot); else if(screen==16) vacations(c,top,bot); else monthlyReport(c,top,bot); c.restore(); }
  void header(Canvas c,float h){
    // Deep navy masthead with the restrained curved gold edge used by the approved design.
    Path hp=new Path(); hp.moveTo(0,0); hp.lineTo(W(),0); hp.lineTo(W(),h-10); hp.quadTo(W()/2,h+12,0,h-10); hp.close(); p.setColor(NAVY);p.setStyle(Paint.Style.FILL);c.drawPath(hp,p);
    p.setColor(0xFFD0A85E);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.25f);Path edge=new Path();edge.moveTo(0,h-10);edge.quadTo(W()/2,h+12,W(),h-10);c.drawPath(edge,p); p.setColor(0x55F0D89B);p.setStrokeWidth(.65f);Path edge2=new Path();edge2.moveTo(0,h-7);edge2.quadTo(W()/2,h+15,W(),h-7);c.drawPath(edge2,p);p.setStyle(Paint.Style.FILL);
    text(c,"ב״ה",W()-18,20,9.5f,0xFFE9DFCF,Paint.Align.RIGHT,true);
    // Small botanical strokes: deliberately thin, not glossy or bubble-like.
    p.setColor(0xFFC6A15C);p.setStrokeWidth(1.05f);p.setStyle(Paint.Style.STROKE);c.drawLine(18,25,18,78,p);c.drawLine(18,42,31,32,p);c.drawLine(18,54,7,45,p);c.drawLine(18,65,31,55,p);c.drawLine(18,74,8,68,p);p.setStyle(Paint.Style.FILL);
    displayText(c,"יומן הסופר",W()/2,45,27,0xFFE3C477,Paint.Align.CENTER,true);
    round(c,W()/2-49,54,W()/2+49,75,10,0xFFE7C986); stroke(c,W()/2-49,54,W()/2+49,75,10,0xFF9E7538,.8f);
    text(c,"מהדורת זהב",W()/2,68.5f,10.5f,NAVY,Paint.Align.CENTER,true);
    // The approved reference places the current section inside the navy masthead.
    text(c,headerScreenTitle(),W()-24,96,18.5f,0xFFF7F0E3,Paint.Align.RIGHT,true);
    text(c,headerScreenSubtitle(),W()-24,110,8.8f,0xFFE9DFCF,Paint.Align.RIGHT,false);
    // quill / book silhouette at lower left of masthead
    p.setColor(0xFFE7C986);p.setStrokeWidth(2);p.setStyle(Paint.Style.STROKE);c.drawLine(44,101,66,85,p);c.drawLine(47,98,58,98,p);c.drawLine(53,93,62,93,p);p.setStyle(Paint.Style.FILL);
    // Secondary screens keep navigation inside the navy masthead, as in the approved reference.
    if(screen>=5){ text(c,"‹",25,103,28,0xFFE3C477,Paint.Align.LEFT,false); }
  }
  String headerScreenTitle(){
    if(screen==0)return "לוח שנה"; if(screen==1)return "היום שלי"; if(screen==2)return "הזמנות"; if(screen==3)return "נתונים"; if(screen==4)return "עוד"; if(screen==5)return "כתיבה"; if(screen==6)return "עדכון הספק"; if(screen==7)return "פרטי הזמנה"; if(screen==8)return "הגדרות סדר יום"; if(screen==9)return "סיכום היום"; if(screen==10)return "תכנון שבועי"; if(screen==11)return "מחברת הסופר"; if(screen==12)return "כספים"; if(screen==13)return "הגהות ותיקונים"; if(screen==14)return "יעדים ותכנון"; if(screen==15)return "גיבוי ושחזור"; if(screen==16)return "חופשות"; return "דוח חודשי";
  }
  String headerScreenSubtitle(){
    if(screen==0)return "תכנון, מועדים והזמנות"; if(screen==1)return "סדר היום, יעדים והספק"; if(screen==2)return "ניהול הזמנות ומעקב ביצוע"; if(screen==3)return "סטטיסטיקות וניתוח כתיבה"; if(screen==4)return "ניהול, הגדרות וכלים נוספים"; if(screen==5)return "מחזורי כתיבה והפסקות"; if(screen==6)return "שמירת ההספק בפועל"; if(screen==7)return "מעקב התקדמות, מסירה וכספים"; if(screen==8)return "שעות, מחזורים והפסקות"; if(screen==9)return "הספק, זמן ויעד יומי"; if(screen==10)return "חלוקת העבודה לשבוע"; if(screen==11)return "הערות, תזכורות ושמירת מקום"; if(screen==12)return "הכנסות, הוצאות ורווחיות"; if(screen==13)return "מעקב אחר בדיקות ותיקונים"; if(screen==14)return "יעדים מותאמים לתקופה"; if(screen==15)return "שמירת נתוני היומן"; if(screen==16)return "ימים ללא כתיבה"; return "סיכום כתיבה חודשי";
  }
  void title(Canvas c,String a,String b,float y){
    // Screen identity and subtitle live only in the masthead. Avoid duplicating them on the cream body.
    ornamentalRule(c,y+12);
  }
  void card(Canvas c,float t,float b){
    round(c,20,t+2,W()-20,b+2,15,0x100B2339);
    round(c,18,t,W()-18,b,15,0xFFFFFBF4);
    stroke(c,18,t,W()-18,b,15,0xFFD5C29D,.8f);
  }
  void sectionLabel(Canvas c,String label,float y){
    text(c,label,W()-31,y,11.2f,0xFF9A7B47,Paint.Align.RIGHT,true);
    line(c,31,y+7,W()-31,y+7,0x26AB8448,.8f);
  }
  void goldMedallion(Canvas c,float x,float y,String glyph){
    p.setColor(0x18AB8448);c.drawCircle(x,y,18,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.1f);p.setColor(0xFFC6A15C);c.drawCircle(x,y,15,p);p.setStyle(Paint.Style.FILL);text(c,glyph,x,y+5,13,GOLD,Paint.Align.CENTER,true);
  }
  void ornamentalRule(Canvas c,float y){
    float cx=W()/2f; line(c,30,y,cx-18,y,0x66C6A15C,.8f); line(c,cx+18,y,W()-30,y,0x66C6A15C,.8f);
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1f);p.setColor(0x99C6A15C);c.save();c.rotate(45,cx,y);c.drawRect(cx-5,y-5,cx+5,y+5,p);c.restore();p.setStyle(Paint.Style.FILL);
  }
  void approvedSection(Canvas c,String label,float y){
    ornamentalRule(c,y); text(c,label,W()/2,y+20,11.5f,0xFF8D7143,Paint.Align.CENTER,true);
  }
  void approvedButton(Canvas c,float top,String label,boolean primary){
    int bg=primary?NAVY:0xFFFFFBF4, fg=primary?Color.WHITE:INK; round(c,31,top,W()-31,top+50,15,bg); stroke(c,31,top,W()-31,top+50,15,primary?0xFFC6A15C:0xFFD5C29D,1f); text(c,label,W()/2,top+32,16.5f,fg,Paint.Align.CENTER,true);
  }
  void dateChip(Canvas c,float top,String main,String sub){
    round(c,31,top,W()-31,top+48,15,0xFFF9F3E8); stroke(c,31,top,W()-31,top+48,15,0xFFD8C6A5,.9f);
    text(c,main,W()-47,top+21,13.5f,INK,Paint.Align.RIGHT,true); text(c,sub,W()-47,top+38,10.2f,0xFF7A7062,Paint.Align.RIGHT,false);
    goldMedallion(c,51,top+24,"◷");
  }
  void cycleBadge(Canvas c,float x,float y,int number,boolean done){
    int bg=done?0xFFE8F0E8:0xFFF7F0E3; int fg=done?0xFF3F7651:GOLD; round(c,x-18,y-16,x+18,y+16,10,bg); stroke(c,x-18,y-16,x+18,y+16,10,done?0xFF86A28B:0xFFD8C6A5,.8f); text(c,done?"✓":String.valueOf(number),x,y+5,12.5f,fg,Paint.Align.CENTER,true);
  }
  void statusPill(Canvas c,float right,float top,String label,int color){
    float w=Math.max(64,18+label.length()*7.2f); round(c,right-w,top,right,top+25,12,0xFFF7F0E3); stroke(c,right-w,top,right,top+25,12,color,.8f); text(c,label,right-10,top+17,10.5f,color,Paint.Align.RIGHT,true);
  }
  void parchmentFooter(Canvas c,float top){
    if(top>H()-bottomH()-12)return; p.setColor(0x14C6A15C);p.setStyle(Paint.Style.FILL);Path q=new Path();q.moveTo(0,H()-bottomH()-3);q.lineTo(0,top+25);q.quadTo(W()*.22f,top-8,W()*.43f,top+18);q.quadTo(W()*.68f,top+42,W(),top+8);q.lineTo(W(),H()-bottomH()-3);q.close();c.drawPath(q,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0x55C6A15C);c.drawLine(20,top+31,82,top+4,p);c.drawLine(28,top+24,20,top+10,p);c.drawLine(44,top+18,37,top+3,p);c.drawLine(60,top+12,56,top,p);p.setStyle(Paint.Style.FILL);
  }
  void metricCard(Canvas c,float top,String label,String value,int valueColor){
    card(c,top,top+72);text(c,label,W()-42,top+27,13,0xFF68717A,Paint.Align.RIGHT,false);text(c,value,W()-42,top+54,21,valueColor,Paint.Align.RIGHT,true);
  }
  String gregMonthHe(int m){String[] a={"ינואר","פברואר","מרץ","אפריל","מאי","יוני","יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"};return a[Math.max(0,Math.min(11,m))];}
  boolean hebLeap(int y){return ((7*y+1)%19)<7;}
  long hebElapsed(int y){long m=235L*((y-1)/19)+12L*((y-1)%19)+(7L*((y-1)%19)+1)/19;long pe=204+793*(m%1080),he=5+12*m+793*(m/1080)+pe/1080,d=1+29*m+he/24,parts=(he%24)*1080+pe%1080;if(parts>=19440||(d%7==2&&parts>=9924&&!hebLeap(y))||(d%7==1&&parts>=16789&&hebLeap(y-1)))d++;if(d%7==0||d%7==3||d%7==5)d++;return d;}
  int hebYearDays(int y){return (int)(hebElapsed(y+1)-hebElapsed(y));}
  int hebMonthDays(int y,int m){boolean leap=hebLeap(y);if(m==1)return 30;if(m==2)return hebYearDays(y)%10==5?30:29;if(m==3)return hebYearDays(y)%10==3?29:30;if(m==4)return 29;if(m==5)return 30;if(m==6)return leap?30:29;if(leap){int[] a={0,0,0,0,0,0,30,29,30,29,30,29,30};return a[m];}int[] a={0,0,0,0,0,0,29,30,29,30,29,30};return a[m];}
  int[] hebDate(Calendar g){Calendar z=(Calendar)g.clone();z.set(Calendar.HOUR_OF_DAY,12);z.set(Calendar.MINUTE,0);z.set(Calendar.SECOND,0);z.set(Calendar.MILLISECOND,0);long abs=z.getTimeInMillis()/86400000L+719163L;final long E=-1373428L;int y=(int)((abs-E)/366)+1;while(abs>=E+hebElapsed(y+1))y++;while(abs<E+hebElapsed(y))y--;long day=abs-(E+hebElapsed(y))+1;int m=1;while(day>hebMonthDays(y,m)){day-=hebMonthDays(y,m);m++;}return new int[]{y,m,(int)day};}
  String hebMonthName(int y,int m){String[] common={"","תשרי","חשוון","כסלו","טבת","שבט","אדר","ניסן","אייר","סיוון","תמוז","אב","אלול"};String[] leap={"","תשרי","חשוון","כסלו","טבת","שבט","אדר א׳","אדר ב׳","ניסן","אייר","סיוון","תמוז","אב","אלול"};return hebLeap(y)?leap[Math.max(1,Math.min(13,m))]:common[Math.max(1,Math.min(12,m))];}
  String hebNum(int n){if(n<=0)return "";StringBuilder b=new StringBuilder();int[] vals={400,300,200,100,90,80,70,60,50,40,30,20,10,9,8,7,6,5,4,3,2,1};String[] lets={"ת","ש","ר","ק","צ","פ","ע","ס","נ","מ","ל","כ","י","ט","ח","ז","ו","ה","ד","ג","ב","א"};if(n==15)return "ט״ו";if(n==16)return "ט״ז";for(int i=0;i<vals.length;i++)while(n>=vals[i]){b.append(lets[i]);n-=vals[i];}if(b.length()==1)b.append('׳');else if(b.length()>1)b.insert(b.length()-1,'״');return b.toString();}
  String hebYearText(int y){return hebNum(y%1000);}
  String hebDateText(Calendar g){int[] h=hebDate(g);return hebNum(h[2])+" ב"+hebMonthName(h[0],h[1])+" "+hebYearText(h[0]);}
  String hebMonthSpan(Calendar month){Calendar a=(Calendar)month.clone();a.set(Calendar.DAY_OF_MONTH,1);Calendar z=(Calendar)month.clone();z.set(Calendar.DAY_OF_MONTH,z.getActualMaximum(Calendar.DAY_OF_MONTH));int[] h1=hebDate(a),h2=hebDate(z);String names=hebMonthName(h1[0],h1[1]);if(h1[1]!=h2[1]||h1[0]!=h2[0])names+="–"+hebMonthName(h2[0],h2[1]);return names+" "+hebYearText(h2[0]);}
  boolean majorYomTov(int[] h){int m=h[1],d=h[2];boolean leap=hebLeap(h[0]);int nisan=leap?8:7,sivan=leap?10:9;return (m==1&&(d==1||d==2||d==10||d==15||d==22))||(m==nisan&&(d==15||d==21))||(m==sivan&&d==6);}
  boolean inVacationRange(Calendar g,long start,long end,boolean enabled){if(!enabled||start<=0||end<=0)return false;Calendar d=(Calendar)g.clone();d.set(Calendar.HOUR_OF_DAY,12);d.set(Calendar.MINUTE,0);d.set(Calendar.SECOND,0);d.set(Calendar.MILLISECOND,0);Calendar a=Calendar.getInstance(),z=Calendar.getInstance();a.setTimeInMillis(Math.min(start,end));z.setTimeInMillis(Math.max(start,end));for(Calendar q:new Calendar[]{a,z}){q.set(Calendar.HOUR_OF_DAY,12);q.set(Calendar.MINUTE,0);q.set(Calendar.SECOND,0);q.set(Calendar.MILLISECOND,0);}return !d.before(a)&&!d.after(z);} boolean isVacationDay(Calendar g){if(inVacationRange(g,vacationStartEpoch,vacationEndEpoch,vacationEnabled))return true;for(int vi=0;vi<2;vi++)if(inVacationRange(g,extraVacationStartEpoch[vi],extraVacationEndEpoch[vi],extraVacationEnabled[vi]))return true;return false;}
  boolean nonWorkCalendarDay(Calendar g){int dow=g.get(Calendar.DAY_OF_WEEK);return dow==Calendar.FRIDAY||dow==Calendar.SATURDAY||majorYomTov(hebDate(g))||isVacationDay(g);}
  boolean writingWorkDay(Calendar g){return !nonWorkCalendarDay(g);}
  Calendar weekDayCalendar(int i){Calendar a=Calendar.getInstance();int dow=a.get(Calendar.DAY_OF_WEEK);a.add(Calendar.DAY_OF_MONTH,-(dow-Calendar.SUNDAY)+(weeklyOffset*7)+i);return a;}
  boolean hebDayIsSaturday(int y,int m,int d){Calendar q=Calendar.getInstance();q.set(Calendar.HOUR_OF_DAY,12);q.set(Calendar.MINUTE,0);q.set(Calendar.SECOND,0);q.set(Calendar.MILLISECOND,0);Calendar scan=(Calendar)q.clone();scan.add(Calendar.DAY_OF_MONTH,-420);for(int i=0;i<840;i++){int[] h=hebDate(scan);if(h[0]==y&&h[1]==m&&h[2]==d)return scan.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY;scan.add(Calendar.DAY_OF_MONTH,1);}return false;}
  boolean shiftedFast(int y,int m,int d,int fixedDay){if(d==fixedDay&&!hebDayIsSaturday(y,m,fixedDay))return true;return d==fixedDay+1&&hebDayIsSaturday(y,m,fixedDay);}
  boolean isChanukah(int y,int m,int d){if(m==3&&d>=25)return true;if(m!=4)return false;int kislevDays=hebMonthDays(y,3);return d<=(kislevDays==30?2:3);}
  String jewishHoliday(Calendar g){int[] h=hebDate(g);int y=h[0],m=h[1],d=h[2];boolean leap=hebLeap(y);int adar=leap?7:6,nisan=leap?8:7,sivan=leap?10:9,tammuz=leap?11:10,av=leap?12:11;if(isVacationDay(g))return "חופשה אישית";if(m==1&&d==1)return "ראש השנה";if(m==1&&d==2)return "ראש השנה ב׳";if(m==1&&((d==3&&!hebDayIsSaturday(y,1,3))||(d==4&&hebDayIsSaturday(y,1,3))))return "צום גדליה";if(m==1&&d==10)return "יום כיפור";if(m==1&&d==15)return "סוכות";if(m==1&&d>=16&&d<=21)return "חול המועד סוכות";if(m==1&&d==22)return "שמיני עצרת";if(isChanukah(y,m,d))return "חנוכה";if(m==4&&d==10)return "עשרה בטבת";if(m==adar&&((d==13&&g.get(Calendar.DAY_OF_WEEK)!=Calendar.SATURDAY)||(d==11&&hebDayIsSaturday(y,adar,13))))return "תענית אסתר";if(m==adar&&d==14)return "פורים";if(m==adar&&d==15)return "שושן פורים";if(m==nisan&&d==15)return "פסח";if(m==nisan&&d>=16&&d<=20)return "חול המועד פסח";if(m==nisan&&d==21)return "שביעי של פסח";if(m==sivan&&d==6)return "שבועות";if(m==tammuz&&shiftedFast(y,tammuz,d,17))return "י״ז בתמוז";if(m==av&&shiftedFast(y,av,d,9))return "תשעה באב";if(d==1||(d==30&&m!=1))return "ראש חודש";if(g.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY)return "שבת";if(g.get(Calendar.DAY_OF_WEEK)==Calendar.FRIDAY)return "יום שישי – אין כתיבה";return "";}
  boolean sameCalendarDay(long epoch,int year,int month,int day){Calendar c=Calendar.getInstance();c.setTimeInMillis(epoch);return c.get(Calendar.YEAR)==year&&c.get(Calendar.MONTH)==month&&c.get(Calendar.DAY_OF_MONTH)==day;}
  int firstOrderDueOn(int year,int month,int day){for(int i=0;i<orderCount;i++)if(orderDueEpochs[i]>0&&sameCalendarDay(orderDueEpochs[i],year,month,day))return i;return -1;}
  int orderTypeColor(String type){if(type==null)return 0xFF344764; if(type.contains("מזוז"))return 0xFF78938B;if(type.contains("מגיל"))return 0xFFA47A91;if(type.contains("ספר תורה"))return 0xFFC6A15C;return 0xFF344764;}
  java.util.Calendar shownMonth(){java.util.Calendar cal=java.util.Calendar.getInstance();cal.set(java.util.Calendar.DAY_OF_MONTH,1);cal.add(java.util.Calendar.MONTH,calendarOffset);return cal;}
  void home(Canvas c,float t,float b){
    java.util.Calendar cal=shownMonth(), now=java.util.Calendar.getInstance(); int month=cal.get(java.util.Calendar.MONTH), year=cal.get(java.util.Calendar.YEAR);
    title(c,"לוח שנה",hebMonthSpan(cal)+"  •  "+gregMonthHe(month)+" "+year,t+31);
    float y=t+68; card(c,y,y+286);
    text(c,hebMonthSpan(cal),W()/2,y+27,20,INK,Paint.Align.CENTER,true); text(c,gregMonthHe(month)+" "+year,W()/2,y+45,10.8f,0xFF77746D,Paint.Align.CENTER,false);
    text(c,"‹",44,y+32,27,GOLD,Paint.Align.CENTER,false); text(c,"›",W()-44,y+32,27,GOLD,Paint.Align.CENTER,false);
    String[] wd={"א","ב","ג","ד","ה","ו","ש"}; float left=39,right=W()-39,col=(right-left)/6f;
    for(int i=0;i<7;i++) text(c,wd[i],right-i*col,y+65,13,0xFF6E7378,Paint.Align.CENTER,true);
    int firstDow=cal.get(java.util.Calendar.DAY_OF_WEEK); int days=cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH); int firstCol=firstDow-1;
    for(int d=1;d<=days;d++){int pos=firstCol+d-1,r=pos/7,cc=pos%7; float x=right-cc*col,yy=y+91+r*31;
      boolean today=calendarOffset==0 && d==now.get(java.util.Calendar.DAY_OF_MONTH); boolean selected=d==selectedCalendarDay;
      Calendar cell=(Calendar)cal.clone();cell.set(Calendar.DAY_OF_MONTH,d);boolean nonWork=nonWorkCalendarDay(cell);
      if(nonWork&&!today&&!selected)round(c,x-17,yy-20,x+17,yy+13,8,0xFFF0EBE2);
      if(today||selected){round(c,x-16,yy-19,x+16,yy+12,9,today?0xFFEAD8B4:0xFFF3EBDD);stroke(c,x-16,yy-19,x+16,yy+12,9,GOLD,today?1.2f:.8f);}
      text(c,""+d,x,yy-2,12.5f,nonWork?0xFF8A8175:INK,Paint.Align.CENTER,today||selected);int[] hd=hebDate(cell);text(c,hebNum(hd[2]),x,yy+10,7.8f,nonWork?0xFF9A8E7E:0xFF8A8175,Paint.Align.CENTER,false);
      int dots=0; for(int oi=0;oi<orderCount;oi++){if(orderDueEpochs[oi]>0 && sameCalendarDay(orderDueEpochs[oi],year,month,d)){p.setColor(orderTypeColor(orderTypes[oi]));c.drawCircle(x-((dots-1)*5),yy+8,2.6f,p);dots++; if(dots>=3)break;}}
    }
    float ly=y+258; text(c,"● תפילין",W()-48,ly,11.5f,0xFF344764,Paint.Align.RIGHT,false); text(c,"● מזוזות",W()*.70f,ly,11.5f,0xFF78938B,Paint.Align.RIGHT,false); text(c,"● מגילות",W()*.43f,ly,11.5f,0xFFA47A91,Paint.Align.RIGHT,false); text(c,"● ספר תורה",W()*.18f,ly,11.5f,0xFFC6A15C,Paint.Align.RIGHT,false);
    float y2=y+300; card(c,y2,Math.min(b,y2+143)); String head=selectedCalendarDay>0?"יום "+selectedCalendarDay:(calendarOffset==0?"היום":"תחילת החודש"); text(c,head,W()-40,y2+30,18.5f,INK,Paint.Align.RIGHT,true);
    Calendar picked=(Calendar)cal.clone(); if(selectedCalendarDay>0)picked.set(Calendar.DAY_OF_MONTH,selectedCalendarDay);else if(calendarOffset==0)picked=now;else picked.set(Calendar.DAY_OF_MONTH,1); String ds=hebDateText(picked)+"  •  "+new java.text.SimpleDateFormat("dd/MM/yyyy",java.util.Locale.US).format(picked.getTime());
    text(c,ds,W()-40,y2+53,12.8f,0xFF73787D,Paint.Align.RIGHT,false); int dueIdx=selectedCalendarDay>0?firstOrderDueOn(year,month,selectedCalendarDay):-1; String holiday=jewishHoliday(picked); String calOrder=dueIdx>=0?orderNames[dueIdx]:(!holiday.isEmpty()?holiday:orderName); text(c,calOrder,W()-40,y2+81,17.5f,INK,Paint.Align.RIGHT,true); text(c,dueIdx>=0?"מסירה מתוכננת ביום זה":(!holiday.isEmpty()?"יום ללא כתיבה":"יעד: "+dailyTarget+" שורות"),W()-40,y2+104,13.5f,0xFF68717A,Paint.Align.RIGHT,false);
    float todayFrac=Math.min(1f,totalLines()/(float)Math.max(1,dailyTarget));progress(c,40,y2+117,W()-40,todayFrac);text(c,Math.round(todayFrac*100)+"%",40,y2+139,12.5f,GOLD,Paint.Align.LEFT,true);
  }
  void day(Canvas c,float t,float b){
    title(c,"היום שלי","סדר היום, יעדים והספק",t+34); float y=t+70;
    card(c,y,y+112); statusPill(c,W()-42,y+14,dayFinished?"היום נסגר":(dayReadyToClose?"מוכן לסגירה":"יום כתיבה"),dayFinished?0xFF3F7651:GOLD);
    text(c,orderName,W()-42,y+58,19,INK,Paint.Align.RIGHT,true); text(c,"יעד יומי  •  "+dailyTarget+" שורות",W()-42,y+84,13.5f,0xFF68717A,Paint.Align.RIGHT,false);
    float by=y+125; approvedButton(c,by,running?"חזרה לטיימר":"התחל כתיבה",true);
    float pY=by+67; card(c,pY,pY+88); int total=totalLines(); float frac=Math.min(1f,total/(float)Math.max(1,dailyTarget));
    text(c,"התקדמות היום",W()-42,pY+27,16.5f,INK,Paint.Align.RIGHT,true); text(c,total+" / "+dailyTarget+" שורות",W()-42,pY+53,13.5f,0xFF68717A,Paint.Align.RIGHT,false); text(c,Math.round(frac*100)+"%",42,pY+53,14,GOLD,Paint.Align.LEFT,true); progress(c,42,pY+67,W()-42,frac);
    float list=pY+103; int[] starts=cycleStarts(); int shown=Math.min(cycleCount,6);
    for(int i=0;i<shown;i++){float ry=list+i*44; round(c,31,ry,W()-31,ry+36,11,0xFFFFFBF4); stroke(c,31,ry,W()-31,ry+36,11,0x22AB8448,.7f); cycleBadge(c,W()-53,ry+18,i+1,cycleDone[i]); String row=hm(starts[i])+"–"+hm(starts[i]+cycleMinutes); text(c,row,W()-82,ry+22,13.2f,cycleDone[i]?0xFF3F7651:INK,Paint.Align.RIGHT,cycleDone[i]); text(c,cycleDone[i]?cycleLines[i]+" שורות":(i==3?"אחריו הפסקה ארוכה":cycleMinutes+" דקות"),43,ry+22,11.5f,cycleDone[i]?GOLD:0xFF8A8175,Paint.Align.LEFT,cycleDone[i]);}
  }
  void orders(Canvas c,float t,float b){
    title(c,"הזמנות","ניהול הזמנות פעילות והתקדמות",t+34); float y=t+72;
    approvedButton(c,y,"＋  הזמנה חדשה",true);
    int pageCount=Math.max(1,(orderCount+3)/4); ordersPage=Math.max(0,Math.min(pageCount-1,ordersPage)); int firstOrder=ordersPage*4;
    float yy=y+65; int visible=Math.min(4,Math.max(0,orderCount-firstOrder));
    for(int row=0;row<visible;row++){int i=firstOrder+row;float oy=yy+row*112; card(c,oy,oy+96); int typeCol=orderTypeColor(orderTypes[i]); statusPill(c,W()-42,oy+12,orderTypes[i],typeCol); text(c,orderNames[i],W()-42,oy+51,16.5f,INK,Paint.Align.RIGHT,true); if(!orderCustomers[i].isEmpty())text(c,orderCustomers[i],W()-42,oy+70,11.5f,0xFF7A7062,Paint.Align.RIGHT,false); text(c,orderProgresses[i]+"%",42,oy+31,14.5f,typeCol,Paint.Align.LEFT,true); progress(c,42,oy+77,W()-42,orderProgresses[i]/100f); text(c,orderDues[i],42,oy+67,10.5f,0xFF8A8175,Paint.Align.LEFT,false);}
    if(pageCount>1){float py=Math.min(b-17,yy+4*112+4); text(c,"‹",42,py,23,GOLD,Paint.Align.LEFT,true); text(c,"עמוד "+(ordersPage+1)+" מתוך "+pageCount,W()/2,py,11.5f,0xFF7A7062,Paint.Align.CENTER,true); text(c,"›",W()-42,py,23,GOLD,Paint.Align.RIGHT,true);}
  }
  boolean sameMonthKey(String key,Calendar m){ if(key==null||key.length()<7)return false; try{String[] a=key.split("-");return Integer.parseInt(a[0])==m.get(Calendar.YEAR)&&Integer.parseInt(a[1])==m.get(Calendar.MONTH)+1;}catch(Exception e){return false;} }
  int historyLinesForMonth(Calendar m){int n=0;for(int i=0;i<historyCount;i++)if(sameMonthKey(historyDates[i],m))n+=historyLines[i];return n;}
  int historyDaysForMonth(Calendar m){int n=0;for(int i=0;i<historyCount;i++)if(sameMonthKey(historyDates[i],m))n++;return n;}
  int historyCyclesForMonth(Calendar m){int n=0;for(int i=0;i<historyCount;i++)if(sameMonthKey(historyDates[i],m))n+=historyCycles[i];return n;}
  int historyMinutesForMonth(Calendar m){int n=0;for(int i=0;i<historyCount;i++)if(sameMonthKey(historyDates[i],m))n+=historyMinutes[i];return n;}
  int monthlyHistoryLines(){return historyLinesForMonth(Calendar.getInstance());}
  int monthlyHistoryDays(){return historyDaysForMonth(Calendar.getInstance());}
  int monthlyHistoryCycles(){return historyCyclesForMonth(Calendar.getInstance());}
  int monthlyHistoryMinutes(){return historyMinutesForMonth(Calendar.getInstance());}
  Calendar reportMonth(){Calendar m=Calendar.getInstance();m.set(Calendar.DAY_OF_MONTH,1);m.set(Calendar.HOUR_OF_DAY,12);m.set(Calendar.MINUTE,0);m.set(Calendar.SECOND,0);m.set(Calendar.MILLISECOND,0);m.add(Calendar.MONTH,reportMonthOffset);return m;}
  String monthLabel(Calendar m){String[] mn={"ינואר","פברואר","מרץ","אפריל","מאי","יוני","יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"};return mn[m.get(Calendar.MONTH)]+" "+m.get(Calendar.YEAR);}
  String currentMonthLabel(){return monthLabel(reportMonth());}
  void data(Canvas c,float t,float b){
    title(c,"נתונים","סטטיסטיקות וניתוח כתיבה",t+34); float y=t+74;
    int lines=totalLines(), done=completedCycles(); int histCycles=historicalCycles(), monthLines=monthlyHistoryLines(), monthDays=monthlyHistoryDays(), monthCycles=monthlyHistoryCycles(); int avgCycle=histCycles==0?0:Math.round(historicalLines()/(float)histCycles); int totalPaid=0;for(int oi=0;oi<orderCount;oi++)totalPaid+=orderPaids[oi];int profit=totalPaid-monthlyExpenses;
    card(c,y,y+112); goldMedallion(c,W()-52,y+55,"▥"); text(c,"הספק כתיבה",W()-84,y+31,17,INK,Paint.Align.RIGHT,true);text(c,"החודש הנוכחי",W()-84,y+53,11.5f,0xFF7A7062,Paint.Align.RIGHT,false);
    text(c,monthLines+"",W()*.76f,y+86,22,INK,Paint.Align.CENTER,true);text(c,monthDays+"",W()*.50f,y+86,22,INK,Paint.Align.CENTER,true);text(c,monthCycles+"",W()*.24f,y+86,22,INK,Paint.Align.CENTER,true);text(c,"שורות",W()*.76f,y+103,10.5f,0xFF77746D,Paint.Align.CENTER,false);text(c,"ימים",W()*.50f,y+103,10.5f,0xFF77746D,Paint.Align.CENTER,false);text(c,"מחזורים",W()*.24f,y+103,10.5f,0xFF77746D,Paint.Align.CENTER,false);
    float sy=y+126;metricCard(c,sy,"קצב אישי","ממוצע "+avgCycle+" שורות למחזור",INK);goldMedallion(c,48,sy+36,"↗");
    metricCard(c,sy+84,"רווחיות","₪ "+profit,GOLD);goldMedallion(c,48,sy+120,"₪");
    metricCard(c,sy+168,"היום",""+lines+" שורות  •  "+done+"/6 מחזורים",INK);goldMedallion(c,48,sy+204,"✓");
    card(c,sy+252,sy+324);text(c,"דוח חודשי",W()-42,sy+280,16,INK,Paint.Align.RIGHT,true);text(c,"סיכום מלא של כתיבה, קצב ורווחיות",W()-42,sy+305,12.5f,0xFF68717A,Paint.Align.RIGHT,false);text(c,"‹",42,sy+295,24,GOLD,Paint.Align.LEFT,false);
    parchmentFooter(c,sy+340);
  }
  void monthlyReport(Canvas c,float t,float b){
    Calendar rm=reportMonth(); backTitle(c,"דוח חודשי",currentMonthLabel(),t+34);
    text(c,"‹",42,t+62,25,GOLD,Paint.Align.CENTER,true); text(c,reportMonthOffset==0?"החודש הנוכחי":"חזרה לחודש הנוכחי",W()/2,t+62,11.5f,0xFF7A7062,Paint.Align.CENTER,false); text(c,"›",W()-42,t+62,25,GOLD,Paint.Align.CENTER,true);
    float y=t+88;
    int lines=historyLinesForMonth(rm),days=historyDaysForMonth(rm),cycles=historyCyclesForMonth(rm),minutes=historyMinutesForMonth(rm);
    int avgDay=days==0?0:Math.round(lines/(float)days),avgCycle=cycles==0?0:Math.round(lines/(float)cycles);
    card(c,y,y+126); text(c,"סיכום החודש",W()-42,y+30,17,INK,Paint.Align.RIGHT,true);
    text(c,""+lines,W()*.78f,y+76,24,GOLD,Paint.Align.CENTER,true); text(c,""+days,W()*.50f,y+76,24,INK,Paint.Align.CENTER,true); text(c,""+cycles,W()*.22f,y+76,24,INK,Paint.Align.CENTER,true);
    text(c,"שורות",W()*.78f,y+100,11,0xFF77746D,Paint.Align.CENTER,false); text(c,"ימי כתיבה",W()*.50f,y+100,11,0xFF77746D,Paint.Align.CENTER,false); text(c,"מחזורים",W()*.22f,y+100,11,0xFF77746D,Paint.Align.CENTER,false);
    metricCard(c,y+145,"זמן כתיבה",durationHm(minutes),INK); goldMedallion(c,48,y+181,"◷");
    metricCard(c,y+229,"ממוצע ליום",avgDay+" שורות",GOLD); goldMedallion(c,48,y+265,"↗");
    metricCard(c,y+313,"ממוצע למחזור",avgCycle+" שורות",INK); goldMedallion(c,48,y+349,"▥");
    card(c,y+407,y+479); text(c,"הנתונים מבוססים על ימים שנסגרו ביומן",W()-42,y+438,13,INK,Paint.Align.RIGHT,true); text(c,"יום שעדיין פתוח אינו נכנס לדוח החודשי",W()-42,y+461,11.5f,0xFF7A7062,Paint.Align.RIGHT,false);
  }

  void more(Canvas c,float t,float b){title(c,"עוד","ניהול, הגדרות וכלים נוספים",t+34);sectionLabel(c,"כלי הסופר",t+62);String[] rows={"תכנון שבועי","מחברת הסופר","הגהות ותיקונים","הגדרות סדר יום","כספים","יעדים","חופשות וימי אי־עבודה","גיבוי ושחזור"};float y=t+70;for(int i=0;i<rows.length;i++){card(c,y+i*52,y+43+i*52);text(c,rows[i],W()-42,y+28+i*52,15,INK,Paint.Align.RIGHT,true);text(c,"‹",42,y+29+i*52,22,GOLD,Paint.Align.LEFT,false);p.setColor(0x22C6A15C);c.drawCircle(W()-29,y+21+i*52,4,p);} }

  void backTitle(Canvas c,String a,String b,float y){title(c,a,b,y);}
  void timer(Canvas c,float t,float b){
    int[] st=cycleStarts(); int ci=Math.min(currentCycle,5);
    String sub=phaseName()+"  •  מחזור "+(ci+1)+" מתוך 6";
    backTitle(c,"טיימר "+phaseName(),sub,t+34);
    float cy=t+190,rad=Math.min(W()*.265f,106);
    // Refined timer face: thinner antique-gold ring and a quiet inner border, closer to the approved luxury treatment.
    p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND);
    p.setStrokeWidth(9); p.setColor(0xFFE4D9C7); c.drawCircle(W()/2,cy,rad,p);
    float total=Math.max(1,phaseDurationMs()); float progress=1f-(float)timerMs/total;
    p.setColor(GOLD); c.drawArc(W()/2-rad,cy-rad,W()/2+rad,cy+rad,-90,360*Math.max(0,Math.min(1,progress)),false,p);
    p.setStrokeWidth(1); p.setColor(0x55AB8448); c.drawCircle(W()/2,cy,rad-18,p);
    p.setStrokeCap(Paint.Cap.BUTT); p.setStyle(Paint.Style.FILL);
    text(c,phaseName(),W()/2,cy-35,12,0xFF8A7658,Paint.Align.CENTER,false);
    long sec=timerMs/1000;text(c,String.format(java.util.Locale.US,"%02d:%02d",sec/60,sec%60),W()/2,cy+10,38,INK,Paint.Align.CENTER,true);
    if(timerPhase==0) text(c,hm(st[ci])+"–"+hm(st[ci]+cycleMinutes),W()/2,cy+39,13,0xFF68717A,Paint.Align.CENTER,false);
    else text(c,(timerPhase==2?longBreakMinutes:breakMinutes)+" דקות מנוחה",W()/2,cy+39,13,0xFF68717A,Paint.Align.CENTER,false);
    float y=cy+137;round(c,42,y,W()-42,y+52,15,NAVY);
    String btn=running?"השהה":(timerFinished?(timerPhase==0?"עדכן הספק":"המחזור הבא מוכן"):"התחל");
    text(c,btn,W()/2,y+35,19,Color.WHITE,Paint.Align.CENTER,true);
    card(c,y+72,y+142);
    text(c,orderName,W()-58,y+92,11.5f,GOLD,Paint.Align.RIGHT,true);
    if(timerFinished){ text(c,timerPhase==0?"המחזור הסתיים ✓":"ההפסקה הסתיימה ✓",W()-58,y+111,15.5f,INK,Paint.Align.RIGHT,true); text(c,timerPhase==0?(ci==3?"הפסקה ארוכה • "+breakMinutesAfterCycle(ci)+" דקות":"הפסקה • "+breakMinutesAfterCycle(ci)+" דקות"):(ci<5?"מחזור "+(ci+2)+" מוכן להתחלה":"סיום יום"),W()-58,y+132,12.5f,0xFF68717A,Paint.Align.RIGHT,false);}
    else { text(c,"המשך סדר היום",W()-58,y+111,15.5f,INK,Paint.Align.RIGHT,true); if(ci<5) text(c,hm(st[ci+1])+"–"+hm(st[ci+1]+cycleMinutes)+"  •  מחזור "+(ci+2),W()-58,y+132,12.5f,0xFF68717A,Paint.Align.RIGHT,false); else text(c,"זהו המחזור האחרון להיום",W()-58,y+132,12.5f,0xFF68717A,Paint.Align.RIGHT,false);}
  }
  void update(Canvas c,float t,float b){int[] st=cycleStarts(); int ci=Math.min(currentCycle,st.length-1); backTitle(c,"עדכון הספק בפועל","מחזור "+(ci+1)+"  •  "+hm(st[ci])+"–"+hm(st[ci]+cycleMinutes),t+34);float y=t+85;card(c,y,y+245);text(c,"כמה שורות כתבת?",W()/2,y+45,21,INK,Paint.Align.CENTER,true);text(c,"−        "+actualLines+"        +",W()/2,y+105,31,GOLD,Paint.Align.CENTER,true);stroke(c,55,y+70,W()-55,y+125,18,0xFFD8C6A5,1.5f);text(c,"הערה למחזור (לא חובה)",W()-55,y+160,14,0xFF68717A,Paint.Align.RIGHT,false);stroke(c,45,y+175,W()-45,y+220,15,0xFFE1D2B7,1.3f);round(c,45,y+265,W()-45,y+320,18,NAVY);text(c,"שמירת העדכון",W()/2,y+300,18,Color.WHITE,Paint.Align.CENTER,true);}
  void orderDetail(Canvas c,float t,float b){backTitle(c,"פרטי הזמנה",orderName,t+34);float y=t+80;card(c,y,y+373);String startText=orderStartEpochs[activeOrder]>0?dateText(orderStartEpochs[activeOrder]):"טרם נקבע"; String[] r={"שם ההזמנה     "+orderName,"סוג / לקוח     "+orderTypes[activeOrder]+(orderCustomers[activeOrder].isEmpty()?"":" • "+orderCustomers[activeOrder]),"התחלה / מסירה     "+startText+"  ←  "+orderDue,"הספק בפועל       "+orderActualUnits[activeOrder]+" / "+orderTargets[activeOrder]+"  •  "+orderProgress+"%","מחיר / שולם       ₪ "+orderPrice+" / ₪ "+orderPaid+(orderPaid>0?"  •  "+expenseDateText(orderPaidEpochs[activeOrder]):""),"יתרה              ₪ "+Math.max(0,orderPrice-orderPaid),"רווח צפוי          ₪ "+orderExpectedProfits[activeOrder]};for(int i=0;i<r.length;i++){text(c,r[i],W()-45,y+34+i*43,14.6f,INK,Paint.Align.RIGHT,i==2);if(i<r.length-1){p.setColor(0xFFE9DFCF);c.drawLine(45,y+47+i*43,W()-45,y+47+i*43,p);}}progress(c,45,y+335,W()-45,orderProgress/100f);round(c,31,y+387,W()/2-6,y+437,14,NAVY);text(c,"התקדמות +5%",(31+W()/2-6)/2,y+419,15.5f,Color.WHITE,Paint.Align.CENTER,true);round(c,W()/2+6,y+387,W()-31,y+437,14,0xFFF7F1E6);stroke(c,W()/2+6,y+387,W()-31,y+437,14,0xFFC9B68F,0.9f);text(c,"עריכת פרטים",(W()/2+6+W()-31)/2,y+419,15,GOLD,Paint.Align.CENTER,true);round(c,31,y+453,W()-31,y+499,14,0xFFFFFBF4);stroke(c,31,y+453,W()-31,y+499,14,0xFFC9B68F,0.9f);text(c,"מחיקת הזמנה",W()/2,y+482,14.5f,0xFF8A4F4F,Paint.Align.CENTER,true);text(c,"לחץ על תאריך המסירה לבחירת תאריך",W()/2,y+525,12.5f,0xFF7A7062,Paint.Align.CENTER,false);}
  void settings(Canvas c,float t,float b){backTitle(c,"הגדרות סדר יום","שעות, מחזורים והפסקות",t+34);String[] a={"שעת התחלה|"+hm(startMinutes)+"|◷","שעת סיום|"+hm(plannedEnd())+"|◷","מבנה המחזורים|6 מחזורים • "+cycleMinutes+" דקות|▦","הפסקה רגילה|"+breakMinutes+" דקות|☕","הפסקה ארוכה|"+longBreakMinutes+" דקות|⌛"};float y=t+75;for(int i=0;i<a.length;i++){String[] q=a[i].split("\\|");float ry=y+i*67;card(c,ry,ry+58);text(c,q[0],W()-42,ry+24,14.5f,INK,Paint.Align.RIGHT,true);text(c,q[1],W()-42,ry+45,12.5f,0xFF68717A,Paint.Align.RIGHT,false);goldMedallion(c,48,ry+29,q[2]);}card(c,y+345,y+407);text(c,(adaptive?"✓":"○")+"  הזזה אוטומטית בהתחלה מאוחרת",W()-42,y+373,14,INK,Paint.Align.RIGHT,true);text(c,"כל יום חדש חוזר לברירת המחדל",W()-42,y+395,11.5f,0xFF68717A,Paint.Align.RIGHT,false);parchmentFooter(c,y+425);}
  void summary(Canvas c,float t,float b){backTitle(c,"סיכום היום","סיכום לפי המחזורים שנשמרו",t+34); int done=completedCycles(),total=totalLines(); float y=t+78;card(c,y,y+135);text(c,done+"/6",W()*.78f,y+70,30,GOLD,Paint.Align.CENTER,true);text(c,durationHm(done*cycleMinutes),W()*.5f,y+70,30,INK,Paint.Align.CENTER,true);text(c,""+total,W()*.22f,y+70,30,INK,Paint.Align.CENTER,true);text(c,"מחזורים",W()*.78f,y+100,13,0xFF68717A,Paint.Align.CENTER,false);text(c,"זמן כתיבה",W()*.5f,y+100,13,0xFF68717A,Paint.Align.CENTER,false);text(c,"שורות",W()*.22f,y+100,13,0xFF68717A,Paint.Align.CENTER,false);card(c,y+155,y+275);text(c,"יעד יומי "+dailyTarget+" שורות",W()-42,y+190,17,INK,Paint.Align.RIGHT,true);float frac=Math.min(1f,total/(float)Math.max(1,dailyTarget));text(c,"בפועל "+total+" שורות  •  "+Math.round(total/(float)Math.max(1,dailyTarget)*100)+"%",W()-42,y+220,16,GOLD,Paint.Align.RIGHT,true);progress(c,42,y+240,W()-42,frac);approvedButton(c,y+300,dayFinished?"היום נסגר ✓":(dayReadyToClose?"סיימתי לכתוב להיום":"יש להשלים 6 מחזורים"),true);parchmentFooter(c,y+380);}
  String weeklyRangeText(){ Calendar a=weekDayCalendar(0); Calendar z=weekDayCalendar(4); return String.format(Locale.US,"%02d/%02d – %02d/%02d/%04d",a.get(Calendar.DAY_OF_MONTH),a.get(Calendar.MONTH)+1,z.get(Calendar.DAY_OF_MONTH),z.get(Calendar.MONTH)+1,z.get(Calendar.YEAR)); }
  String weeklyDayLabel(int i){ String[] names={"א׳","ב׳","ג׳","ד׳","ה׳","ו׳"}; Calendar a=weekDayCalendar(i); return names[i]+" "+a.get(Calendar.DAY_OF_MONTH); }
  void weekly(Canvas c,float t,float b){backTitle(c,"תכנון שבועי",weeklyRangeText(),t+34);text(c,"‹",42,t+60,25,GOLD,Paint.Align.CENTER,true);text(c,weeklyOffset==0?"השבוע":"חזרה לשבוע הנוכחי",W()/2,t+60,11.5f,0xFF7A7062,Paint.Align.CENTER,false);text(c,"›",W()-42,t+60,25,GOLD,Paint.Align.CENTER,true);sectionLabel(c,"שבוע העבודה",t+78);float y=t+96;int total=0;for(int i=0;i<5;i++){Calendar wd=weekDayCalendar(i);boolean off=!writingWorkDay(wd);if(!off)total+=weeklyCycles[i];card(c,y+i*60,y+51+i*60);text(c,weeklyDayLabel(i),W()-42,y+25+i*60,15,off?0xFF9A8E7E:GOLD,Paint.Align.RIGHT,true);String h=hebDateText(wd);text(c,h,W()-42,y+42+i*60,9.5f,0xFF8A8175,Paint.Align.RIGHT,false);String plan=off?jewishHoliday(wd):weeklyPlans[i];text(c,plan,W()-120,y+31+i*60,14.5f,off?0xFF8A8175:INK,Paint.Align.RIGHT,true);String cy=off?"אין כתיבה":(weeklyCycles[i]==0?"—":weeklyCycles[i]+" מחזורים");text(c,cy,42,y+31+i*60,12.5f,off?0xFF9A8E7E:0xFF68717A,Paint.Align.LEFT,false);}card(c,y+308,y+356);text(c,"סה״כ שבועי",W()-42,y+338,14,INK,Paint.Align.RIGHT,true);text(c,total+" מחזורים",42,y+338,14,GOLD,Paint.Align.LEFT,true);text(c,"שישי, שבת ויום טוב אינם נספרים כימי כתיבה",W()/2,y+378,12.2f,0xFF7A7062,Paint.Align.CENTER,false);}
  void editWeeklyDayDialog(int i){ if(i<0||i>=6)return; LinearLayout box=new LinearLayout(getContext());box.setOrientation(LinearLayout.VERTICAL);int pad=24;box.setPadding(pad,8,pad,0);EditText plan=new EditText(getContext());plan.setHint("מה מתוכנן ליום זה");plan.setText(weeklyPlans[i]);plan.setGravity(Gravity.RIGHT);EditText cycles=new EditText(getContext());cycles.setHint("מספר מחזורים 0–6");cycles.setInputType(InputType.TYPE_CLASS_NUMBER);cycles.setText(String.valueOf(weeklyCycles[i]));box.addView(plan);box.addView(cycles);new AlertDialog.Builder(getContext()).setTitle("תכנון "+weeklyDayLabel(i)).setView(box).setPositiveButton("שמור",(d,w)->{String v=plan.getText().toString().trim();if(!v.isEmpty())weeklyPlans[i]=v;try{weeklyCycles[i]=Math.max(0,Math.min(6,Integer.parseInt(cycles.getText().toString().trim())));}catch(Exception ex){}saveState();invalidate();}).setNegativeButton("ביטול",null).show();}

  String shortDate(long epoch){if(epoch<=0)return "לא נקבע";Calendar d=Calendar.getInstance();d.setTimeInMillis(epoch);return String.format(Locale.US,"%02d/%02d/%04d",d.get(Calendar.DAY_OF_MONTH),d.get(Calendar.MONTH)+1,d.get(Calendar.YEAR));}
  void vacations(Canvas c,float t,float b){backTitle(c,"חופשות וימי אי־עבודה","עד שלושה טווחים אישיים בנוסף לשבתות וימים טובים",t+34);float y=t+70;long[] starts={vacationStartEpoch,extraVacationStartEpoch[0],extraVacationStartEpoch[1]},ends={vacationEndEpoch,extraVacationEndEpoch[0],extraVacationEndEpoch[1]};boolean[] enabled={vacationEnabled,extraVacationEnabled[0],extraVacationEnabled[1]};for(int i=0;i<3;i++){card(c,y+i*92,y+76+i*92);text(c,"טווח "+(i+1)+(enabled[i]?"  ✓":""),W()-42,y+25+i*92,15,INK,Paint.Align.RIGHT,true);text(c,shortDate(starts[i])+"  —  "+shortDate(ends[i]),W()-42,y+51+i*92,14,GOLD,Paint.Align.RIGHT,true);text(c,"לחץ לעריכה • לחיצה ארוכה אינה נדרשת",42,y+51+i*92,11.5f,0xFF7A7062,Paint.Align.LEFT,false);}text(c,"טווחים פעילים מוחרגים מתכנון שבועי ומחישובי יעדים",W()/2,y+304,12.5f,0xFF7A7062,Paint.Align.CENTER,false);}
  void chooseVacationRange(int idx){long st=idx==0?vacationStartEpoch:extraVacationStartEpoch[idx-1], en=idx==0?vacationEndEpoch:extraVacationEndEpoch[idx-1];Calendar d=Calendar.getInstance();if(st>0)d.setTimeInMillis(st);new DatePickerDialog(getContext(),(v,yy,mm,dd)->{Calendar q=Calendar.getInstance();q.set(yy,mm,dd,12,0,0);q.set(Calendar.MILLISECOND,0);long ns=q.getTimeInMillis();Calendar ecal=Calendar.getInstance();if(en>0)ecal.setTimeInMillis(en);else ecal.setTimeInMillis(ns);new DatePickerDialog(getContext(),(v2,yy2,mm2,dd2)->{Calendar z=Calendar.getInstance();z.set(yy2,mm2,dd2,12,0,0);z.set(Calendar.MILLISECOND,0);long ne=z.getTimeInMillis();if(ns>ne){long x=ns;nsHolder[0]=ne;nsHolder[1]=ns;}else{nsHolder[0]=ns;nsHolder[1]=ne;}if(idx==0){vacationStartEpoch=nsHolder[0];vacationEndEpoch=nsHolder[1];vacationEnabled=true;}else{extraVacationStartEpoch[idx-1]=nsHolder[0];extraVacationEndEpoch[idx-1]=nsHolder[1];extraVacationEnabled[idx-1]=true;}saveState();invalidate();},ecal.get(Calendar.YEAR),ecal.get(Calendar.MONTH),ecal.get(Calendar.DAY_OF_MONTH)).show();},d.get(Calendar.YEAR),d.get(Calendar.MONTH),d.get(Calendar.DAY_OF_MONTH)).show();}
  private final long[] nsHolder=new long[2];

  void notebook(Canvas c,float t,float b){backTitle(c,"מחברת הסופר","הערות, רעיונות ומקום כתיבה",t+34);sectionLabel(c,"רשומות",t+63);float y=t+78;approvedButton(c,y,"＋  הערה חדשה",true);int pages=Math.max(1,(notebookCount+3)/4);notebookPage=Math.max(0,Math.min(notebookPage,pages-1));int start=notebookPage*4,end=Math.min(notebookCount,start+4);for(int i=start;i<end;i++){float ry=y+55+(i-start)*45;card(c,ry,ry+39);text(c,notebookTexts[i],W()-42,ry+18,13,INK,Paint.Align.RIGHT,true);int oi=notebookOrderIndex[i];String meta=(notebookPlaces[i].isEmpty()?"":"מקום: "+notebookPlaces[i]+"  •  ")+(oi>=0&&oi<orderCount?"הזמנה: "+orderNames[oi]:"ללא שיוך");text(c,meta,W()-42,ry+34,10,0xFF7B7F82,Paint.Align.RIGHT,false);} if(notebookCount==0)text(c,"עדיין אין הערות",W()/2,y+92,13,GOLD,Paint.Align.CENTER,true);if(pages>1){float py=y+250;text(c,"‹",52,py,24,GOLD,Paint.Align.CENTER,true);text(c,(notebookPage+1)+" / "+pages,W()/2,py,12,0xFF7A7062,Paint.Align.CENTER,true);text(c,"›",W()-52,py,24,GOLD,Paint.Align.CENTER,true);}}
  void proofreading(Canvas c,float t,float b){backTitle(c,"הגהות ותיקונים","מעקב אחרי בדיקות ותיקונים",t+34);sectionLabel(c,"מצב ההגהות",t+65);float y=t+84;card(c,y,y+92);text(c,"פתוחים",W()*.72f,y+38,13,0xFF68717A,Paint.Align.CENTER,false);text(c,""+proofreadingOpen,W()*.72f,y+69,24,GOLD,Paint.Align.CENTER,true);text(c,"הושלמו",W()*.28f,y+38,13,0xFF68717A,Paint.Align.CENTER,false);text(c,""+proofreadingDone,W()*.28f,y+69,24,INK,Paint.Align.CENTER,true);int pages=Math.max(1,(proofreadingCount+3)/4);proofreadingPage=Math.max(0,Math.min(proofreadingPage,pages-1));int start=proofreadingPage*4,end=Math.min(proofreadingCount,start+4);float listY=y+105,rowH=48;for(int i=start;i<end;i++){float ry=listY+(i-start)*rowH;card(c,ry,ry+41);text(c,proofreadingNames[i],W()-42,ry+19,14.2f,INK,Paint.Align.RIGHT,true);String link=(proofreadingOrderIndex[i]>=0&&proofreadingOrderIndex[i]<orderCount)?" • "+orderNames[proofreadingOrderIndex[i]]:"";text(c,(proofreadingCompleted[i]?"הושלם ✓":"ממתין")+link,W()-42,ry+35,10.8f,proofreadingCompleted[i]?0xFF3F7651:0xFF68717A,Paint.Align.RIGHT,false);}float navY=listY+205;if(pages>1){text(c,"‹",52,navY,24,GOLD,Paint.Align.CENTER,true);text(c,(proofreadingPage+1)+" / "+pages,W()/2,navY,12,0xFF7A7062,Paint.Align.CENTER,true);text(c,"›",W()-52,navY,24,GOLD,Paint.Align.CENTER,true);}float add=Math.min(b-61,listY+245);round(c,42,add,W()-42,add+49,14,NAVY);text(c,proofreadingCount>=8?"הגעת למקסימום 8":"＋ הוספת הגהה",W()/2,add+31,15.5f,Color.WHITE,Paint.Align.CENTER,true);}


  Calendar financeMonth(){ Calendar m=Calendar.getInstance(); m.set(Calendar.DAY_OF_MONTH,1); m.set(Calendar.HOUR_OF_DAY,12); m.set(Calendar.MINUTE,0); m.set(Calendar.SECOND,0); m.set(Calendar.MILLISECOND,0); m.add(Calendar.MONTH,financeMonthOffset); return m; }
  boolean sameMonth(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.MONTH)==b.get(Calendar.MONTH);}
  boolean monthOnOrAfter(Calendar target,long startEpoch){if(startEpoch<=0)return false;Calendar start=Calendar.getInstance();start.setTimeInMillis(startEpoch);int tm=target.get(Calendar.YEAR)*12+target.get(Calendar.MONTH),sm=start.get(Calendar.YEAR)*12+start.get(Calendar.MONTH);return tm>=sm;}
  boolean expenseAppliesToMonth(int idx,Calendar target){if(idx<0||idx>=expenseAmounts.length)return false;long epoch=expenseDateEpoch[idx];if(epoch<=0)return financeMonthOffset==0;if(expenseRecurring[idx])return monthOnOrAfter(target,epoch);Calendar d=Calendar.getInstance();d.setTimeInMillis(epoch);return sameMonth(target,d);}
  boolean expenseInFinanceMonth(long epoch){ if(epoch<=0)return financeMonthOffset==0; Calendar m=financeMonth(),d=Calendar.getInstance();d.setTimeInMillis(epoch);return sameMonth(m,d); }
  boolean expenseInCurrentMonth(long epoch){ if(epoch<=0)return true; Calendar now=Calendar.getInstance(),d=Calendar.getInstance();d.setTimeInMillis(epoch);return sameMonth(now,d); }
  String financeMonthLabel(){ Calendar m=financeMonth(); String[] names={"ינואר","פברואר","מרץ","אפריל","מאי","יוני","יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"};return names[m.get(Calendar.MONTH)]+" "+m.get(Calendar.YEAR); }
  int financeMonthExpenses(){int sum=0;Calendar target=financeMonth();for(int i=0;i<expenseCount;i++)if(expenseAppliesToMonth(i,target))sum+=Math.max(0,expenseAmounts[i]);return sum;}
  void recalcMonthlyExpenses(){monthlyExpenses=0;Calendar target=Calendar.getInstance();for(int i=0;i<expenseCount;i++){long epoch=expenseDateEpoch[i];boolean applies;if(epoch<=0)applies=true;else if(expenseRecurring[i])applies=monthOnOrAfter(target,epoch);else{Calendar d=Calendar.getInstance();d.setTimeInMillis(epoch);applies=sameMonth(target,d);}if(applies)monthlyExpenses+=Math.max(0,expenseAmounts[i]);}}

  void finance(Canvas c,float t,float b){
    recalcMonthlyExpenses(); backTitle(c,"כספים","הכנסות, הוצאות ורווחיות",t+34); float y=t+76;
    int monthExpenses=financeMonthExpenses(),monthPaid=0;for(int oi=0;oi<orderCount;oi++)if(orderPaids[oi]>0&&orderPaidEpochs[oi]>0&&expenseInFinanceMonth(orderPaidEpochs[oi]))monthPaid+=orderPaids[oi];int profit=monthPaid-monthExpenses;
    round(c,31,y-4,W()-31,y+34,13,0xFFFFFBF4);stroke(c,31,y-4,W()-31,y+34,13,0xFFC9B68F,0.9f);text(c,"‹",49,y+21,22,GOLD,Paint.Align.CENTER,true);text(c,financeMonthLabel(),W()/2,y+20,14.5f,INK,Paint.Align.CENTER,true);text(c,"›",W()-49,y+21,22,GOLD,Paint.Align.CENTER,true);
    metricCard(c,y+46,"תקבולים בחודש","₪ "+monthPaid,0xFF3F7651);goldMedallion(c,48,y+82,"↗");
    metricCard(c,y+128,"הוצאות בחודש","₪ "+monthExpenses,0xFF9A5353);goldMedallion(c,48,y+164,"↘");
    metricCard(c,y+210,"יתרה בחודש","₪ "+profit,GOLD);goldMedallion(c,48,y+246,"▥");
    approvedSection(c,"רשומות הוצאות",y+293);
    Calendar viewedFinanceMonth=financeMonth();int expenseStart=expensePage*4;for(int row=0;row<4;row++){int i=expenseStart+row;if(i>=expenseCount)break;float ry=y+324+row*49;card(c,ry,ry+41);text(c,expenseNames[i],W()-42,ry+18,13.5f,INK,Paint.Align.RIGHT,true);boolean inMonth=expenseAppliesToMonth(i,viewedFinanceMonth);String recurrence=expenseRecurring[i]?" • קבועה מהתאריך":"";String flags=(expensePaid[i]?"שולם":"ממתין")+recurrence+(expenseDateEpoch[i]>0?" • "+expenseDateText(expenseDateEpoch[i]):"")+(inMonth?"":" • לא חל בחודש");text(c,flags,W()-42,ry+34,10.5f,inMonth?(expensePaid[i]?0xFF56735E:0xFF8A8175):0xFF9A5353,Paint.Align.RIGHT,false);text(c,"₪ "+expenseAmounts[i],42,ry+26,13.5f,GOLD,Paint.Align.LEFT,true);}
    if(expenseCount>4){text(c,expensePage==0?"עמוד 1 מתוך 2  ›":"‹  עמוד 2 מתוך 2",W()/2,y+527,11.5f,GOLD,Paint.Align.CENTER,true);} text(c,expenseCount<8?"＋ הוסף הוצאה":"לחץ על הוצאה לעריכה",W()/2,y+548,11.5f,0xFF7A7062,Paint.Align.CENTER,true);parchmentFooter(c,y+562);
  }

  void goals(Canvas c,float t,float b){
    backTitle(c,"יעדים","יעדים מותאמים עד 20 שנה",t+34); float y=t+78; goalDone=goalProgressLines();
    card(c,y,y+145); text(c,"היעד הפעיל",W()-42,y+32,19,INK,Paint.Align.RIGHT,true);
    text(c,""+goalDone+" / "+goalTarget+" שורות",W()-42,y+70,18,GOLD,Paint.Align.RIGHT,true); progress(c,42,y+90,W()-42,Math.min(1f,goalDone/(float)Math.max(1,goalTarget)));
    text(c,"התחלה: "+goalStartText()+"  •  יעד: "+goalDueText(),W()-42,y+119,12.5f,0xFF68717A,Paint.Align.RIGHT,false); text(c,"קצב נדרש: "+goalDailyPace+" שורות ליום",W()-42,y+137,12.5f,GOLD,Paint.Align.RIGHT,true);
    card(c,y+165,y+285); text(c,"יחידות כתיבה",W()-42,y+198,17,INK,Paint.Align.RIGHT,true); text(c,"⅔ מזוזה = 14 שורות  •  מזוזה = 21",W()-42,y+228,14,INK,Paint.Align.RIGHT,false); text(c,"½ עמודת מגילה = 21  •  עמודה = 42",W()-42,y+250,14,INK,Paint.Align.RIGHT,false); text(c,"לחץ כאן לעריכת כמות היעד והקצב",W()-42,y+273,11.5f,GOLD,Paint.Align.RIGHT,true);
    card(c,y+300,y+392); text(c,"חישוב מחדש",W()-42,y+330,17,INK,Paint.Align.RIGHT,true); text(c,goalRecalcMode==0?"אפשרות א׳: שומר תאריך יעד ומגדיל קצב":"אפשרות ב׳: שומר קצב ומאריך את התאריך",W()-42,y+360,13,GOLD,Paint.Align.RIGHT,true); text(c,"לחץ להחלפה • בכרטיס היעד: צד ימין התחלה, צד שמאל תאריך יעד",W()-42,y+383,12,0xFF68717A,Paint.Align.RIGHT,false);
    approvedButton(c,y+410,"חשב מחדש לפי ההתקדמות",true);parchmentFooter(c,y+482);
  }
  void createFullBackup(){
    SharedPreferences.Editor e=prefs.edit();
    e.putBoolean("backupExists",true).putLong("backup_created_at",System.currentTimeMillis());
    e.putInt("backup_startMinutes",startMinutes).putInt("backup_cycleMinutes",cycleMinutes).putInt("backup_breakMinutes",breakMinutes).putInt("backup_longBreakMinutes",longBreakMinutes).putBoolean("backup_adaptive",adaptive);
    e.putInt("backup_actualStartMinutes",actualStartMinutes).putString("backup_workDate",workDate).putInt("backup_currentCycle",currentCycle).putInt("backup_dailyTarget",dailyTarget).putBoolean("backup_dayFinished",dayFinished).putBoolean("backup_dayReadyToClose",dayReadyToClose).putInt("backup_actualLines",actualLines);
    e.putInt("backup_activeOrder",activeOrder).putInt("backup_monthlyExpenses",monthlyExpenses); e.putInt("backup_expenseCount",expenseCount); for(int ei=0;ei<8;ei++) e.putString("backup_expenseName"+ei,expenseNames[ei]).putInt("backup_expenseAmount"+ei,expenseAmounts[ei]).putBoolean("backup_expensePaid"+ei,expensePaid[ei]).putBoolean("backup_expenseRecurring"+ei,expenseRecurring[ei]).putLong("backup_expenseDateEpoch"+ei,expenseDateEpoch[ei]); e.putInt("backup_notebookNotes",notebookNotes).putInt("backup_notebookCount",notebookCount); for(int ni=0;ni<8;ni++)e.putString("backup_notebookText"+ni,notebookTexts[ni]).putString("backup_notebookPlace"+ni,notebookPlaces[ni]).putInt("backup_notebookOrderIndex"+ni,notebookOrderIndex[ni]).putLong("backup_notebookDateEpoch"+ni,notebookDateEpoch[ni]); e.putInt("backup_proofreadingOpen",proofreadingOpen).putInt("backup_proofreadingDone",proofreadingDone).putInt("backup_proofreadingCount",proofreadingCount); for(int pi=0;pi<8;pi++)e.putString("backup_proofreadingName"+pi,proofreadingNames[pi]).putBoolean("backup_proofreadingCompleted"+pi,proofreadingCompleted[pi]).putInt("backup_proofreadingOrderIndex"+pi,proofreadingOrderIndex[pi]).putLong("backup_proofreadingDateEpoch"+pi,proofreadingDateEpoch[pi]).putString("backup_proofreadingNotes"+pi,proofreadingNotes[pi]);
    for(int wi=0;wi<6;wi++)e.putString("backup_weeklyPlan"+wi,weeklyPlans[wi]).putInt("backup_weeklyCycles"+wi,weeklyCycles[wi]);
    e.putInt("backup_goalYears",goalYears).putInt("backup_goalTarget",goalTarget).putInt("backup_goalDone",goalDone).putInt("backup_goalRecalcMode",goalRecalcMode).putInt("backup_goalDailyPace",goalDailyPace).putLong("backup_goalDueEpoch",goalDueEpoch).putLong("backup_goalStartEpoch",goalStartEpoch).putLong("backup_vacationStartEpoch",vacationStartEpoch).putLong("backup_vacationEndEpoch",vacationEndEpoch).putBoolean("backup_vacationEnabled",vacationEnabled); for(int vi=0;vi<2;vi++)e.putLong("backup_extraVacationStartEpoch"+vi,extraVacationStartEpoch[vi]).putLong("backup_extraVacationEndEpoch"+vi,extraVacationEndEpoch[vi]).putBoolean("backup_extraVacationEnabled"+vi,extraVacationEnabled[vi]);
    for(int i=0;i<6;i++) e.putInt("backup_cycleLines"+i,cycleLines[i]).putBoolean("backup_cycleDone"+i,cycleDone[i]); e.putInt("backup_historyCount",historyCount); for(int hi=0;hi<historyCount;hi++)e.putString("backup_historyDate"+hi,historyDates[hi]==null?"":historyDates[hi]).putInt("backup_historyLines"+hi,historyLines[hi]).putInt("backup_historyCycles"+hi,historyCycles[hi]).putInt("backup_historyMinutes"+hi,historyMinutes[hi]);
    e.putInt("backup_orderCount",orderCount); for(int i=0;i<8;i++) e.putString("backup_orderName"+i,orderNames[i]).putString("backup_orderDue"+i,orderDues[i]).putInt("backup_orderProgress"+i,orderProgresses[i]).putInt("backup_orderPrice"+i,orderPrices[i]).putInt("backup_orderPaid"+i,orderPaids[i]).putLong("backup_orderPaidEpoch"+i,orderPaidEpochs[i]).putString("backup_orderType"+i,orderTypes[i]).putString("backup_orderCustomer"+i,orderCustomers[i]).putLong("backup_orderDueEpoch"+i,orderDueEpochs[i]).putLong("backup_orderStartEpoch"+i,orderStartEpochs[i]).putInt("backup_orderExpectedProfit"+i,orderExpectedProfits[i]).putInt("backup_orderTarget"+i,orderTargets[i]).putInt("backup_orderActualUnits"+i,orderActualUnits[i]);
    e.apply(); backupExists=true; saveState();
  }
  void restoreFullBackup(){
    if(!backupExists)return;
    startMinutes=Math.max(0,Math.min(1439,prefs.getInt("backup_startMinutes",startMinutes))); cycleMinutes=Math.max(5,Math.min(180,prefs.getInt("backup_cycleMinutes",cycleMinutes))); breakMinutes=Math.max(0,Math.min(120,prefs.getInt("backup_breakMinutes",breakMinutes))); longBreakMinutes=Math.max(0,Math.min(240,prefs.getInt("backup_longBreakMinutes",longBreakMinutes))); adaptive=prefs.getBoolean("backup_adaptive",adaptive);
    actualStartMinutes=prefs.getInt("backup_actualStartMinutes",actualStartMinutes); workDate=prefs.getString("backup_workDate",workDate); currentCycle=prefs.getInt("backup_currentCycle",currentCycle); dailyTarget=prefs.getInt("backup_dailyTarget",dailyTarget); dayFinished=prefs.getBoolean("backup_dayFinished",dayFinished); dayReadyToClose=prefs.getBoolean("backup_dayReadyToClose",completedCycles()==6 && !dayFinished); actualLines=prefs.getInt("backup_actualLines",actualLines);
    int restoredActiveOrder=prefs.getInt("backup_activeOrder",activeOrder); monthlyExpenses=prefs.getInt("backup_monthlyExpenses",monthlyExpenses); expenseCount=Math.max(0,Math.min(8,prefs.getInt("backup_expenseCount",expenseCount))); for(int ei=0;ei<8;ei++){expenseNames[ei]=prefs.getString("backup_expenseName"+ei,expenseNames[ei]);expenseAmounts[ei]=prefs.getInt("backup_expenseAmount"+ei,expenseAmounts[ei]);expensePaid[ei]=prefs.getBoolean("backup_expensePaid"+ei,expensePaid[ei]);expenseRecurring[ei]=prefs.getBoolean("backup_expenseRecurring"+ei,expenseRecurring[ei]);expenseDateEpoch[ei]=prefs.getLong("backup_expenseDateEpoch"+ei,expenseDateEpoch[ei]);} recalcMonthlyExpenses(); notebookNotes=prefs.getInt("backup_notebookNotes",notebookNotes); notebookCount=Math.max(0,Math.min(8,prefs.getInt("backup_notebookCount",notebookNotes))); for(int ni=0;ni<8;ni++){notebookTexts[ni]=prefs.getString("backup_notebookText"+ni,notebookTexts[ni]);notebookPlaces[ni]=prefs.getString("backup_notebookPlace"+ni,notebookPlaces[ni]);notebookOrderIndex[ni]=prefs.getInt("backup_notebookOrderIndex"+ni,notebookOrderIndex[ni]);notebookDateEpoch[ni]=prefs.getLong("backup_notebookDateEpoch"+ni,notebookDateEpoch[ni]);} notebookNotes=notebookCount; proofreadingOpen=prefs.getInt("backup_proofreadingOpen",proofreadingOpen); proofreadingDone=prefs.getInt("backup_proofreadingDone",proofreadingDone); proofreadingCount=Math.max(0,Math.min(8,prefs.getInt("backup_proofreadingCount",proofreadingCount)));for(int pi=0;pi<8;pi++){proofreadingNames[pi]=prefs.getString("backup_proofreadingName"+pi,proofreadingNames[pi]);proofreadingCompleted[pi]=prefs.getBoolean("backup_proofreadingCompleted"+pi,proofreadingCompleted[pi]);proofreadingOrderIndex[pi]=prefs.getInt("backup_proofreadingOrderIndex"+pi,proofreadingOrderIndex[pi]);proofreadingDateEpoch[pi]=prefs.getLong("backup_proofreadingDateEpoch"+pi,proofreadingDateEpoch[pi]);proofreadingNotes[pi]=prefs.getString("backup_proofreadingNotes"+pi,proofreadingNotes[pi]);}recalcProofreading();
    for(int wi=0;wi<6;wi++){weeklyPlans[wi]=prefs.getString("backup_weeklyPlan"+wi,weeklyPlans[wi]);weeklyCycles[wi]=prefs.getInt("backup_weeklyCycles"+wi,weeklyCycles[wi]);}
    goalYears=prefs.getInt("backup_goalYears",goalYears); goalTarget=prefs.getInt("backup_goalTarget",goalTarget); goalDone=prefs.getInt("backup_goalDone",goalDone); goalRecalcMode=prefs.getInt("backup_goalRecalcMode",goalRecalcMode); goalDailyPace=prefs.getInt("backup_goalDailyPace",goalDailyPace); goalDueEpoch=prefs.getLong("backup_goalDueEpoch",goalDueEpoch); goalStartEpoch=prefs.getLong("backup_goalStartEpoch",goalStartEpoch); vacationStartEpoch=prefs.getLong("backup_vacationStartEpoch",vacationStartEpoch); vacationEndEpoch=prefs.getLong("backup_vacationEndEpoch",vacationEndEpoch); vacationEnabled=prefs.getBoolean("backup_vacationEnabled",vacationEnabled); for(int vi=0;vi<2;vi++){extraVacationStartEpoch[vi]=prefs.getLong("backup_extraVacationStartEpoch"+vi,extraVacationStartEpoch[vi]);extraVacationEndEpoch[vi]=prefs.getLong("backup_extraVacationEndEpoch"+vi,extraVacationEndEpoch[vi]);extraVacationEnabled[vi]=prefs.getBoolean("backup_extraVacationEnabled"+vi,extraVacationEnabled[vi]);}
    for(int i=0;i<6;i++){cycleLines[i]=prefs.getInt("backup_cycleLines"+i,cycleLines[i]);cycleDone[i]=prefs.getBoolean("backup_cycleDone"+i,cycleDone[i]);} historyCount=Math.max(0,Math.min(HISTORY_MAX,prefs.getInt("backup_historyCount",historyCount))); for(int hi=0;hi<historyCount;hi++){historyDates[hi]=prefs.getString("backup_historyDate"+hi,historyDates[hi]==null?"":historyDates[hi]);historyLines[hi]=prefs.getInt("backup_historyLines"+hi,historyLines[hi]);historyCycles[hi]=prefs.getInt("backup_historyCycles"+hi,historyCycles[hi]);historyMinutes[hi]=prefs.getInt("backup_historyMinutes"+hi,historyMinutes[hi]);}
    orderCount=Math.max(1,Math.min(8,prefs.getInt("backup_orderCount",orderCount))); activeOrder=Math.max(0,Math.min(orderCount-1,restoredActiveOrder)); for(int i=0;i<8;i++){orderNames[i]=prefs.getString("backup_orderName"+i,orderNames[i]);orderDues[i]=prefs.getString("backup_orderDue"+i,orderDues[i]);orderProgresses[i]=prefs.getInt("backup_orderProgress"+i,orderProgresses[i]);orderPrices[i]=prefs.getInt("backup_orderPrice"+i,orderPrices[i]);orderPaids[i]=prefs.getInt("backup_orderPaid"+i,orderPaids[i]);orderPaidEpochs[i]=prefs.getLong("backup_orderPaidEpoch"+i,orderPaidEpochs[i]);orderTypes[i]=prefs.getString("backup_orderType"+i,orderTypes[i]);orderCustomers[i]=prefs.getString("backup_orderCustomer"+i,orderCustomers[i]);orderDueEpochs[i]=prefs.getLong("backup_orderDueEpoch"+i,orderDueEpochs[i]);orderStartEpochs[i]=prefs.getLong("backup_orderStartEpoch"+i,orderStartEpochs[i]);orderExpectedProfits[i]=prefs.getInt("backup_orderExpectedProfit"+i,orderExpectedProfits[i]);orderTargets[i]=prefs.getInt("backup_orderTarget"+i,orderTargets[i]);orderActualUnits[i]=prefs.getInt("backup_orderActualUnits"+i,orderActualUnits[i]);if(orderTargets[i]>0)orderProgresses[i]=Math.min(100,Math.round(orderActualUnits[i]*100f/orderTargets[i]));}
    sanitizeRestoredData(); syncActiveOrder(); running=false; timerEndAt=0; timerFinished=false; timerPhase=0; timerMs=cycleMinutes*60*1000L; saveState();
  }

  String exportBackupText(){
    StringBuilder b=new StringBuilder();
    b.append("YOMAN_HASOFER_GOLD_BACKUP_V1\n");
    b.append("workDate=").append(workDate).append('\n');
    b.append("schedule=").append(startMinutes).append(',').append(cycleMinutes).append(',').append(breakMinutes).append(',').append(longBreakMinutes).append(',').append(adaptive).append('\n');
    b.append("day=").append(actualStartMinutes).append(',').append(currentCycle).append(',').append(dailyTarget).append(',').append(dayFinished).append(',').append(actualLines).append(',').append(dayReadyToClose).append('\n');
    for(int i=0;i<6;i++) b.append("cycle").append(i).append('=').append(cycleLines[i]).append(',').append(cycleDone[i]).append('\n');
    b.append("orderCount=").append(orderCount).append('\n');
    for(int i=0;i<8;i++) b.append("order").append(i).append('=').append(orderNames[i].replace("\n"," ")).append('|').append(orderDues[i].replace("\n"," ")).append('|').append(orderProgresses[i]).append('|').append(orderPrices[i]).append('|').append(orderPaids[i]).append('|').append(orderDueEpochs[i]).append('|').append(orderTypes[i].replace("\n"," " )).append('|').append(orderCustomers[i].replace("\n"," " )).append('|').append(orderTargets[i]).append('|').append(orderActualUnits[i]).append('|').append(orderStartEpochs[i]).append('|').append(orderExpectedProfits[i]).append('|').append(orderPaidEpochs[i]).append('\n');
    b.append("finance=").append(monthlyExpenses).append('\n'); b.append("expenseCount=").append(expenseCount).append('\n'); for(int ei=0;ei<expenseCount;ei++) b.append("expense").append(ei).append('=').append(expenseNames[ei].replace("\n"," ")).append('|').append(expenseAmounts[ei]).append('|').append(expensePaid[ei]?1:0).append('|').append(expenseRecurring[ei]?1:0).append('|').append(expenseDateEpoch[ei]).append('\n');
    b.append("notebook=").append(notebookNotes).append(',').append(proofreadingOpen).append(',').append(proofreadingDone).append('\n'); b.append("notebookCount=").append(notebookCount).append('\n'); for(int ni=0;ni<8;ni++)b.append("note").append(ni).append('=').append(notebookTexts[ni].replace("\n"," ")).append('|').append(notebookOrderIndex[ni]).append('|').append(notebookDateEpoch[ni]).append('|').append(notebookPlaces[ni].replace("\n"," ")).append('\n'); b.append("proofreadingCount=").append(proofreadingCount).append('\n'); for(int pi=0;pi<8;pi++)b.append("proofreading").append(pi).append('=').append(proofreadingCompleted[pi]?1:0).append('|').append(proofreadingNames[pi].replace("\n"," ")).append('|').append(proofreadingOrderIndex[pi]).append('|').append(proofreadingDateEpoch[pi]).append('|').append(proofreadingNotes[pi].replace("\n"," ")).append('\n');
    b.append("goal=").append(goalYears).append(',').append(goalTarget).append(',').append(goalDone).append(',').append(goalRecalcMode).append(',').append(goalDailyPace).append(',').append(goalDueEpoch).append(',').append(goalStartEpoch).append('\n');
    for(int wi=0;wi<5;wi++) b.append("weekly").append(wi).append('=').append(weeklyCycles[wi]).append('|').append(weeklyPlans[wi].replace("\n"," ")).append('\n');
    b.append("vacation=").append(vacationEnabled).append(',').append(vacationStartEpoch).append(',').append(vacationEndEpoch).append('\n'); for(int vi=0;vi<2;vi++)b.append("extraVacation").append(vi).append('=').append(extraVacationEnabled[vi]).append(',').append(extraVacationStartEpoch[vi]).append(',').append(extraVacationEndEpoch[vi]).append('\n');
    b.append("historyCount=").append(historyCount).append('\n'); for(int hi=0;hi<historyCount;hi++)b.append("history").append(hi).append('=').append(historyDates[hi]).append('|').append(historyLines[hi]).append('|').append(historyCycles[hi]).append('|').append(historyMinutes[hi]).append('\n');
    b.append("activeOrder=").append(activeOrder).append('\n');
    return b.toString();
  }
  void chooseBackupFile(){
    try{
      Intent open=new Intent(Intent.ACTION_OPEN_DOCUMENT);
      open.addCategory(Intent.CATEGORY_OPENABLE); open.setType("text/plain");
      ((Activity)getContext()).startActivityForResult(open,2301);
    }catch(Exception ex){ android.widget.Toast.makeText(getContext(),"לא ניתן לפתוח את בוחר הקבצים",android.widget.Toast.LENGTH_LONG).show(); }
  }
  void importBackupUri(Uri uri){
    if(uri==null)return;
    try{
      StringBuilder sb=new StringBuilder();
      try(BufferedReader r=new BufferedReader(new InputStreamReader(getContext().getContentResolver().openInputStream(uri),StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)sb.append(line).append('\n');}
      importBackupText(sb.toString());
      android.widget.Toast.makeText(getContext(),"הגיבוי יובא בהצלחה",android.widget.Toast.LENGTH_LONG).show();
    }catch(Exception ex){ android.widget.Toast.makeText(getContext(),"קובץ הגיבוי אינו תקין",android.widget.Toast.LENGTH_LONG).show(); }
  }
  void normalizeLinkedOrderIndexes(){
    for(int pi=0;pi<8;pi++) if(proofreadingOrderIndex[pi]<-1 || proofreadingOrderIndex[pi]>=orderCount) proofreadingOrderIndex[pi]=-1;
    for(int ni=0;ni<8;ni++) if(notebookOrderIndex[ni]<-1 || notebookOrderIndex[ni]>=orderCount) notebookOrderIndex[ni]=-1;
  }
  void sanitizeRestoredData(){
    startMinutes=Math.max(0,Math.min(1439,startMinutes)); cycleMinutes=Math.max(5,Math.min(180,cycleMinutes)); breakMinutes=Math.max(0,Math.min(120,breakMinutes)); longBreakMinutes=Math.max(0,Math.min(240,longBreakMinutes));
    if(actualStartMinutes<-1||actualStartMinutes>1439)actualStartMinutes=-1;
    dailyTarget=Math.max(0,dailyTarget); actualLines=Math.max(0,actualLines); currentCycle=Math.max(0,Math.min(5,currentCycle)); cycleCount=6;
    for(int i=0;i<6;i++){cycleLines[i]=Math.max(0,cycleLines[i]);weeklyCycles[i]=Math.max(0,Math.min(6,weeklyCycles[i]));if(weeklyPlans[i]==null)weeklyPlans[i]="";}
    orderCount=Math.max(1,Math.min(8,orderCount)); activeOrder=Math.max(0,Math.min(orderCount-1,activeOrder));
    for(int i=0;i<8;i++){
      if(orderNames[i]==null)orderNames[i]=""; if(orderDues[i]==null)orderDues[i]=""; if(orderTypes[i]==null||orderTypes[i].trim().isEmpty())orderTypes[i]="תפילין"; if(orderCustomers[i]==null)orderCustomers[i]="";
      orderPrices[i]=Math.max(0,orderPrices[i]); orderPaids[i]=Math.max(0,orderPaids[i]); orderExpectedProfits[i]=Math.max(0,orderExpectedProfits[i]); orderTargets[i]=Math.max(0,orderTargets[i]); orderActualUnits[i]=Math.max(0,orderActualUnits[i]);
      orderDueEpochs[i]=Math.max(0L,orderDueEpochs[i]); orderStartEpochs[i]=Math.max(0L,orderStartEpochs[i]); orderPaidEpochs[i]=Math.max(0L,orderPaidEpochs[i]);
      orderProgresses[i]=orderTargets[i]>0?Math.min(100,Math.round(orderActualUnits[i]*100f/orderTargets[i])):Math.max(0,Math.min(100,orderProgresses[i]));
    }
    expenseCount=Math.max(0,Math.min(8,expenseCount)); for(int i=0;i<8;i++){expenseAmounts[i]=Math.max(0,expenseAmounts[i]);expenseDateEpoch[i]=Math.max(0L,expenseDateEpoch[i]);if(expenseNames[i]==null)expenseNames[i]="";}
    notebookCount=Math.max(0,Math.min(8,notebookCount)); proofreadingCount=Math.max(0,Math.min(8,proofreadingCount));
    for(int i=0;i<8;i++){if(notebookTexts[i]==null)notebookTexts[i]="";if(notebookPlaces[i]==null)notebookPlaces[i]="";notebookDateEpoch[i]=Math.max(0L,notebookDateEpoch[i]);if(proofreadingNames[i]==null)proofreadingNames[i]="";if(proofreadingNotes[i]==null)proofreadingNotes[i]="";proofreadingDateEpoch[i]=Math.max(0L,proofreadingDateEpoch[i]);}
    goalYears=Math.max(1,Math.min(20,goalYears)); goalTarget=Math.max(0,goalTarget); goalDone=Math.max(0,goalDone); goalDailyPace=Math.max(1,goalDailyPace); goalStartEpoch=Math.max(0L,goalStartEpoch); goalDueEpoch=Math.max(0L,goalDueEpoch);
    vacationStartEpoch=Math.max(0L,vacationStartEpoch); vacationEndEpoch=Math.max(0L,vacationEndEpoch); if(vacationEnabled&&(vacationStartEpoch<=0||vacationEndEpoch<vacationStartEpoch))vacationEnabled=false;
    for(int i=0;i<2;i++){extraVacationStartEpoch[i]=Math.max(0L,extraVacationStartEpoch[i]);extraVacationEndEpoch[i]=Math.max(0L,extraVacationEndEpoch[i]);if(extraVacationEnabled[i]&&(extraVacationStartEpoch[i]<=0||extraVacationEndEpoch[i]<extraVacationStartEpoch[i]))extraVacationEnabled[i]=false;}
    historyCount=Math.max(0,Math.min(HISTORY_MAX,historyCount)); for(int i=0;i<historyCount;i++){if(historyDates[i]==null)historyDates[i]="";historyLines[i]=Math.max(0,historyLines[i]);historyCycles[i]=Math.max(0,Math.min(6,historyCycles[i]));historyMinutes[i]=Math.max(0,historyMinutes[i]);}
    if(dayFinished)dayReadyToClose=false; else if(completedCycles()<6)dayReadyToClose=false;
    normalizeLinkedOrderIndexes(); notebookNotes=notebookCount; recalcProofreading(); recalcMonthlyExpenses();
  }

  void importBackupText(String txt) throws Exception{
    String[] lines=txt.split("\\r?\\n"); if(lines.length<2 || !lines[0].trim().equals("YOMAN_HASOFER_GOLD_BACKUP_V1")) throw new IOException("bad header");
    for(int k=1;k<lines.length;k++){String line=lines[k]; if(line.trim().isEmpty())continue; int eq=line.indexOf('='); if(eq<1)continue; String key=line.substring(0,eq), val=line.substring(eq+1);
      if(key.equals("workDate")) workDate=val;
      else if(key.equals("schedule")){String[] a=val.split(","); if(a.length>=5){startMinutes=Math.max(0,Math.min(1439,Integer.parseInt(a[0])));cycleMinutes=Math.max(5,Math.min(180,Integer.parseInt(a[1])));breakMinutes=Math.max(0,Math.min(120,Integer.parseInt(a[2])));longBreakMinutes=Math.max(0,Math.min(240,Integer.parseInt(a[3])));adaptive=Boolean.parseBoolean(a[4]);}}
      else if(key.equals("day")){String[] a=val.split(","); if(a.length>=5){actualStartMinutes=Integer.parseInt(a[0]);currentCycle=Math.max(0,Math.min(5,Integer.parseInt(a[1])));dailyTarget=Integer.parseInt(a[2]);dayFinished=Boolean.parseBoolean(a[3]);actualLines=Integer.parseInt(a[4]); if(a.length>=6)dayReadyToClose=Boolean.parseBoolean(a[5]);}}
      else if(key.startsWith("cycle")){int i=Integer.parseInt(key.substring(5));String[] a=val.split(",");if(i>=0&&i<6&&a.length>=2){cycleLines[i]=Integer.parseInt(a[0]);cycleDone[i]=Boolean.parseBoolean(a[1]);}}
      else if(key.equals("orderCount")){orderCount=Math.max(1,Math.min(8,Integer.parseInt(val)));}
      else if(key.startsWith("order")){int i=Integer.parseInt(key.substring(5));String[] a=val.split("\\|",-1);if(i>=0&&i<8&&a.length>=5){orderNames[i]=a[0];orderDues[i]=a[1];orderProgresses[i]=Integer.parseInt(a[2]);orderPrices[i]=Integer.parseInt(a[3]);orderPaids[i]=Integer.parseInt(a[4]);if(a.length>=6)orderDueEpochs[i]=Long.parseLong(a[5]);if(a.length>=7)orderTypes[i]=a[6];if(a.length>=8)orderCustomers[i]=a[7];if(a.length>=9)orderTargets[i]=Integer.parseInt(a[8]);if(a.length>=10)orderActualUnits[i]=Integer.parseInt(a[9]);if(a.length>=11)orderStartEpochs[i]=Long.parseLong(a[10]);if(a.length>=12)orderExpectedProfits[i]=Integer.parseInt(a[11]);if(a.length>=13)orderPaidEpochs[i]=Long.parseLong(a[12]);if(orderTargets[i]>0)orderProgresses[i]=Math.min(100,Math.round(orderActualUnits[i]*100f/orderTargets[i]));}}
      else if(key.equals("expenseCount")) expenseCount=Math.max(0,Math.min(8,Integer.parseInt(val)));
      else if(key.matches("expense\\d+")){int ei=Integer.parseInt(key.substring(7));String[] a=val.split("\\|",-1);if(ei>=0&&ei<8&&a.length>=2){expenseNames[ei]=a[0];expenseAmounts[ei]=Math.max(0,Integer.parseInt(a[1]));if(a.length>=3)expensePaid[ei]=a[2].equals("1");if(a.length>=4)expenseRecurring[ei]=a[3].equals("1");if(a.length>=5)expenseDateEpoch[ei]=Long.parseLong(a[4]);}}
      else if(key.equals("finance")) monthlyExpenses=Integer.parseInt(val);
      else if(key.equals("notebookCount")){notebookCount=Math.max(0,Math.min(8,Integer.parseInt(val)));notebookNotes=notebookCount;} else if(key.startsWith("note")&&!key.equals("notebook")){int ni=Integer.parseInt(key.substring(4));if(ni>=0&&ni<8){String[] a=val.split("\\|",4);notebookTexts[ni]=a[0];if(a.length>=2)notebookOrderIndex[ni]=Integer.parseInt(a[1]);if(a.length>=3)notebookDateEpoch[ni]=Long.parseLong(a[2]);if(a.length>=4)notebookPlaces[ni]=a[3];}} else if(key.equals("proofreadingCount")){proofreadingCount=Math.max(0,Math.min(8,Integer.parseInt(val)));} else if(key.startsWith("proofreading")&&!key.equals("proofreadingCount")){int pi=Integer.parseInt(key.substring(12));if(pi>=0&&pi<8){String[] a=val.split("\\|",5);if(a.length>=2){proofreadingCompleted[pi]=a[0].equals("1");proofreadingNames[pi]=a[1];if(a.length>=3)proofreadingOrderIndex[pi]=Integer.parseInt(a[2]);if(a.length>=4)proofreadingDateEpoch[pi]=Long.parseLong(a[3]);if(a.length>=5)proofreadingNotes[pi]=a[4];}}} else if(key.equals("notebook")){String[] a=val.split(",");if(a.length>=3){notebookNotes=Integer.parseInt(a[0]);proofreadingOpen=Integer.parseInt(a[1]);proofreadingDone=Integer.parseInt(a[2]);}}
      else if(key.startsWith("weekly")){int wi=Integer.parseInt(key.substring(6));String[] a=val.split("\\|",2);if(wi>=0&&wi<5&&a.length==2){weeklyCycles[wi]=Math.max(0,Math.min(6,Integer.parseInt(a[0])));weeklyPlans[wi]=a[1];}}
      else if(key.equals("goal")){String[] a=val.split(",");if(a.length>=4){goalYears=Math.max(1,Math.min(20,Integer.parseInt(a[0])));goalTarget=Integer.parseInt(a[1]);goalDone=Integer.parseInt(a[2]);goalRecalcMode=Integer.parseInt(a[3])==0?0:1;if(a.length>=5)goalDailyPace=Math.max(1,Integer.parseInt(a[4]));if(a.length>=6)goalDueEpoch=Long.parseLong(a[5]);if(a.length>=7)goalStartEpoch=Long.parseLong(a[6]);if(goalStartEpoch<=0)goalStartEpoch=startOfTodayEpoch();}}
      else if(key.equals("vacation")){String[] a=val.split(",");if(a.length>=3){vacationEnabled=Boolean.parseBoolean(a[0]);vacationStartEpoch=Long.parseLong(a[1]);vacationEndEpoch=Long.parseLong(a[2]);}} else if(key.startsWith("extraVacation")){int vi=Integer.parseInt(key.substring(13));String[] a=val.split(",");if(vi>=0&&vi<2&&a.length>=3){extraVacationEnabled[vi]=Boolean.parseBoolean(a[0]);extraVacationStartEpoch[vi]=Long.parseLong(a[1]);extraVacationEndEpoch[vi]=Long.parseLong(a[2]);}}
      else if(key.equals("historyCount")) historyCount=Math.max(0,Math.min(HISTORY_MAX,Integer.parseInt(val))); else if(key.startsWith("history")&&!key.equals("historyCount")){int hi=Integer.parseInt(key.substring(7));String[] a=val.split("\\|",-1);if(hi>=0&&hi<HISTORY_MAX&&a.length>=4){historyDates[hi]=a[0];historyLines[hi]=Integer.parseInt(a[1]);historyCycles[hi]=Integer.parseInt(a[2]);historyMinutes[hi]=Integer.parseInt(a[3]);}} else if(key.equals("activeOrder")) activeOrder=Math.max(0,Math.min(7,Integer.parseInt(val)));
    }
    sanitizeRestoredData(); expensePage=Math.max(0,Math.min(expenseCount<=4?0:1,expensePage)); syncActiveOrder(); running=false; timerEndAt=0L; timerFinished=false; timerPhase=0; timerMs=cycleMinutes*60*1000L; backupExists=true; saveState(); invalidate();
  }

  void exportBackupFile(){
    try{
      File dir=new File(getContext().getFilesDir(),"exports"); if(!dir.exists())dir.mkdirs();
      File f=new File(dir,"yoman_hasofer_backup.txt");
      try(FileOutputStream out=new FileOutputStream(f)){out.write(exportBackupText().getBytes(StandardCharsets.UTF_8));}
      Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_SUBJECT,"גיבוי יומן הסופר – מהדורת זהב"); send.putExtra(Intent.EXTRA_TEXT,exportBackupText());
      getContext().startActivity(Intent.createChooser(send,"שמירת / שיתוף קובץ גיבוי"));
    }catch(Exception ex){ android.widget.Toast.makeText(getContext(),"לא ניתן לייצא את הגיבוי",android.widget.Toast.LENGTH_LONG).show(); }
  }

  void backup(Canvas c,float t,float b){
    backTitle(c,"גיבוי ושחזור","שמירת תמונת מצב מקומית",t+34); sectionLabel(c,"שמירת הנתונים",t+65); float y=t+84;
    card(c,y,y+125); text(c,backupExists?"קיים גיבוי שמור":"עדיין אין גיבוי",W()-42,y+40,18,INK,Paint.Align.RIGHT,true); text(c,backupExists?"אפשר לשחזר את נתוני העבודה מהגיבוי האחרון":"צור גיבוי לפני שינוי גדול או מעבר גרסה",W()-42,y+72,13,0xFF68717A,Paint.Align.RIGHT,false);
    round(c,42,y+155,W()-42,y+208,18,NAVY); text(c,"יצירת גיבוי עכשיו",W()/2,y+189,17,Color.WHITE,Paint.Align.CENTER,true);
    stroke(c,42,y+230,W()-42,y+283,18,GOLD,1.5f); text(c,"שחזור מהגיבוי האחרון",W()/2,y+264,17,GOLD,Paint.Align.CENTER,true);
    round(c,42,y+305,W()-42,y+358,18,0xFFEDE4D4); text(c,"ייצוא גיבוי לקובץ",W()/2,y+339,17,NAVY,Paint.Align.CENTER,true);
    stroke(c,42,y+380,W()-42,y+433,18,GOLD,1.5f); text(c,"ייבוא גיבוי מקובץ",W()/2,y+414,17,GOLD,Paint.Align.CENTER,true);
    text(c,"אפשר להעביר את הנתונים גם למכשיר אחר",W()/2,y+458,11.5f,0xFF68717A,Paint.Align.CENTER,false);
  }

  void progress(Canvas c,float l,float y,float r,float q){round(c,l,y,r,y+10,5,0xFFE8E0D3);round(c,r-(r-l)*q,y,r,y+10,5,GOLD);}
  void bottom(Canvas c,float h){
    float y=H()-h; round(c,7,y,W()-7,H()-4,16,NAVY); stroke(c,7,y,W()-7,H()-4,16,0xFFC6A15C,1.0f);
    String[] n={"לוח שנה","היום שלי","הזמנות","נתונים","עוד"};
    for(int i=0;i<5;i++){float x=W()-(i+.5f)*W()/5f; int col=i==tab?0xFFE2C477:0xFFF1EEE8; if(i==tab){round(c,x-25,y+4,x+25,y+7,1.5f,0xFFE2C477);} drawNavIcon(c,i,x,y+21,col); text(c,n[i],x,y+44,9.2f,col,Paint.Align.CENTER,i==tab);}
  }
  void drawNavIcon(Canvas c,int i,float x,float cy,int col){
    p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.7f); p.setStrokeCap(Paint.Cap.ROUND);
    if(i==0){ // calendar
      RectF r=new RectF(x-8,cy-7,x+8,cy+7); c.drawRoundRect(r,2.5f,2.5f,p); c.drawLine(x-8,cy-2,x+8,cy-2,p); c.drawLine(x-4,cy-9,x-4,cy-5,p); c.drawLine(x+4,cy-9,x+4,cy-5,p);
    } else if(i==1){ // today / timer
      c.drawCircle(x,cy,8,p); c.drawLine(x,cy,x,cy-5,p); c.drawLine(x,cy,x+4,cy+2,p); c.drawLine(x-3,cy-10,x+3,cy-10,p);
    } else if(i==2){ // orders / document
      RectF r=new RectF(x-7,cy-9,x+7,cy+9); c.drawRoundRect(r,2,2,p); c.drawLine(x+2,cy-9,x+7,cy-4,p); c.drawLine(x+2,cy-9,x+2,cy-4,p); c.drawLine(x+2,cy-4,x+7,cy-4,p); c.drawLine(x-4,cy,x+4,cy,p); c.drawLine(x-4,cy+4,x+4,cy+4,p);
    } else if(i==3){ // statistics
      c.drawLine(x-8,cy+8,x+8,cy+8,p); c.drawRect(x-7,cy+1,x-4,cy+8,p); c.drawRect(x-1,cy-4,x+2,cy+8,p); c.drawRect(x+5,cy-8,x+8,cy+8,p);
    } else { // more
      p.setStyle(Paint.Style.FILL); c.drawCircle(x-7,cy,1.8f,p); c.drawCircle(x,cy,1.8f,p); c.drawCircle(x+7,cy,1.8f,p);
    }
    p.setStyle(Paint.Style.FILL); p.setStrokeCap(Paint.Cap.BUTT);
  }
  void recalcProofreading(){proofreadingOpen=0;proofreadingDone=0;for(int i=0;i<proofreadingCount;i++){if(proofreadingCompleted[i])proofreadingDone++;else proofreadingOpen++;}}
  LinearLayout proofreadingEditor(int idx, EditText name, Spinner orderSpinner, EditText note){ LinearLayout box=new LinearLayout(getContext());box.setOrientation(LinearLayout.VERTICAL);int pad=(int)(18*getResources().getDisplayMetrics().density);box.setPadding(pad,8,pad,0);name.setHint("תיאור ההגהה / התיקון");name.setTextDirection(TEXT_DIRECTION_RTL);box.addView(name);String[] choices=new String[orderCount+1];choices[0]="ללא שיוך להזמנה";for(int i=0;i<orderCount;i++)choices[i]=orderNames[i];orderSpinner.setAdapter(new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_dropdown_item,choices));int oi=idx>=0?proofreadingOrderIndex[idx]:activeOrder;orderSpinner.setSelection(oi>=0&&oi<orderCount?oi+1:0);box.addView(orderSpinner);note.setHint("הערה (אופציונלי)");note.setTextDirection(TEXT_DIRECTION_RTL);if(idx>=0)note.setText(proofreadingNotes[idx]);box.addView(note);return box;}
  void addProofreadingDialog(){if(proofreadingCount>=8)return;final EditText name=new EditText(getContext());final Spinner os=new Spinner(getContext());final EditText note=new EditText(getContext());LinearLayout box=proofreadingEditor(-1,name,os,note);new AlertDialog.Builder(getContext()).setTitle("הוספת הגהה").setView(box).setNegativeButton("ביטול",null).setPositiveButton("הוספה",(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty()){int i=proofreadingCount;proofreadingNames[i]=n;proofreadingCompleted[i]=false;proofreadingOrderIndex[i]=os.getSelectedItemPosition()-1;proofreadingDateEpoch[i]=System.currentTimeMillis();proofreadingNotes[i]=note.getText().toString().trim();proofreadingCount++;recalcProofreading();saveState();invalidate();}}).show();}
  void deleteProofreadingConfirmed(final int idx){new AlertDialog.Builder(getContext()).setTitle("מחיקת הגהה").setMessage("למחוק את הרשומה הזו?").setNegativeButton("ביטול",null).setPositiveButton("מחק",(d,w)->{for(int i=idx;i<proofreadingCount-1;i++){proofreadingNames[i]=proofreadingNames[i+1];proofreadingCompleted[i]=proofreadingCompleted[i+1];proofreadingOrderIndex[i]=proofreadingOrderIndex[i+1];proofreadingDateEpoch[i]=proofreadingDateEpoch[i+1];proofreadingNotes[i]=proofreadingNotes[i+1];}proofreadingCount--;proofreadingNames[proofreadingCount]="";proofreadingCompleted[proofreadingCount]=false;proofreadingOrderIndex[proofreadingCount]=-1;proofreadingDateEpoch[proofreadingCount]=0L;proofreadingNotes[proofreadingCount]="";recalcProofreading();saveState();invalidate();}).show();}
  void editProofreadingDialog(final int idx){if(idx<0||idx>=proofreadingCount)return;final EditText name=new EditText(getContext());name.setText(proofreadingNames[idx]);final Spinner os=new Spinner(getContext());final EditText note=new EditText(getContext());LinearLayout box=proofreadingEditor(idx,name,os,note);String action=proofreadingCompleted[idx]?"סמן כפתוח":"סמן כהושלם";new AlertDialog.Builder(getContext()).setTitle("עדכון הגהה").setView(box).setNeutralButton("מחיקה",(d,w)->deleteProofreadingConfirmed(idx)).setNegativeButton("שמירה",(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty())proofreadingNames[idx]=n;proofreadingOrderIndex[idx]=os.getSelectedItemPosition()-1;proofreadingNotes[idx]=note.getText().toString().trim();recalcProofreading();saveState();invalidate();}).setPositiveButton(action,(d,w)->{String n=name.getText().toString().trim();if(!n.isEmpty())proofreadingNames[idx]=n;proofreadingOrderIndex[idx]=os.getSelectedItemPosition()-1;proofreadingNotes[idx]=note.getText().toString().trim();proofreadingCompleted[idx]=!proofreadingCompleted[idx];if(proofreadingDateEpoch[idx]<=0)proofreadingDateEpoch[idx]=System.currentTimeMillis();recalcProofreading();saveState();invalidate();}).show();}
  String expenseDateText(long epoch){ if(epoch<=0)return "ללא תאריך"; Calendar c=Calendar.getInstance();c.setTimeInMillis(epoch);return String.format(Locale.US,"%02d/%02d/%04d",c.get(Calendar.DAY_OF_MONTH),c.get(Calendar.MONTH)+1,c.get(Calendar.YEAR)); }

  void addExpenseDialog(){
    if(expenseCount>=8)return; int idx=expenseCount; expenseNames[idx]="הוצאה חדשה"; expenseAmounts[idx]=0; expensePaid[idx]=false; expenseRecurring[idx]=false; expenseDateEpoch[idx]=System.currentTimeMillis(); expenseCount++; expensePage=(expenseCount-1)/4; saveState(); editExpenseDialog(idx); invalidate();
  }
  void deleteExpenseConfirmed(final int idx){
    if(idx<0||idx>=expenseCount)return; new AlertDialog.Builder(getContext()).setTitle("מחיקת הוצאה").setMessage("למחוק את ההוצאה הזו?").setNegativeButton("ביטול",null).setPositiveButton("מחק",(d,w)->{for(int i=idx;i<expenseCount-1;i++){expenseNames[i]=expenseNames[i+1];expenseAmounts[i]=expenseAmounts[i+1];expensePaid[i]=expensePaid[i+1];expenseRecurring[i]=expenseRecurring[i+1];expenseDateEpoch[i]=expenseDateEpoch[i+1];}expenseCount--;expenseNames[expenseCount]="";expenseAmounts[expenseCount]=0;expensePaid[expenseCount]=false;expenseRecurring[expenseCount]=false;expenseDateEpoch[expenseCount]=0L;if(expensePage>0&&expenseCount<=4)expensePage=0;recalcMonthlyExpenses();saveState();invalidate();}).show();
  }

  void editExpenseDialog(final int idx){
    if(idx<0||idx>=expenseCount)return;
    LinearLayout box=new LinearLayout(getContext()); box.setOrientation(LinearLayout.VERTICAL); int pad=(int)(18*getResources().getDisplayMetrics().density); box.setPadding(pad,pad/2,pad,pad/2);
    final EditText name=new EditText(getContext()); name.setText(expenseNames[idx]); name.setHint("שם ההוצאה"); box.addView(name);
    final EditText amount=new EditText(getContext()); amount.setText(String.valueOf(expenseAmounts[idx])); amount.setHint("סכום"); amount.setInputType(InputType.TYPE_CLASS_NUMBER); amount.setSelectAllOnFocus(true); box.addView(amount);
    final android.widget.CheckBox paid=new android.widget.CheckBox(getContext()); paid.setText("שולם החודש"); paid.setChecked(expensePaid[idx]); box.addView(paid);
    final android.widget.CheckBox recurring=new android.widget.CheckBox(getContext()); recurring.setText("הוצאה קבועה / חוזרת"); recurring.setChecked(expenseRecurring[idx]); box.addView(recurring);
    final long[] chosenDate={expenseDateEpoch[idx]}; final android.widget.Button dateButton=new android.widget.Button(getContext()); dateButton.setText("תאריך ההוצאה: "+expenseDateText(chosenDate[0])); box.addView(dateButton); dateButton.setOnClickListener(v->{Calendar dc=Calendar.getInstance();if(chosenDate[0]>0)dc.setTimeInMillis(chosenDate[0]);new DatePickerDialog(getContext(),(view,year,month,day)->{Calendar picked=Calendar.getInstance();picked.set(year,month,day,12,0,0);picked.set(Calendar.MILLISECOND,0);chosenDate[0]=picked.getTimeInMillis();dateButton.setText("תאריך ההוצאה: "+expenseDateText(chosenDate[0]));},dc.get(Calendar.YEAR),dc.get(Calendar.MONTH),dc.get(Calendar.DAY_OF_MONTH)).show();});
    final android.widget.Button deleteButton=new android.widget.Button(getContext()); deleteButton.setText("מחק הוצאה"); box.addView(deleteButton);
    final AlertDialog dialog=new AlertDialog.Builder(getContext()).setTitle("עריכת הוצאה").setView(box).setNeutralButton("ללא תאריך",(d,w)->{expenseDateEpoch[idx]=0L;recalcMonthlyExpenses();saveState();invalidate();}).setNegativeButton("ביטול",null).setPositiveButton("שמירה",(d,w)->{
      String n=name.getText().toString().trim(); if(!n.isEmpty()) expenseNames[idx]=n; try{expenseAmounts[idx]=Math.max(0,Integer.parseInt(amount.getText().toString().trim()));}catch(Exception ignored){} expensePaid[idx]=paid.isChecked(); expenseRecurring[idx]=recurring.isChecked(); expenseDateEpoch[idx]=chosenDate[0]; recalcMonthlyExpenses(); saveState(); invalidate();
    }).create();
    deleteButton.setOnClickListener(v->{dialog.dismiss();deleteExpenseConfirmed(idx);});
    dialog.show();
  }

  void editMonthlyExpensesDialog(){
    final EditText amount=new EditText(getContext()); amount.setText(String.valueOf(monthlyExpenses)); amount.setHint("סך הוצאות צפויות לחודש"); amount.setInputType(InputType.TYPE_CLASS_NUMBER); amount.setSelectAllOnFocus(true);
    new AlertDialog.Builder(getContext()).setTitle("הוצאות חודשיות").setMessage("הזן את סך ההוצאות הצפויות לחודש").setView(amount).setNegativeButton("ביטול",null).setPositiveButton("שמירה",(d,w)->{
      try{monthlyExpenses=Math.max(0,Integer.parseInt(amount.getText().toString().trim()));}catch(Exception ignored){}
      saveState(); invalidate();
    }).show();
  }

  String dateText(long epoch){ if(epoch<=0)return "טרם נקבע"; Calendar c=Calendar.getInstance(); c.setTimeInMillis(epoch); return String.format(java.util.Locale.US,"%02d/%02d/%04d",c.get(Calendar.DAY_OF_MONTH),c.get(Calendar.MONTH)+1,c.get(Calendar.YEAR)); }

  void chooseOrderStartDate(){ Calendar c=Calendar.getInstance(); if(orderStartEpochs[activeOrder]>0)c.setTimeInMillis(orderStartEpochs[activeOrder]); new DatePickerDialog(getContext(),(v,yy,mm,dd)->{Calendar st=Calendar.getInstance();st.set(yy,mm,dd,12,0,0);st.set(Calendar.MILLISECOND,0);orderStartEpochs[activeOrder]=st.getTimeInMillis();saveState();invalidate();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show(); }

  void editOrderDialog(){
    final EditText name=new EditText(getContext()); name.setText(orderName); name.setHint("שם ההזמנה"); name.setTextDirection(TEXT_DIRECTION_RTL);
    final EditText customer=new EditText(getContext()); customer.setText(orderCustomers[activeOrder]); customer.setHint("שם הלקוח"); customer.setTextDirection(TEXT_DIRECTION_RTL);
    final Spinner type=new Spinner(getContext()); String[] typeOptions={"ספר תורה","תפילין","מזוזות","מגילה"}; ArrayAdapter<String> typeAdapter=new ArrayAdapter<>(getContext(),android.R.layout.simple_spinner_dropdown_item,typeOptions); type.setAdapter(typeAdapter); int typePos=1; for(int ti=0;ti<typeOptions.length;ti++)if(typeOptions[ti].equals(orderTypes[activeOrder]))typePos=ti; type.setSelection(typePos);
    final EditText target=new EditText(getContext()); target.setText(String.valueOf(orderTargets[activeOrder])); target.setHint("יעד יחידות / שורות"); target.setInputType(InputType.TYPE_CLASS_NUMBER);
    final EditText actual=new EditText(getContext()); actual.setText(String.valueOf(orderActualUnits[activeOrder])); actual.setHint("הספק בפועל"); actual.setInputType(InputType.TYPE_CLASS_NUMBER);
    final EditText price=new EditText(getContext()); price.setText(String.valueOf(orderPrice)); price.setHint("מחיר"); price.setInputType(InputType.TYPE_CLASS_NUMBER);
    final EditText paid=new EditText(getContext()); paid.setText(String.valueOf(orderPaid)); paid.setHint("שולם"); paid.setInputType(InputType.TYPE_CLASS_NUMBER);
    final long[] paidDate={orderPaidEpochs[activeOrder]}; final android.widget.Button paidDateButton=new android.widget.Button(getContext()); paidDateButton.setText("תאריך תקבול: "+expenseDateText(paidDate[0])); paidDateButton.setOnClickListener(v->{Calendar dc=Calendar.getInstance();if(paidDate[0]>0)dc.setTimeInMillis(paidDate[0]);new DatePickerDialog(getContext(),(view,year,month,day)->{Calendar picked=Calendar.getInstance();picked.set(year,month,day,12,0,0);picked.set(Calendar.MILLISECOND,0);paidDate[0]=picked.getTimeInMillis();paidDateButton.setText("תאריך תקבול: "+expenseDateText(paidDate[0]));},dc.get(Calendar.YEAR),dc.get(Calendar.MONTH),dc.get(Calendar.DAY_OF_MONTH)).show();});
    final EditText profit=new EditText(getContext()); profit.setText(String.valueOf(orderExpectedProfits[activeOrder])); profit.setHint("רווח צפוי"); profit.setInputType(InputType.TYPE_CLASS_NUMBER);
    LinearLayout box=new LinearLayout(getContext()); box.setOrientation(LinearLayout.VERTICAL); int pad=(int)(20*getResources().getDisplayMetrics().density); box.setPadding(pad,8,pad,0); box.addView(name); box.addView(customer); box.addView(type); box.addView(target); box.addView(actual); box.addView(price); box.addView(paid); box.addView(paidDateButton); box.addView(profit);
    new AlertDialog.Builder(getContext()).setTitle("עריכת פרטי הזמנה").setView(box).setNegativeButton("ביטול",null).setPositiveButton("שמירה",(d,w)->{
      String n=name.getText().toString().trim(); if(n.length()>0) orderName=n;
      String cust=customer.getText().toString().trim(); orderCustomers[activeOrder]=cust;
      orderTypes[activeOrder]=String.valueOf(type.getSelectedItem());
      try{orderTargets[activeOrder]=Math.max(0,Integer.parseInt(target.getText().toString().trim()));}catch(Exception ignored){}
      try{orderActualUnits[activeOrder]=Math.max(0,Integer.parseInt(actual.getText().toString().trim()));}catch(Exception ignored){}
      if(orderTargets[activeOrder]>0) orderProgress=Math.min(100,Math.round(orderActualUnits[activeOrder]*100f/orderTargets[activeOrder]));
      try{orderPrice=Math.max(0,Integer.parseInt(price.getText().toString().trim()));}catch(Exception ignored){}
      try{orderPaid=Math.max(0,Math.min(orderPrice,Integer.parseInt(paid.getText().toString().trim())));}catch(Exception ignored){} if(orderPaid>0){orderPaidEpochs[activeOrder]=paidDate[0]>0?paidDate[0]:System.currentTimeMillis();}else orderPaidEpochs[activeOrder]=0L;
      try{orderExpectedProfits[activeOrder]=Math.max(0,Integer.parseInt(profit.getText().toString().trim()));}catch(Exception ignored){}
      syncActiveOrderBack(); saveState(); invalidate();
    }).show();
  }
  LinearLayout notebookEditor(int idx, EditText input, EditText place, Spinner orderSpinner){ LinearLayout box=new LinearLayout(getContext());box.setOrientation(LinearLayout.VERTICAL);int pad=(int)(18*getResources().getDisplayMetrics().density);box.setPadding(pad,8,pad,0);place.setHint("מקום כתיבה – פרשה / עמוד / שורה");place.setTextDirection(TEXT_DIRECTION_RTL);if(idx>=0)place.setText(notebookPlaces[idx]);box.addView(place);input.setHint("הערה / תזכורת");input.setSingleLine(false);input.setMinLines(3);input.setGravity(Gravity.RIGHT|Gravity.TOP);box.addView(input);String[] choices=new String[orderCount+1];choices[0]="ללא שיוך להזמנה";for(int i=0;i<orderCount;i++)choices[i]=orderNames[i];orderSpinner.setAdapter(new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_dropdown_item,choices));int oi=idx>=0?notebookOrderIndex[idx]:activeOrder;orderSpinner.setSelection(oi>=0&&oi<orderCount?oi+1:0);box.addView(orderSpinner);return box; }
  void addNotebookDialog(){
    if(notebookCount>=8){android.widget.Toast.makeText(getContext(),"ניתן לשמור עד 8 הערות בגרסה זו",android.widget.Toast.LENGTH_SHORT).show();return;}
    final EditText input=new EditText(getContext()); final EditText place=new EditText(getContext()); final Spinner os=new Spinner(getContext()); LinearLayout box=notebookEditor(-1,input,place,os);
    new AlertDialog.Builder(getContext()).setTitle("רשומה חדשה").setView(box).setPositiveButton("שמור",(d,w)->{String v=input.getText().toString().trim();String pl=place.getText().toString().trim();if(!v.isEmpty()||!pl.isEmpty()){int i=notebookCount++;notebookTexts[i]=v.isEmpty()?"מקום כתיבה":v;notebookPlaces[i]=pl;notebookOrderIndex[i]=os.getSelectedItemPosition()-1;notebookDateEpoch[i]=System.currentTimeMillis();notebookNotes=notebookCount;saveState();invalidate();}}).setNegativeButton("ביטול",null).show();
  }
  void deleteNotebookConfirmed(final int i){ new AlertDialog.Builder(getContext()).setTitle("מחיקת רשומה").setMessage("למחוק את הרשומה ממחברת הסופר?").setNegativeButton("ביטול",null).setPositiveButton("מחק",(d,w)->{for(int n=i;n<notebookCount-1;n++){notebookTexts[n]=notebookTexts[n+1];notebookPlaces[n]=notebookPlaces[n+1];notebookOrderIndex[n]=notebookOrderIndex[n+1];notebookDateEpoch[n]=notebookDateEpoch[n+1];}int last=Math.max(0,notebookCount-1);notebookTexts[last]="";notebookPlaces[last]="";notebookOrderIndex[last]=-1;notebookDateEpoch[last]=0L;notebookCount--;notebookNotes=notebookCount;saveState();invalidate();}).show(); }
  void editNotebookDialog(int i){
    if(i<0||i>=notebookCount)return; final EditText input=new EditText(getContext()); input.setText(notebookTexts[i]); input.setSelection(input.length()); final EditText place=new EditText(getContext()); final Spinner os=new Spinner(getContext()); LinearLayout box=notebookEditor(i,input,place,os);
    new AlertDialog.Builder(getContext()).setTitle("עריכת רשומה").setView(box).setPositiveButton("שמור",(d,w)->{String v=input.getText().toString().trim();String pl=place.getText().toString().trim();if(!v.isEmpty()||!pl.isEmpty()){notebookTexts[i]=v.isEmpty()?"מקום כתיבה":v;notebookPlaces[i]=pl;notebookOrderIndex[i]=os.getSelectedItemPosition()-1;if(notebookDateEpoch[i]<=0)notebookDateEpoch[i]=System.currentTimeMillis();saveState();invalidate();}}).setNeutralButton("מחק",(d,w)->deleteNotebookConfirmed(i)).setNegativeButton("ביטול",null).show();
  }

  String goalDueText(){ Calendar c=Calendar.getInstance(); c.setTimeInMillis(goalDueEpoch); return String.format(Locale.US,"%02d/%02d/%04d",c.get(Calendar.DAY_OF_MONTH),c.get(Calendar.MONTH)+1,c.get(Calendar.YEAR)); }
  long goalPlanningStartEpoch(){ return Math.max(startOfTodayEpoch(),goalStartEpoch); }
  int goalWorkDaysUntilDue(){ return goalWorkDaysBetween(goalPlanningStartEpoch(),goalDueEpoch); }
  long goalDueForPace(int remaining,int pace){
    int needed=(int)Math.ceil(Math.max(0,remaining)/(double)Math.max(1,pace));
    Calendar d=Calendar.getInstance(); d.setTimeInMillis(goalPlanningStartEpoch()); d.set(Calendar.HOUR_OF_DAY,12);d.set(Calendar.MINUTE,0);d.set(Calendar.SECOND,0);d.set(Calendar.MILLISECOND,0);
    if(needed<=0)return d.getTimeInMillis();
    int added=0, guard=0; while(added<needed && guard<7500){ if(writingWorkDay(d))added++; if(added<needed)d.add(Calendar.DAY_OF_MONTH,1); guard++; }
    return d.getTimeInMillis();
  }
  void editGoalPlanDialog(){
    android.widget.LinearLayout box=new android.widget.LinearLayout(getContext()); box.setOrientation(android.widget.LinearLayout.VERTICAL); int pad=(int)(18*getResources().getDisplayMetrics().density); box.setPadding(pad,pad/2,pad,pad/2);
    android.widget.EditText target=new android.widget.EditText(getContext()); target.setHint("כמות יעד בשורות"); target.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); target.setText(String.valueOf(goalTarget)); box.addView(target);
    android.widget.EditText pace=new android.widget.EditText(getContext()); pace.setHint("קצב יומי בשורות"); pace.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); pace.setText(String.valueOf(goalDailyPace)); box.addView(pace);
    new AlertDialog.Builder(getContext()).setTitle("עריכת היעד").setView(box).setNegativeButton("ביטול",null).setPositiveButton("שמור",(d,w)->{ try{ int newTarget=Integer.parseInt(target.getText().toString().trim()); int newPace=Integer.parseInt(pace.getText().toString().trim()); if(newTarget<1||newPace<1)throw new Exception(); goalTarget=newTarget; goalDailyPace=newPace; goalDone=goalProgressLines(); saveState(); invalidate(); }catch(Exception ex){ Toast.makeText(getContext(),"יש להזין מספרים גדולים מאפס",Toast.LENGTH_SHORT).show(); } }).show();
  }
  void chooseDefaultStartTime(){
    int hour=Math.max(0,Math.min(23,startMinutes/60)), minute=Math.max(0,Math.min(59,startMinutes%60));
    android.app.TimePickerDialog dlg=new android.app.TimePickerDialog(getContext(),(v,hourOfDay,minuteOfHour)->{
      startMinutes=hourOfDay*60+minuteOfHour; saveState(); invalidate();
    },hour,minute,true);
    dlg.setTitle("שעת התחלה ברירת מחדל"); dlg.show();
  }
  void editScheduleMinutes(final int field){
    final int current=field==0?cycleMinutes:(field==1?breakMinutes:longBreakMinutes);
    final EditText input=new EditText(getContext()); input.setInputType(InputType.TYPE_CLASS_NUMBER); input.setText(String.valueOf(current)); input.setSelectAllOnFocus(true);
    String title=field==0?"משך מחזור כתיבה":(field==1?"משך הפסקה רגילה":"משך הפסקה ארוכה");
    new AlertDialog.Builder(getContext()).setTitle(title).setMessage("הזן מספר דקות").setView(input).setNegativeButton("ביטול",null).setPositiveButton("שמור",(d,w)->{
      try{
        int value=Integer.parseInt(input.getText().toString().trim());
        int min=field==0?10:(field==1?5:15), max=field==0?120:(field==1?60:180);
        if(value<min||value>max){ android.widget.Toast.makeText(getContext(),"הערך צריך להיות בין "+min+" ל־"+max+" דקות",android.widget.Toast.LENGTH_LONG).show(); return; }
        if(field==0)cycleMinutes=value; else if(field==1)breakMinutes=value; else longBreakMinutes=value;
        if(!running&&!timerFinished) timerMs=phaseDurationMs();
        saveState(); invalidate();
      }catch(Exception ex){ android.widget.Toast.makeText(getContext(),"יש להזין מספר דקות תקין",android.widget.Toast.LENGTH_SHORT).show(); }
    }).show();
  }

  void chooseGoalStartDate(){ Calendar cal=Calendar.getInstance();cal.setTimeInMillis(goalStartEpoch); DatePickerDialog dlg=new DatePickerDialog(getContext(),(v,yy,mm,dd)->{Calendar d=Calendar.getInstance();d.set(yy,mm,dd,12,0,0);d.set(Calendar.MILLISECOND,0);long candidate=d.getTimeInMillis();if(candidate>goalDueEpoch){new AlertDialog.Builder(getContext()).setTitle("תאריך התחלה לא תקין").setMessage("תאריך ההתחלה חייב להיות לפני תאריך היעד.").setPositiveButton("אישור",null).show();return;}goalStartEpoch=candidate;goalDone=goalProgressLines();int remaining=Math.max(0,goalTarget-goalDone);goalDailyPace=Math.max(1,(int)Math.ceil(remaining/(double)goalWorkDaysUntilDue()));saveState();invalidate();},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));dlg.setTitle("בחירת תאריך התחלה");dlg.show(); }
  void chooseGoalDueDate(){ Calendar cal=Calendar.getInstance();cal.setTimeInMillis(goalDueEpoch); DatePickerDialog dlg=new DatePickerDialog(getContext(),(v,yy,mm,dd)->{Calendar d=Calendar.getInstance();d.set(yy,mm,dd,12,0,0);d.set(Calendar.MILLISECOND,0);long candidate=d.getTimeInMillis();if(candidate<goalStartEpoch){new AlertDialog.Builder(getContext()).setTitle("תאריך יעד לא תקין").setMessage("תאריך היעד חייב להיות אחרי תאריך ההתחלה.").setPositiveButton("אישור",null).show();return;}goalDueEpoch=candidate;goalDone=goalProgressLines();int remaining=Math.max(0,goalTarget-goalDone);goalDailyPace=Math.max(1,(int)Math.ceil(remaining/(double)goalWorkDaysUntilDue()));goalYears=Math.max(1,Math.min(20,(int)Math.ceil(goalWorkDaysBetween(goalStartEpoch,goalDueEpoch)/260.0)));saveState();invalidate();},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)); dlg.setTitle("בחירת תאריך יעד");dlg.show(); }
  void chooseOrderDueDate(){
    Calendar cal=Calendar.getInstance();
    DatePickerDialog dlg=new DatePickerDialog(getContext(),(v,yy,mm,dd)->{
      Calendar due=Calendar.getInstance(); due.set(yy,mm,dd,12,0,0); due.set(Calendar.MILLISECOND,0); orderDueEpochs[activeOrder]=due.getTimeInMillis(); orderDue=String.format(java.util.Locale.US,"%02d/%02d/%04d",dd,mm+1,yy); syncActiveOrderBack(); saveState(); invalidate();
    },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));
    dlg.setTitle("בחירת תאריך מסירה"); dlg.show();
  }
  @Override public boolean onTouchEvent(android.view.MotionEvent e){
    if(e.getAction()!=MotionEvent.ACTION_UP)return true; float sc=designScale(); float x=e.getX()/sc, y=e.getY()/sc;
    // back chevron on secondary screens
    if(screen>=5 && y<H()*.25f && x<75){ screen=(screen==5||screen==6||screen==9)?1:(screen==7?2:(screen==17?3:(screen==10||screen==11||screen==8||screen==12||screen==13||screen==14||screen==15||screen==16?4:tab))); invalidate(); return true; }
    if(y>H()-bottomH()){
      // Clamp the extreme screen edges into the five visible navigation cells.
      float cell=W()/5f; int i=(int)((W()-Math.max(0.001f,Math.min(W()-0.001f,x)))/cell);
      i=Math.max(0,Math.min(4,i)); tab=i;screen=i;invalidate();return true;
    }
    if(screen==0){
      float calY=contentTop()+68;
      if(y>=calY && y<=calY+58){ if(x<82){calendarOffset--;selectedCalendarDay=-1;invalidate();return true;} if(x>W()-82){calendarOffset++;selectedCalendarDay=-1;invalidate();return true;} }
      java.util.Calendar cal=shownMonth(); int firstCol=cal.get(java.util.Calendar.DAY_OF_WEEK)-1, days=cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH); float left=39,right=W()-39,col=(right-left)/6f;
      if(y>=calY+70 && y<=calY+252){ int r=(int)((y-(calY+72))/31f); int cc=Math.round((right-x)/col); int d=r*7+cc-firstCol+1; if(cc>=0&&cc<7&&d>=1&&d<=days){selectedCalendarDay=d;invalidate();return true;} }
      float todayCardTop=calY+300; if(y>=todayCardTop && y<=todayCardTop+143){ tab=1; screen=1; invalidate(); return true; }
    }
    if(screen==1){
      // Keep touch geometry tied to the exact composition used by day().
      float dayY=contentTop()+70;
      float startButtonY=dayY+125;
      if(y>=startButtonY && y<=startButtonY+50){
        if(actualStartMinutes<0) startTodayNow(); currentCycle=nextOpenCycle(); timerPhase=0; timerFinished=false; timerMs=cycleMinutes*60*1000L; saveState(); screen=5;invalidate();return true;
      }
      float progressY=startButtonY+67;
      float listTop=progressY+103;
      if(y>=listTop && y<=listTop+6*44){
        int ci=(int)((y-listTop)/44f); float within=(y-listTop)-ci*44f;
        if(ci>=0&&ci<Math.min(cycleCount,6)&&within<=36){currentCycle=ci;actualLines=cycleLines[ci];saveState();screen=6;invalidate();return true;}
      }
    }
    if(screen==5){ float timerCy=contentTop()+190; float timerButtonY=timerCy+137; if(y>timerButtonY-10 && y<timerButtonY+64){ if(running){ timerMs=Math.max(0,timerEndAt-System.currentTimeMillis()); running=false; timerEndAt=0L; h.removeCallbacks(tick); stopTimerService(); } else if(timerFinished){ if(timerPhase==0){ actualLines=cycleLines[Math.min(currentCycle,5)]; updateAfterTimedCycle=true; screen=6; } else { prepareNextWork(); } } else { if(timerMs<=0) timerMs=phaseDurationMs(); running=true; timerFinished=false; lastTick=System.currentTimeMillis(); timerEndAt=lastTick+timerMs; h.removeCallbacks(tick); h.post(tick); startTimerService(); } saveState();invalidate();return true;} }
    if(screen==6){ float top=contentTop()+85; if(y>top+65 && y<top+135){ if(x<W()/2) actualLines=Math.max(0,actualLines-1); else actualLines++; saveState(); invalidate(); return true; } if(y>top+250 && y<top+335){ cycleLines[Math.min(currentCycle,5)]=actualLines; cycleDone[Math.min(currentCycle,5)]=true; if(updateAfterTimedCycle){ updateAfterTimedCycle=false; if(currentCycle<5){ prepareBreak(); screen=5; } else { timerPhase=0; timerFinished=false; timerMs=cycleMinutes*60*1000L; dayReadyToClose=(completedCycles()==6); saveState(); screen=9; } } else { saveState(); screen=1; } invalidate(); return true; } }
    if(screen==2){
      float ordersTop=contentTop()+72;
      if(y>=ordersTop && y<=ordersTop+48){
        if(orderCount<8){int i=orderCount++; orderNames[i]="הזמנה חדשה "+orderCount; orderDues[i]="טרם נקבע"; orderProgresses[i]=0; orderPrices[i]=0; orderPaids[i]=0; orderPaidEpochs[i]=0L; orderTypes[i]="תפילין"; orderCustomers[i]=""; orderDueEpochs[i]=0L; orderStartEpochs[i]=System.currentTimeMillis(); orderExpectedProfits[i]=0; orderTargets[i]=0; orderActualUnits[i]=0; activeOrder=i; syncActiveOrder(); saveState(); screen=7; invalidate(); return true;}
      }
      float first=ordersTop+65; int pageCount=Math.max(1,(orderCount+3)/4); ordersPage=Math.max(0,Math.min(pageCount-1,ordersPage));
      if(y>=first && y<first+4*112){int row=(int)((y-first)/112f); float within=(y-first)-row*112f; int idx=ordersPage*4+row; if(idx>=0&&idx<orderCount && within>=0 && within<=96){activeOrder=idx;syncActiveOrder();saveState();screen=7;invalidate();return true;}}
      float pagerY=Math.min(H()-bottomH()-27,first+4*112+4); if(pageCount>1 && y>=pagerY-24 && y<=pagerY+18){if(x<W()/3f)ordersPage=Math.max(0,ordersPage-1);else if(x>W()*2f/3f)ordersPage=Math.min(pageCount-1,ordersPage+1);invalidate();return true;}
    }
    if(screen==7){ float oy=contentTop()+80;
      // The delivery-date row opens a real Android date picker.
      if(y>=oy+90 && y<=oy+141){ chooseOrderDueDate(); return true; }
      if(y>oy+381 && y<oy+445){
        if(x<W()/2){ orderProgress=Math.min(100,orderProgress+5); if(orderTargets[activeOrder]>0) orderActualUnits[activeOrder]=Math.min(orderTargets[activeOrder],Math.round(orderTargets[activeOrder]*orderProgress/100f)); syncActiveOrderBack(); saveState(); invalidate(); return true; }
        else { editOrderDialog(); return true; }
      }
      if(y>oy+448 && y<oy+508){ if(orderCount>1){ new AlertDialog.Builder(getContext()).setTitle("מחיקת הזמנה").setMessage("למחוק את ההזמנה "+orderName+"?").setNegativeButton("ביטול",null).setPositiveButton("מחק",(d,w)->{ for(int i=activeOrder;i<orderCount-1;i++){orderNames[i]=orderNames[i+1];orderDues[i]=orderDues[i+1];orderProgresses[i]=orderProgresses[i+1];orderPrices[i]=orderPrices[i+1];orderPaids[i]=orderPaids[i+1];orderPaidEpochs[i]=orderPaidEpochs[i+1];orderTypes[i]=orderTypes[i+1];orderCustomers[i]=orderCustomers[i+1];orderDueEpochs[i]=orderDueEpochs[i+1];orderStartEpochs[i]=orderStartEpochs[i+1];orderExpectedProfits[i]=orderExpectedProfits[i+1];orderTargets[i]=orderTargets[i+1];orderActualUnits[i]=orderActualUnits[i+1];} for(int pi=0;pi<proofreadingCount;pi++){if(proofreadingOrderIndex[pi]==activeOrder)proofreadingOrderIndex[pi]=-1;else if(proofreadingOrderIndex[pi]>activeOrder)proofreadingOrderIndex[pi]--;} for(int ni=0;ni<notebookCount;ni++){if(notebookOrderIndex[ni]==activeOrder)notebookOrderIndex[ni]=-1;else if(notebookOrderIndex[ni]>activeOrder)notebookOrderIndex[ni]--;} int last=orderCount-1;orderNames[last]="";orderDues[last]="";orderProgresses[last]=0;orderPrices[last]=0;orderPaids[last]=0;orderPaidEpochs[last]=0L;orderTypes[last]="תפילין";orderCustomers[last]="";orderDueEpochs[last]=0L;orderStartEpochs[last]=0L;orderExpectedProfits[last]=0;orderTargets[last]=0;orderActualUnits[last]=0;orderCount--;activeOrder=Math.max(0,Math.min(activeOrder,orderCount-1));syncActiveOrder();saveState();screen=2;invalidate();}); return true;} }
    }
    if(screen==9){ float sy=contentTop()+78; if(y>sy+285 && y<sy+380){ finishDay(); invalidate(); return true; } }
    if(screen==3){ float dy=contentTop()+74; float sy=dy+126; if(y>=sy+252 && y<=sy+324){reportMonthOffset=0;screen=17;invalidate();return true;} }
    if(screen==17){ float rt=contentTop(); if(y>=rt+35&&y<=rt+82){ if(x<W()/3f){reportMonthOffset--;invalidate();return true;} if(x>W()*2f/3f){reportMonthOffset++;invalidate();return true;} if(reportMonthOffset!=0){reportMonthOffset=0;invalidate();return true;} } }
    if(screen==4){
      // Match the 43px cards on their 52px rhythm; taps in the visual gaps do nothing.
      float top=contentTop()+70;
      if(y>=top && y<top+8*52f){int row=(int)((y-top)/52f);float within=(y-top)-row*52f;if(within<=43){if(row==0)screen=10;else if(row==1)screen=11;else if(row==2)screen=13;else if(row==3)screen=8;else if(row==4)screen=12;else if(row==5)screen=14;else if(row==6)screen=16;else if(row==7)screen=15;invalidate();return true;}}
    }
    if(screen==10){ float wt=contentTop(); if(y>=wt+35&&y<=wt+76){if(x<95){weeklyOffset--;invalidate();return true;}if(x>W()-95){weeklyOffset++;invalidate();return true;}if(weeklyOffset!=0&&x>95&&x<W()-95){weeklyOffset=0;invalidate();return true;}} float wy=wt+96; if(y>=wy && y<wy+300){int wi=(int)((y-wy)/60f);float within=(y-wy)-wi*60f;if(wi>=0&&wi<5&&within<=51){Calendar wd=weekDayCalendar(wi);if(!writingWorkDay(wd)){android.widget.Toast.makeText(getContext(),jewishHoliday(wd)+" – יום ללא כתיבה",android.widget.Toast.LENGTH_SHORT).show();return true;}editWeeklyDayDialog(wi);return true;}} }
    if(screen==11){ float ny=contentTop()+72; if(y>ny && y<ny+50){addNotebookDialog();return true;} int pages=Math.max(1,(notebookCount+3)/4);float first=ny+55;if(y>=first&&y<first+4*45f){int local=(int)((y-first)/45f);float within=(y-first)-local*45f;int ni=notebookPage*4+local;if(ni>=0&&ni<notebookCount&&within<=39){editNotebookDialog(ni);return true;}}float py=ny+250;if(pages>1&&y>py-28&&y<py+18){if(x<W()/2f)notebookPage=Math.min(pages-1,notebookPage+1);else notebookPage=Math.max(0,notebookPage-1);invalidate();return true;} }
    if(screen==13){ float py=contentTop()+78, listY=py+105, rowH=48;int pages=Math.max(1,(proofreadingCount+3)/4);if(y>=listY&&y<listY+4*rowH){int local=(int)((y-listY)/rowH);float within=(y-listY)-local*rowH;int pi=proofreadingPage*4+local;if(pi>=0&&pi<proofreadingCount&&within<=41){editProofreadingDialog(pi);return true;}}float navY=listY+205;if(pages>1&&y>navY-28&&y<navY+18){if(x<W()/2f)proofreadingPage=Math.min(pages-1,proofreadingPage+1);else proofreadingPage=Math.max(0,proofreadingPage-1);invalidate();return true;}float add=Math.min(H()-bottomH()-71,listY+245);if(y>=add&&y<add+49&&proofreadingCount<8){addProofreadingDialog();return true;} }
    if(screen==12){ float fy=contentTop()+76; if(y>=fy-4&&y<=fy+34){if(x<W()/3f){financeMonthOffset--;invalidate();return true;}if(x>W()*2f/3f){financeMonthOffset++;invalidate();return true;}} float first=fy+324;if(y>=first&&y<first+4*49){int row=(int)((y-first)/49f);float within=(y-first)-row*49f;int ei=expensePage*4+row;if(ei>=0&&ei<expenseCount&&within<=41){editExpenseDialog(ei);return true;}} if(expenseCount>4&&y>=fy+510&&y<=fy+540){expensePage=1-expensePage;invalidate();return true;} if(expenseCount<8&&y>=fy+540&&y<=fy+565){addExpenseDialog();return true;} }

    if(screen==14){ float gy=contentTop()+78; if(y>gy && y<gy+145){ if(x>W()/2f) chooseGoalStartDate(); else chooseGoalDueDate(); return true;} if(y>gy+165 && y<gy+285){ editGoalPlanDialog(); return true; } if(y>gy+295 && y<gy+400){ goalRecalcMode=1-goalRecalcMode; saveState(); invalidate(); return true; } if(y>gy+400 && y<gy+480){ goalDone=goalProgressLines(); int remaining=Math.max(0,goalTarget-goalDone); if(goalRecalcMode==0){ int workDays=goalWorkDaysUntilDue(); goalDailyPace=Math.max(1,(int)Math.ceil(remaining/(double)workDays)); } else { int pace=Math.max(1,goalDailyPace); goalDueEpoch=goalDueForPace(remaining,pace); goalYears=Math.max(1,Math.min(20,(int)Math.ceil(goalWorkDaysBetween(goalPlanningStartEpoch(),goalDueEpoch)/260.0))); } saveState(); invalidate(); return true; } }
    if(screen==15){
      // Keep touch geometry identical to the four visible backup buttons.
      float by=contentTop()+84;
      if(y>=by+155 && y<=by+208){ createFullBackup(); invalidate(); return true; }
      if(y>=by+230 && y<=by+283){ if(backupExists){ restoreFullBackup(); invalidate(); } else android.widget.Toast.makeText(getContext(),"עדיין אין גיבוי מקומי לשחזור",android.widget.Toast.LENGTH_SHORT).show(); return true; }
      if(y>=by+305 && y<=by+358){ exportBackupFile(); return true; }
      if(y>=by+380 && y<=by+433){ chooseBackupFile(); return true; }
    }
    if(screen==16){float vy=contentTop()+70;for(int vi=0;vi<3;vi++){float ry=vy+vi*92;if(y>=ry&&y<ry+76){chooseVacationRange(vi);return true;}}}
    if(screen==8){
      // settings() draws five 58px cards on a 67px rhythm starting at contentTop()+75.
      // Use the same geometry here so every visible card activates the matching setting.
      float top=contentTop()+75;
      if(y>=top && y<top+5*67){
        int row=(int)((y-top)/67f); float within=(y-top)-row*67f;
        if(within<=58){
          if(row==0){ chooseDefaultStartTime(); return true; }
          else if(row==1){ android.widget.Toast.makeText(getContext(),"שעת הסיום מחושבת אוטומטית לפי 6 המחזורים וההפסקות",android.widget.Toast.LENGTH_SHORT).show(); return true; }
          else if(row==2){ editScheduleMinutes(0); return true; }
          else if(row==3){ editScheduleMinutes(1); return true; }
          else if(row==4){ editScheduleMinutes(2); return true; }
        }
      }
      float adaptiveTop=top+345;
      if(y>=adaptiveTop && y<=adaptiveTop+62){adaptive=!adaptive;saveState();invalidate();return true;}
    }
    return true;
  }
}
