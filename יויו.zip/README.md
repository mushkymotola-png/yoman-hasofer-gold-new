# v11.7.0 — Schedule Consistency & Import Safety
- Android metadata: versionCode 127 / versionName 11.7.0.
- Today screen now displays the configured writing-cycle duration instead of a hard-coded 40-minute label.
- Backup restore and text import clamp schedule values to safe ranges so malformed/legacy data cannot create invalid timer durations or clock values.
- Six-cycle structure remains fixed; configurable durations continue to drive timer and planned schedule calculations.

# v11.6 – Schedule Settings Integrity
- Schedule settings now use real editors instead of two-value toggles.
- Default start time uses a 24-hour time picker.
- Writing-cycle, regular-break, and long-break durations accept validated minute values.
- Six cycles remain fixed; planned finish remains derived from the schedule.
- Android metadata: versionCode 126 / versionName 11.6.0.

# v11.5 – Timer Alarm Lifecycle Integrity
- Timer completion alarm now has one owned tone/vibration lifecycle inside TimerService.
- Repeated completion calls first stop any previous alarm resources, preventing overlapping tone/vibration instances.
- Tone and vibration resources are explicitly cancelled/released when the service is destroyed and after the 10-second completion alert.
- Vibration is finite rather than an indefinitely repeating waveform.
- Android metadata: versionCode 125 / versionName 11.5.0.
- Source-level integrity checks only; APK compilation/device verification remains pending.

# v11.4.0 – Finance Expense Deletion Integrity
- Android metadata: versionCode 124 / versionName 11.4.0.
- Dynamic finance expenses can now be deleted directly from the expense editor.
- Deletion asks for confirmation, compacts all expense fields together, clears the vacated slot, recalculates the selected-month totals, persists state, and safely returns pagination to page 1 when needed.
- Clearing an expense date now also recalculates monthly totals immediately.
- Source-level integrity pass only; APK compilation and Galaxy S23 Ultra device verification are still pending.


## v11.3.0 — Backup Import Integrity
- Fixed a real import regression introduced by dynamic finance expenses: `expenseCount` was being mistaken for an indexed `expenseN` record, which could abort import with an invalid-number error.
- Expense import now accepts only numeric indexed keys (`expense0` … `expense7`) and handles `expenseCount` separately.
- Monthly expense totals are recalculated once after the complete import, so restored count/date/recurrence data is applied consistently.
- Android metadata: versionCode 123 / versionName 11.3.0.
# v10.9.0 — Notification Permission Integrity

- Requests Android 13+ notification permission at runtime, matching the existing manifest declaration.
- This closes a timer reliability gap: foreground timer notifications can now be authorized by the user instead of relying only on manifest metadata.
- Android 12 and older remain unchanged.
- versionCode 119 / versionName 10.9.0.

# v8.4 — Approved Design Consistency Pass

- Continued from v8.3 without resetting functionality or data model.
- Added reusable approved-design primitives: ornamental center rule, restrained navy/gold action buttons, section ornament, and status-pill foundation.
- Applied the shared action-button geometry to Today, End-of-Day Summary, Notebook, Vacations, and Goals so controls no longer drift visually between screens.
- Refined title separators to the approved thin antique-gold ornament language rather than generic horizontal rules.
- Deepened Finance hierarchy with an ornamental management section while keeping the cream/navy/antique-gold balance restrained.
- Added subtle detail consistency to the More screen.
- Target remains Galaxy S23 Ultra proportions. This is a source/layout pass; pixel-perfect fidelity still requires a real APK/device render comparison.

# v7.18 – Day State Backup Integrity

- Added dayReadyToClose to local backup and external export/import.
- New-day reset now always clears stale close-readiness state.
- Restore remains backward-compatible with older day records.
- Version 88 / 7.18.0.

# v7.13 – Long Completion Alert

- Completion alarm now lasts about 10 seconds instead of 3 seconds.
- Vibration repeats for the same alert window and is then cancelled explicitly.
- TimerService remains the single owner of completion sound/vibration.
- No Android SDK/device build was performed in this environment.

# v7.12 – Timer lifecycle synchronization

- Resynchronizes timer state from SharedPreferences whenever the app window regains focus or the custom view is attached.
- Removes pending UI timer callbacks before resynchronizing, preventing duplicate local tick loops after returning to the app.
- Removes UI callbacks when the view detaches; the foreground TimerService remains the background authority.
- If the app opens after a persisted running timer has already reached zero, it no longer clears that authoritative state locally; TimerService is started so it can finalize the timer and issue the single alert.
- versionCode 82 / versionName 7.12.0.

# v7.11 — Timer single-owner cleanup

- Removed the obsolete UI-side alarm/vibration implementation.
- TimerService remains the only component responsible for end-of-timer sound/vibration.
- Keeps timer completion authority and alert behavior in one place, reducing future duplicate/race regressions.
- Version: 7.11.0 (81).

# v7.10 – Timer Authority & Cross-Component Sync

- TimerService is the authoritative owner of timer completion and alarm.
- UI no longer clears persisted running/end state before the service can fire the alert.
- UI synchronizes pause/resume/finish state from SharedPreferences, including notification actions.
- Service watcher now reposts only while active and checks completion every second.
- Structural validation only; Android SDK/device build test still required.

## v7.9 – Native Android timer dependencies
- Removed accidental AndroidX Core dependency from timer notification and notification permission code.
- TimerService now uses native Notification.Builder/Notification.Action APIs supported by minSdk 26.
- Notification permission request now uses native Activity/Context APIs.
- This closes a source-level build blocker because the project had no AndroidX dependency declared.
- versionCode 79 / versionName 7.9.0.
- Structural checks performed; Android SDK/device build still pending.

# v7.6 – Resume control in timer notification

- Added a notification Resume action wired to ACTION_RESUME.
- Notification action state now distinguishes running vs paused timer state.
- Stop remains available in both states.
- Structural source validation only; Android SDK/device runtime verification is still pending.

## v7.5 – Timer notification stop control
- Added a dedicated עצור action to the foreground timer notification.
- Stopping from the notification clears running/end/remaining/finished timer state, preventing stale resume state.
- Pause remains separate and preserves remaining time.

## v7.4 – Timer resume foundation
- Added explicit ACTION_RESUME to the foreground timer service.
- Resume rebuilds timerEndAt from the exact persisted timerMs remaining value.
- Invalid/zero remaining time refuses resume safely.
- Keeps timerFinished false when resuming.

## v7.3 – Timer single-alert ownership
- TimerService is now the single owner of end-of-timer sound/vibration.
- The foreground UI still updates timerFinished and the screen, but no longer fires a second alarm at the same expiry.
- Prevents duplicate sound/vibration when the app is open while the foreground service is also active.

## v7.2 – Timer notification pause action
- Added a Pause action directly to the foreground timer notification.
- Pausing preserves the exact remaining milliseconds in SharedPreferences and stops the foreground service cleanly.
- Opening the app afterward resumes from the preserved remaining time when the user starts the timer again.

# v7.1 – Timer permissions and Android foreground-service hardening

- Requests Android 13+ notification permission when needed.
- Declares FOREGROUND_SERVICE_SPECIAL_USE for the writing countdown service.
- Adds the required special-use foreground-service subtype property.
- Keeps the timer notification/service architecture from v7.0.
- Structural validation only; no Android SDK/device runtime test was available here.

# v6.8 – Goal Recalculation Integrity

- Goal recalculation now starts from the later of today or the configured goal start date.
- Preserve-pace mode uses the same workday engine as preserve-due-date mode.
- Future-start goals no longer calculate a new due date from today.
- Completed goals no longer run an unnecessary date-extension loop.
- versionCode 68 / versionName 6.8.0.

## v6.6 – בטיחות שיוכים בייבוא ושחזור
- שיוכי הגהות ומחברת להזמנות נבדקים מול מספר ההזמנות הקיים.
- אינדקס שיוך לא תקין הופך אוטומטית ל״ללא שיוך״ במקום להצביע להזמנה שגויה.
- הבדיקה חלה בטעינת נתונים שמורים וגם לאחר ייבוא חיצוני, כאשר מסלול הייבוא הקיים מגיע לשלב הסנכרון.
- versionCode 66 / versionName 6.6.0.

## v6.4 – Editable Goal Start Date
- Goal start date is now editable directly from the goal card.
- Right half of the goal card edits start date; left half edits due date.
- Start date cannot be later than due date.
- Changing start date immediately recalculates scoped progress and required daily pace.
- Goal progress remains based only on writing from the selected start date onward.

# v6.3 – Goal Start Date & Scoped Progress

- Added a persistent start date for the active long-term goal.
- Goal progress is now calculated only from writing history on/after that goal start date, instead of all historical writing.
- Current live-day writing is included when it falls inside the goal period.
- Goal screen shows both start date and due date.
- Goal start date is included in local backup/restore and external export/import, with backward compatibility for older exports.
- Version 6.3.0.

# v5.6 – Order Targets & Actual Output

Adds per-order target and actual-output fields, derives progress from them, persists them, and includes them in local backup and text export/import. Existing visual language is intentionally preserved.

# v5.5 – Monthly Reports & Weekly Range Consistency

- Weekly planner range now matches the actual Sunday–Thursday workweek.
- Statistics screen now derives current-month writing totals, closed writing days and cycles from the persisted historical ledger.
- Existing approved visual structure is preserved; this stage focuses on data consistency.

# v4.9 – חופשות ולוח יהודי מורחב

- טווח חופשה אישי עם תאריך התחלה/סיום והפעלה/כיבוי.
- חופשה פעילה מוחרגת מתכנון שבועי ומחישובי יעדים.
- תוויות נוספות בלוח: חול המועד, חנוכה, פורים וצומות מרכזיים.
- חופשה נשמרת בגיבוי המקומי ובייצוא/ייבוא.
- ימי העבודה הקבועים נשארים א׳–ה׳; שבת ויום טוב נשארים אי־עבודה.

# v4.8 – Workday Engine Integration

- Centralized writing-workday rule: Friday, Shabbat and major Yom Tov are non-writing days.
- Weekly planner now uses the same rule, marks non-writing days and excludes their cycles from weekly totals.
- Weekly rows now show the Hebrew date.
- Goal pace/date recalculation now uses the same non-writing-day engine instead of counting every Sunday–Thursday blindly.
- Tapping a non-writing day in the weekly planner does not open editing.

Current limitation: holiday coverage is still intentionally limited to the major Yom Tov set already implemented; Chol HaMoed, fasts, Chanukah/Purim and personal vacations are not yet treated as non-writing days.

# v4.1 – פירוט הוצאות חודשי אמיתי

בגרסה זו מסך הכספים עבר ממספר הוצאות כולל לארבעה סעיפי הוצאה נפרדים וניתנים לעריכה. כל סעיף כולל שם וסכום, הסכום החודשי מחושב אוטומטית, ונוספו צפי כולל מכל ההזמנות ויתרה לגבייה. סעיפי ההוצאה נשמרים ב-SharedPreferences ונכללים בגיבוי המקומי ובייצוא/ייבוא.

# v4.0 – Finance stability and real expense editing

- Fixed a compile-level finance bug: the finance screen now calculates total paid across all active orders inside its own scope.
- Monthly balance now uses total payments across orders minus monthly expenses.
- Replaced the prototype “add ₪50” behavior with a real numeric Android dialog for monthly expected expenses.
- Expense value persists through the existing state/backup/export flow.
- Android metadata: versionCode 40 / versionName 4.0.0.
- ZIP/source checks performed here; APK/device rendering is still not claimed.

# יומן הסופר – מהדורת זהב v0.6

פרויקט Android חדש ונפרד לחלוטין.

בגרסה זו:
- 12 מסכי הממשק נשארים בפרויקט.
- טיימר עם שמירה, צליל ורטט.
- עדכון הספק מקומי.
- הגדרות סדר יום נשמרות: התחלה, מספר מחזורים, משך מחזור, הפסקה רגילה וארוכה.
- שעת הסיום מחושבת אוטומטית לפי ההגדרות.
- מתג ללו״ז אדפטיבי נשמר.
- Package עצמאי: `il.yomanhasofer.goldnew`.

הערה: הקובץ הוא קוד מקור. בסביבה הנוכחית לא קיים Android SDK/Gradle מקומי ולכן לא נטען כאן APK ולא נטען שה-build נבדק.

## v0.7
- Adaptive daily schedule now calculates every cycle from the actual start time.
- Starting writing records today’s actual start and shifts all later cycles/breaks.
- Long break remains after cycle 4.
- Today’s actual start can be reset in schedule settings.

## v0.8
- Each of the six writing cycles now has its own persistent actual-output value.
- Tapping a cycle in “היום שלי” opens the actual-output editor for that cycle.
- Saved cycles are marked complete and display their line count.
- Timer header/time are linked to the selected cycle and adaptive schedule.
- Daily summary now calculates completed cycles and total lines from saved cycle data.

## v0.9
- Daily progress is now calculated from saved cycle output.
- Start writing opens the next unfinished cycle.
- End-of-day action closes the day and stops the timer.
- Daily target is persisted locally.

## v1.0 Orders
- Persistent primary order progress, due date and payment state.
- Order detail reflects saved values and can update progress/payment locally.

## v1.1 – Finance + live statistics
- Statistics screen now derives lines, completed cycles, writing time, pace, order progress and current profitability from locally saved data.
- Added a functional Finance screen linked from "עוד" with revenue, expenses, balance, outstanding order payment and a simple persisted expense update.
- Financial values are persisted locally in SharedPreferences.

## v1.4 — visual fidelity pass 1
- Reduced header and bottom navigation proportions for a Galaxy S23 Ultra-like portrait viewport.
- Reworked header toward the approved navy/cream/antique-gold reference: restrained gold, finer rules, less oversized typography.
- Reworked cards with tighter radius and thinner antique-gold borders.
- Reworked persistent bottom navigation with icons, a thin gold top rule, and no bubble/pill selection control.
- This is the first visual-fidelity pass; it is not yet claimed as a pixel-perfect match until device screenshots can be compared to the approved reference.

## v1.5 – Visual fidelity pass 2
- Refined navy/cream/antique-gold palette to remove yellow/glossy appearance.
- Added restrained card depth and thinner antique-gold borders.
- Reduced heading/subheading scale and introduced a fine divider for a denser S23 Ultra layout.
- Simplified bottom navigation spacing, icon scale and selected-state treatment.
- This remains an implementation pass; pixel-perfect parity is not claimed until device screenshots are compared with the approved reference.

## v1.6 – Robust timer
- Running timer now persists an absolute end timestamp and restores remaining time after app/view recreation.
- Pause stores the real remaining duration; resume creates a new end timestamp.
- Finishing/resetting a day clears timer state safely.
- The "next cycle" time on the timer screen is now calculated from the adaptive schedule instead of a hard-coded sample.

## v1.7 — Daily reset & schedule consistency
- The app now stores the active work date and automatically resets day-only state on a new calendar day.
- Late-start time, cycle completion, daily lines, timer state and finished-day state reset for the new day while persistent settings/orders remain.
- The agreed schedule is fixed to six cycles; the old unsafe 6/7 toggle was removed.
- Timer screen now correctly says when cycle 6 is the final cycle instead of repeating cycle 6 as the “next” cycle.

## v1.8
- Timer phases: writing, regular break, long break after cycle 4.
- Timer completion now shows a confirmation state and does not auto-start the next phase.
- 20-minute regular breaks and 60-minute long break are derived from settings.
- Alarm/vibration retained at phase completion.


## v1.9 – Multiple orders
- Three orders now persist independently (name, due date, progress, price, paid).
- Tapping a specific order opens that exact order.
- Progress/payment updates are saved back to the selected order only.
- Finance statistics aggregate payments across all persisted orders.

## v2.0
- Goals now expose the two agreed recalculation modes: preserve due date/increase pace, or preserve pace/extend date.
- Goal recalculation mode is persisted locally.

## v2.1 – Full local snapshot
- Local backup now captures the full working state: all 3 orders, daily cycles/output, schedule settings, goals, finance summary, notebook/proofreading counters and active order.
- Restore returns that full snapshot and safely stops any live timer before resuming work.
- Backup remains local inside the app; file export/import is not implemented yet.

## v2.2 – External backup export
- Added an external backup export action on the Backup & Restore screen.
- Export serializes the current working state to a readable UTF-8 text backup and opens Android's share/save chooser.
- The existing in-app snapshot backup/restore remains unchanged.
- Import from an external file is not implemented yet; this version is export-only.

## v2.3 – External backup import
- Added Android file picker for importing a previously exported backup text file.
- Validates the backup header before applying data.
- Restores schedule, daily cycles, three orders, finance, notebook/proofreading, goals, and active order.
- Stops any stale timer state after import and reinitializes the work timer safely.
- Added missing Java imports required by the v2.2 export code (Intent, file I/O, UTF-8), preventing source-level compile errors from those unresolved classes.

## v2.4 – Bottom navigation fidelity
- Replaced Unicode placeholder symbols in the persistent bottom navigation with Canvas-drawn icons.
- Added dedicated calendar, timer/day, order/document, statistics, and more icons.
- Kept the restrained antique-gold selected state and navy/cream design language.
- This is a visual-fidelity improvement; exact pixel matching still requires device rendering/comparison.


## v2.5 – S23 Ultra layout & daily consistency
- Daily reset is re-checked whenever the app regains focus or the custom view is attached, so leaving the app open across midnight no longer leaves yesterday's work state.
- Bottom navigation touch area now uses the exact same capped footer height as the drawn navigation bar, reducing accidental taps on tall screens such as Galaxy S23 Ultra.
- Six work cycles are now presented as fixed in Settings, matching the agreed workflow instead of appearing editable.
- Settings subtitle clarifies that the six-cycle structure is fixed while timing remains configurable.


## v2.6 – S23 Ultra touch geometry
- Unified header, bottom navigation and content geometry through shared helpers.
- Removed obsolete 16%-of-screen touch origins that no longer matched the drawn 13.5% header.
- Daily start, cycle rows, order detail, summary, More tools, settings, finance, goals and backup touch targets now use the same content origin as rendering.
- Bottom navigation hit area now uses the exact rendered navigation height.
- This reduces vertical tap drift on tall devices such as Galaxy S23 Ultra.


## v2.7 – Timer Geometry & Dynamic Break Labels
- Timer primary button hit area now derives from the exact Canvas geometry used to draw it, rather than screen-height percentages.
- Break duration labels now use the configured normal/long break values instead of hardcoded 20/60 minute text.
- Keeps six-cycle flow and S23 Ultra-oriented layout consistency.

## v2.8 – Calendar interaction
- The “today” summary card on the calendar is now an actual shortcut to “היום שלי”.
- Its hit area is derived from the exact calendar drawing geometry, preserving S23 Ultra alignment.


## v2.9 — Daily data consistency
- Calendar Today card now uses the active order, real daily line target, and actual saved daily progress.
- Today screen uses the active order and line target instead of prototype placeholder text.
- End-of-day writing duration uses a duration formatter rather than a clock-of-day formatter.
- Android version metadata updated to versionCode 29 / versionName 2.9.0.


## v3.0 — interaction consistency
- Order cards now use their exact drawn geometry for selection on tall S23 Ultra screens.
- Taps in the spacing between order cards no longer open an order accidentally.
- Fixed settings touch priority so the adaptive-schedule and reset-actual-start controls can actually be reached.
- Android version metadata updated to 3.0.0.

## v3.1 – Visual fidelity pass
- Refined the navy/gold header with slimmer symmetric antique-gold ornamentation.
- Reduced title/subtitle scale and tightened spacing for a more refined S23 Ultra composition.
- Refined cards with narrower margins, softer shadows, thinner borders and slightly smaller corner radius.
- Tightened bottom navigation icon/label positioning and selected indicator.
- Increased separation between the fixed header and screen content.
- Visual source tuning only; exact pixel matching still requires rendering on the target device and comparing with the approved reference.


## v3.2 – Timer visual fidelity
- Refined the timer face with a slimmer muted-antique-gold progress ring and subtle inner border.
- Reduced timer typography and ring scale to better fit the tall Galaxy S23 Ultra composition.
- Removed the oversized/bubble-like feel from the primary timer control by tightening its radius and height.
- Kept timer touch geometry aligned with the newly drawn control position.
- Android version metadata updated to 3.2.0.
- Source-level visual pass only; device rendering is still required before claiming pixel-perfect fidelity.


## v3.3 – Daily screen visual fidelity
- Refined “היום שלי” hierarchy and typography for a calmer premium layout.
- Reduced button/card roundness and tightened vertical rhythm for Galaxy S23 Ultra proportions.
- Made cycle rows slimmer and more restrained, with subtle antique-gold separators.
- Preserved the approved navy/cream/antique-gold visual language.


## v3.4 – Dynamic calendar foundation
- Replaced the hard-coded October/November sample grid with the device current Gregorian month.
- Added previous/next month navigation and month/year title updates.
- Added real today highlighting and selectable calendar days.
- The lower calendar summary reflects the selected date while keeping the active work order and live daily progress.
- Refined calendar density for the S23 Ultra viewport.
- Hebrew-calendar conversion, Jewish holidays and order-to-date scheduling are still pending.

## v3.5 – Orders foundation + visual consistency
- Refined the Orders screen to match the slimmer approved visual language: tighter cards, smaller radius, restrained navy action button and antique-gold accents.
- The “new order” button now creates a real persisted order slot and opens its detail screen instead of being a visual placeholder.
- Expanded persisted order capacity from 3 fixed records to up to 8 records, including backup/export/import support and finance totals.
- Existing order cards use the updated rendered geometry for touch handling.
- Full text-field editing and delete/reorder are intentionally not marked complete yet; those remain for the dedicated CRUD pass.

## v3.6 – Order management completion pass
- Added a dedicated edit action to the order-detail screen while preserving the approved restrained navy/cream/antique-gold visual language.
- Added persisted quick editing for delivery status/date placeholder, price and paid amount.
- Added order deletion with safe compaction of the saved order slots and active-order selection.
- Split progress, edit and delete into distinct hit targets so actions do not overlap.
- This is still an intermediate order-management pass: full keyboard text entry and date picker remain to be implemented before orders are considered complete.


## v3.7 – Real order editing
- Added real Android keyboard-based editing for order name, price and paid amount.
- Added a real Android date picker for the delivery date by tapping the date row.
- Removed the prototype edit-cycle behavior that changed values by canned increments.
- Kept progress as a separate explicit action and preserved the approved restrained navy/cream/antique-gold screen design.
- Order deletion and persistence remain connected to the expanded order storage.
- ZIP/source validation only; APK/device build still requires an Android SDK environment.

## v3.8 – Real goal recalculation foundation
- Replaced the old fake goal recalculation that simply added 500 lines or one year.
- Option A now preserves the configured time horizon and calculates the required writing pace from remaining lines.
- Option B preserves the current writing pace and estimates the required horizon, capped at 20 years.
- Calculations use the agreed Sunday–Thursday work pattern (about 260 workdays/year).
- Required daily pace is persisted and included in local backup/export/import.
- Goal screen copy and primary action were refined without changing the approved navy/cream/antique-gold visual language.
- Exact due-date calendar math is still a later step; this version uses the configured year horizon rather than a specific Hebrew due date.

## v3.9.0 – Exact goal due date
- Goal planning now stores an exact due date, editable with Android DatePicker.
- Preserve-date recalculation uses the actual remaining Sunday–Thursday workdays until that date.
- Preserve-pace recalculation computes a new exact due date by advancing through Sunday–Thursday workdays.
- Exact goal date is included in local backup, restore, export and import.


## v4.2.0 — Proofreading & corrections ledger
- Replaced prototype counters with up to 8 persisted proofreading/correction records.
- Add a real named proofreading item using Android text input.
- Tap an item to rename it, toggle open/completed status, or delete it.
- Open/completed totals are derived from the actual records.
- Full local backup and text export/import include proofreading names and statuses.
- Visual treatment remains restrained navy/cream/antique-gold and follows the existing approved screen geometry.
- Android SDK/device build and S23 Ultra visual comparison are still pending.

## v4.3.0 — Real Scribe Notebook
- Replaced the notebook's canned counter behavior with persisted note records.
- Add a note with real keyboard text input.
- Tap a note to edit its text or delete it.
- Notes are included in local backup/restore and text export/import.
- Notebook UI remains within the approved restrained navy/cream/antique-gold visual language.
- Current cap is 8 notes; scrolling/unlimited storage is still future work.


## v4.4 – Real Weekly Planner
- Weekly planner now uses the actual current Sunday–Saturday week range instead of a fixed November 2026 caption.
- Sunday through Friday rows show live calendar day numbers.
- Each day is editable with real keyboard input for the planned work and a 0–6 cycle target.
- Weekly plan persists locally and is included in the internal full backup/restore.
- Saturday remains outside the editable work rows, consistent with the established work-week rules.
- Visual language remains navy/cream/antique-gold; no large bubble controls were added.


## v4.5 — Work-week consistency
- Weekly planner now follows the agreed work week: Sunday through Thursday only.
- Friday is no longer presented as a planned work day.
- Added a weekly total of planned writing cycles.
- Weekly plans and cycle counts are now included in external text export/import as well as local backup.
- Existing six-slot storage is retained internally for backward compatibility, but only five work days are used by the planner UI.


## v4.6 – Orders ↔ Calendar
- Exact order due dates are now persisted as timestamps.
- Calendar markers are generated from real order due dates instead of hard-coded sample days.
- Marker colors follow order type (tefillin / mezuzah / megillah / Sefer Torah).
- Selecting a date shows an order due on that date when one exists.
- Due timestamps participate in local backup and external export/import.


## v4.7 — Hebrew calendar foundation
- Calendar now shows Hebrew month span/year as the primary month heading, with Gregorian month secondary.
- Every Gregorian day cell also shows its Hebrew day.
- Selected-day card shows Hebrew and Gregorian dates together.
- Friday, Shabbat, and major Yom Tov dates are visually marked as non-work days.
- Offline Gregorian→Hebrew conversion implemented locally; no network is required at runtime.
- Major Yom Tov foundation currently covers Rosh Hashanah, Yom Kippur, first day Sukkot, Shemini Atzeret (Israel), first/last Pesach, and Shavuot. Chol Hamoed, fasts, Chanukah/Purim labels, vacations, and user-configurable non-work rules remain for a later pass.


## v5.0 – Order model & safety
- Added explicit order type and customer fields instead of inferring type only from the order title.
- Calendar marker colors now use the persisted order type.
- Order editing includes customer and type, with the four agreed categories.
- Type/customer are included in local save, full backup, export and import.
- Order deletion now requires confirmation.
- New orders receive safe defaults and deleted orders shift all associated fields together.
- Existing visual language is preserved; this is a data-integrity/functionality stage, not a claim of final pixel-perfect rendering.


## v5.1 – Consistency & Proofreading completion
- Fixed full-backup restore so activeOrder is clamped against the restored orderCount (up to 8), not the old 3-order prototype limit.
- Proofreading screen now exposes all persisted records (up to 8) instead of hiding records 4–8.
- Touch geometry now matches the compact proofreading rows and add button.
- Existing persistence/export/import behavior is preserved.


## v5.2 – Historical Writing Ledger
- Added a persisted rolling history of up to 60 closed writing days.
- Closing a day records date, lines, completed cycles and writing minutes exactly once (re-closing updates rather than duplicates).
- Statistics now show cumulative written lines and number of closed days.
- Long-term goal progress/recalculation now uses cumulative history rather than only the current day's lines.
- History is included in local backup/restore and external text export/import.
- Existing visual geometry/palette was intentionally preserved in this functional stage.


## v5.3 – Historical Statistics
- Data screen now derives cumulative totals, daily average, per-cycle pace, total historical cycles, and best writing day from the persisted writing ledger.
- Removed the old broad statistics-screen touch shortcut that could unexpectedly open the daily summary.
- Existing approved navy/cream/antique-gold geometry is preserved; this is a functional statistics pass, not a claim of final pixel-perfect device verification.


## v5.4 Finance Ledger
- Expense rows now persist paid/unpaid and recurring flags.
- Finance view distinguishes actual cash balance from projected balance.
- Recurring monthly expense total is shown.
- Expense edit dialog includes paid and recurring controls.
- Local backup and text export/import include the new finance flags.
- Existing visual geometry was preserved; no claim of device pixel-match verification.


## v5.7 – Order lifecycle and profit
- Added a start date per order, persisted independently from delivery date.
- Added expected profit per order.
- Replaced free-text order type entry with an explicit selector: Torah scroll / tefillin / mezuzot / megillah.
- Order detail now shows start→delivery, target/actual progress, balance, and expected profit.
- Backup/export/import include the new order fields.
- External import now clamps active order against the final imported order count.

## v5.8 – Proofreading linked to orders
- Proofreading/correction records can now be linked to a specific order.
- Each proofreading record stores creation/update date metadata and an optional note.
- Editing a proofreading record can change its order association and note.
- Deleting a proofreading record now asks for confirmation.
- Proofreading metadata is included in local backup, restore, export and import.
- Fixed external finance export so paid/recurring expense flags are actually exported (the importer already supported them).


## v5.9 – מחברת הסופר מחוברת להזמנות
- כל 8 ההערות נגישות במסך המחברת, במקום 5 בלבד.
- כל הערה יכולה להיות משויכת להזמנה מסוימת או ללא שיוך.
- נשמר תאריך יצירת/עדכון הערה.
- מחיקת הערה דורשת אישור.
- שיוכי הערות מתעדכנים כאשר הזמנה נמחקת.
- נתוני המחברת החדשים נשמרים ב-SharedPreferences, בגיבוי המקומי ובייצוא/ייבוא החיצוני.


## v6.0 – Order-link integrity
- Notebook order links are now repaired when an order is deleted.
- Notes linked to the deleted order become unlinked instead of pointing to another order.
- Notes linked to later orders shift their index together with the order list.
- This mirrors the existing proofreading-link repair and closes the known v5.9 consistency gap.


## v6.1 – Safe daily rollover
- When the calendar date changes, an unfinished previous day with meaningful activity is written to history before daily counters reset.
- Meaningful activity includes written lines, completed cycles, or an explicitly started workday.
- Existing same-date history remains de-duplicated by recordDayHistory().
- Prevents midnight/app-reopen rollover from silently losing the previous day's statistics.


## v6.2 – Long-term writing history
- Expanded writing history capacity from 60 to 2,048 closed workdays.
- Existing history entries remain compatible.
- Local backup/restore and external text export/import use the expanded history capacity.
- History persistence now writes only populated history entries instead of thousands of empty records.
- This is a storage/correctness step; it does not claim final S23 Ultra visual verification.


## v6.5 – Goal date integrity
- Due date can no longer be set before the goal start date.
- Changing the due date recalculates the required daily pace immediately.
- Remaining work-day calculation respects the later of today or the goal start date.
- Goal screen clarifies which half of the goal card edits start vs due date.


## v6.7 – Import link normalization
- External backup import now normalizes notebook and proofreading order links only after the imported orderCount is fully known.
- Invalid imported association indexes become unlinked (-1), preventing stale references from silently targeting another order.
- Active order is clamped after import before syncing the active-order summary.


## v6.9 – 20-year history capacity
- History capacity raised from 2,048 to 6,000 closed workdays.
- At roughly 260 workdays/year this covers more than 20 years of work history.
- Startup now reads only the populated history rows (`historyCount`) rather than scanning the full capacity.
- Existing history remains compatible with the previous preference keys and backup/export format.


## v7.0 – Background Timer Foundation
- Added a foreground TimerService so an active writing/break timer can keep being monitored while the app is not on screen.
- Added a persistent timer notification with remaining time and phase.
- Timer service reads the same persisted end timestamp used by the UI and marks the timer finished when the deadline is reached.
- Added foreground-service and notification permissions to the manifest.
- Pause/day-finish/day-reset paths stop the foreground timer service.
- This is a source-level implementation only; Android SDK compilation and real-device behavior still require verification.


## v7.7 Timer notification efficiency
- Foreground timer notification refresh reduced from every second to every 5 seconds to lower unnecessary notification/battery churn.
- Notification time rendering now uses saved timerMs when paused and end timestamp when running.
- Version 7.7.0 (77).


## v7.8 – Safe service shutdown
- UI-side timer shutdown now calls Android stopService() directly instead of starting the service with a STOP action.
- Notification STOP action remains handled inside TimerService because it originates from the notification itself.
- Reduces background-service start restrictions when pausing/resetting from the app.


## v7.14 – Six-cycle break sequence hardening
- Fixed schedule rule remains six writing cycles.
- Normal break uses the configured 20-minute default.
- Only the break after cycle 4 uses the configured 60-minute long-break default.
- Transition helper keeps timer UI messaging and phase selection on the same cycle-index rule.
- This is source/structure validation only; no Android SDK build or physical S23 Ultra test was performed here.


## v7.15 – Cycle Output Before Break
- After every completed writing timer, the app now routes to actual-output entry before offering the break.
- Saving cycles 1–5 prepares the correct regular/long break and returns to the timer screen.
- Saving cycle 6 returns to the day view without creating an extra break.
- This keeps the six-cycle ledger aligned with the timer sequence.


## v7.16 – End-of-day summary flow
- After saving output for cycle 6, the app now opens the daily summary screen directly.
- No break is created after cycle 6.
- The summary keeps the explicit “סיימתי לכתוב להיום” action so the user can review totals before closing the day.


## v7.17 – Safe Day Closure
- סגירת יום אפשרית רק לאחר שכל 6 המחזורים נשמרו.
- מחזור 6 מסמן את היום כמוכן לסגירה ורק אז כפתור הסיכום פעיל לוגית.
- מנגנון finishDay בודק שוב את התנאים כדי למנוע סגירה מוקדמת או רישום היסטוריה חלקי.
- לאחר סגירה הדגל מתאפס ונמנעת סגירה כפולה.


## v8.0 – Approved Design Core / S23 geometry
- Began the major approved-design fidelity stage against the exact 12-screen reference and the supplied Galaxy S23 Ultra proportion screenshot.
- Added a 412-wide logical phone artboard and width-based Canvas scaling so high-density S23 pixels no longer stretch/miniaturize the custom UI.
- Touch coordinates are transformed through the same scale, keeping hit targets aligned with the drawing.
- Rebuilt the shared masthead with deep navy, restrained antique-gold curved edge, gold-edition badge and thin botanical/quill details.
- Rebuilt shared cards with tighter cream surfaces, thinner antique-gold borders and softer shadows.
- Rebuilt bottom navigation geometry to the approved rounded navy bar treatment with gold active state.
- Added missing geometry/drawing helpers (W/H/headerH/bottomH/contentTop/line), eliminating a source-level blocker in the prior custom Canvas class.
- This is the first substantial design-core pass, not a claim of final pixel-perfect match. Final fidelity still requires APK rendering and comparison on the physical S23 Ultra.


## v8.2.0 – Approved Design System Pass
- Extended the approved navy/cream/antique-gold visual system across secondary screens through shared title, divider, card, and section-label geometry.
- Added consistent visual section hierarchy to More, Weekly Planner, Notebook, Proofreading, Vacations and Backup/Restore.
- Preserved existing workflow logic and touch handling while tightening the common S23-oriented design language.
- No pixel-perfect claim until an APK is rendered and compared on the Galaxy S23 Ultra.


## v8.3 – Approved Design Deep Pass
- Deep visual pass against the approved 12-screen reference.
- Data, finance and daily-settings screens rebuilt into the approved stacked luxury-card hierarchy.
- Added restrained antique-gold medallions and parchment/botanical footer treatment shared across secondary screens.
- Summary and goals now carry the same lower-page visual language.
- No claim of pixel-perfect device fidelity until an APK is rendered and compared on the Galaxy S23 Ultra.


## v8.5 – Navigation & Visual Integrity Pass
- Bottom navigation now uses the approved five labels exactly: לוח שנה | היום שלי | הזמנות | נתונים | עוד.
- Header hierarchy refined with the professional sofer-management subtitle while preserving restrained navy/cream/antique-gold styling.
- Removed a duplicate Hebrew-calendar method definition found during source audit; this was a source-level Java compile blocker.
- Preserved the existing S23 Ultra design coordinate scaling and touch geometry.
- Version 95 / 8.5.0.
- Structural validation only; final visual fidelity still requires APK render/device comparison.


## v8.6 - Approved Masthead Fidelity
- Active screen identity moved into the navy masthead to follow the approved 12-screen reference more closely.
- Added per-screen Hebrew masthead titles and concise subtitles across all app screens.
- Reduced duplicate hierarchy below the masthead with a quieter context line and antique-gold divider.
- Repositioned the restrained quill/book accent for the new masthead hierarchy.
- Existing touch geometry and functional screen flow are preserved.


## v8.7 – Masthead & Navigation Fidelity
- Removed the duplicated screen subtitle from the cream content area; screen identity now appears only in the navy masthead.
- Moved the back affordance for secondary screens into the masthead instead of the cream body.
- Refined the selected bottom-navigation state to a restrained antique-gold line instead of a large highlighted block.
- Preserved existing touch geometry and screen routing.


## v8.8 – Core Screen Composition Fidelity
- Refined Today screen composition with premium status pill, clearer progress hierarchy and six explicit cycle badges.
- Refined Orders cards with type/status pills, customer hierarchy, due date and restrained progress treatment.
- Timer continuation card now carries the active order and a quieter phase hierarchy.
- Added reusable date/cycle design primitives and content safe-area helpers for the S23-oriented artboard.
- Preserved the existing interaction geometry for the primary actions while changing visual composition.


## v8.9 – Core Interaction Geometry Fidelity
- Aligned the Today screen touch targets with the exact v8.8 visual composition.
- The six visible cycle rows now map to their matching cycle instead of using stale pre-redesign coordinates.
- Aligned Daily Schedule settings touch targets to the five visible 67px-spaced cards.
- Adaptive-start toggle now uses the same card geometry as the rendered control.
- Preserved the approved navy / cream / antique-gold visual language while hardening interaction fidelity.


## v9.0 – Orders Accessibility & Interaction Audit
- כל 8 ההזמנות נגישות כעת במסך ההזמנות באמצעות דפדוף של עד 4 כרטיסים בעמוד.
- אזורי הלחיצה של כרטיסי ההזמנה מחושבים לפי העמוד המוצג, כך שפתיחת הזמנה 5–8 פותחת את הרשומה הנכונה.
- נוספו חיווי עמוד וחיצי מעבר בעיצוב הזהב העתיק, בלי להעמיס על המסך.
- נשמרת מגבלת 8 ההזמנות והלוגיקה הקיימת של פרטי הזמנה, גיבוי וקישורים.

## v9.1.0 – Finance Interaction Integrity
- Replaced misleading finance navigation rows with the four real editable expense records.
- Each expense now shows its name, amount, paid/pending state and recurring state directly on the finance screen.
- Finance touch geometry now exactly follows the rendered 49px row rhythm and ignores the visual gaps between cards.
- Preserved the approved navy/cream/antique-gold visual language.


## v9.2 – Notebook & Proofreading Accessibility
- מחברת הסופר והגהות מחולקות לעמודים של עד 4 רשומות כדי שכל 8 הרשומות יהיו נגישות במסך הטלפון.
- נוספו חיצי דפדוף וחיווי עמוד בשפת הזהב העתיק.
- אזורי המגע ממופים לרשומה האמיתית בעמוד הפעיל.
- כפתור הוספת הגהה נשאר נגיש ואינו נדחק מחוץ למסך כאשר יש הרבה רשומות.


## v9.3 – Backup Interaction Integrity
- Aligned all four backup/restore/export/import touch targets exactly with their visible buttons.
- Removed overlapping legacy hit zones that could trigger the previous action near button boundaries.
- Restore now gives a clear message when no local backup exists.
- Version 103 / 9.3.0.


## v9.4 – Goal Editing Integrity
- The active long-term goal is now editable from the goal screen instead of being effectively fixed.
- Tapping the writing-units card opens a goal editor for target lines and daily pace.
- Values are validated as positive integers and persisted through the existing goal state/backup/export paths.
- The visible card now explicitly signals that it is interactive.


## v9.5 – Monthly Report Integrity
- The visible “דוח חודשי” card on the Data screen now opens a real monthly report instead of being a decorative dead end.
- Added a dedicated monthly report screen using closed-day history: lines, writing days, cycles, writing time, daily average, and per-cycle average.
- The report explicitly excludes an open current day until it is closed, matching the history model.
- Added correct back navigation from the report to Data.

## v9.6 – Structured Writing Place
- Added a dedicated writing-place field to Scribe Notebook records (parasha/page/line or any free-form location).
- Writing place is visible in the notebook list and editable independently from the note text.
- Writing-place data now participates in normal persistence, local backup/restore, and external export/import.
- Notebook deletion shifts/clears writing-place data together with the rest of the record.


## v9.7 – Weekly Planner Navigation Integrity
- Added previous/next week navigation to the weekly planner.
- Weekly date range, Hebrew dates, Shabbat/Yom Tov/vacation exclusions now follow the selected week.
- Added one-tap return to the current week.
- Corrected weekly touch geometry after the navigation row was added.
- Version 107 / 9.7.0.


## v9.8 – Hebrew Calendar Integrity
- Corrected Chanukah length for short/full Kislev years.
- Added shifted fast handling for 17 Tammuz and 9 Av when the fixed date is Shabbat.
- Added Tzom Gedaliah, Ta'anit Esther, Shushan Purim and Rosh Chodesh labels.
- Preserved existing Shabbat/Yom Tov/vacation work-day exclusion logic.


## v9.9 – Timer Process-Restart Safety
- Foreground timer service no longer treats a null START_STICKY restart intent as an unconditional timer start.
- On Android process/service recreation, the service now restores itself only when persisted timer state says a timer is actually running and has a valid future end time.
- If the persisted end time already passed during recreation, completion is committed and the long alarm/vibration is fired once through the service path.
- If there is no valid running timer, the restarted service exits with START_NOT_STICKY instead of creating a misleading foreground timer notification.


## v10.0 – Finance Expense Date Integrity
- Added a real date field to each monthly expense record.
- Expense dates are editable from the expense dialog and visible in the finance list.
- Expense dates persist in normal app state, local backup/restore, and text export/import.
- Existing v9.9 expense records remain compatible: records without a saved date simply show no date until one is chosen.


## v10.1 – Finance Month Integrity
- Monthly expense totals are now date-aware: dated expenses count only in their matching current month.
- Legacy/undated expense rows remain included so existing data is not silently lost.
- Expense rows outside the current month are visibly marked.
- Renamed the income metric to “תקבולים בהזמנות” because order payments do not yet carry payment dates; this avoids falsely presenting them as current-month income.
- Renamed net profit to “יתרה מול הוצאות החודש” for the same accounting-integrity reason.

## v10.2 – Payment Date Integrity
- Added a separate receipt/payment date for each order payment.
- Finance now reports current-month receipts only when a payment has a dated receipt in the current month.
- Order detail displays the receipt date next to paid amount.
- Payment date persists through normal save, backup/restore, and text export/import while remaining backward-compatible with older exports.


## v10.3 – Finance Month Navigation
- Finance screen can browse previous and next calendar months.
- Receipts, dated expenses and balance are calculated for the selected month.
- Legacy undated expense rows remain part of the current month only.


## v10.4 — Final launcher identity pass
- Added a dedicated standalone launcher icon for the Gold edition: deep navy field, restrained antique-gold Torah scroll and quill.
- Added adaptive-icon resources for modern Android launchers while retaining a vector fallback.
- Wired the application manifest to the new icon without changing the package or app data namespace.
- Version 114 / 10.4.0.


## v10.5 – Monthly Report Navigation
- Added previous/next month navigation to the writing monthly report.
- Monthly report totals now use the selected month instead of being locked to the current month.
- Added one-tap return to the current month and reset report month when entering from Data.
- Kept the Data dashboard itself scoped to the actual current month.


## v10.6 – Interaction Geometry Audit
- Audited navigation hit targets against the custom Canvas geometry.
- More-screen rows now respond only inside the visible 43px cards, not the 9px gaps.
- Weekly-planner rows now respond only inside the visible 51px cards, not the inter-card gaps.
- Bottom navigation now safely clamps taps at the extreme left/right screen edges into the correct one of five tabs.
- Android metadata: versionCode 116 / versionName 10.6.0.


## v10.7 – Multiple Vacation Ranges
- Vacation/non-work management expanded from one personal range to three independent ranges.
- Each range is edited as a start/end pair and becomes active when saved.
- All active personal ranges feed the same non-work-day calculation used by weekly planning and goal calculations.
- Preserves the original vacation range for backward compatibility and adds two additional persisted ranges.


## v10.8 – Vacation Backup Integrity
- Added vacation ranges 2–3 to full in-app backup and restore.
- Added vacation ranges 2–3 to text export/import while preserving compatibility with older backup files.
- Prevents newly added non-work ranges from disappearing after restore/import.


## v11.0 Build-readiness / Android 15 system-bar integrity
- Version 120 / 11.0.0.
- On Android 15+ (API 35), the activity explicitly opts the custom Canvas UI out of enforced edge-to-edge so the approved masthead and bottom navigation remain outside the system bars.
- Notification runtime permission ownership is centralized in MainActivity; the custom View no longer issues a second duplicate permission request during construction.
- Source-level integrity checks only; APK compilation/device verification is still pending.


## v11.1 – Recurring Finance Integrity
- הוצאה המסומנת כקבועה/חוזרת חלה בכל חודש מתאריך ההתחלה שלה ואילך.
- הוצאה חד-פעמית ממשיכה להיכלל רק בחודש של התאריך שלה.
- סיכום ההוצאות בחודש הנוכחי ובחודשים היסטוריים משתמש כעת באותו כלל עקבי.
- רשימת ההוצאות מציינת בבירור אם הוצאה קבועה חלה בחודש הנצפה.


## v11.2 – Dynamic Finance Expenses
- Expense records expanded from four fixed rows to up to eight records.
- Added finance expense pagination and an in-screen add-expense action.
- Expense count is persisted, backed up/restored, and exported/imported with backward compatibility.
- Monthly and recurring calculations now iterate only active expense records.


## v11.8 – Restore & Import Data Sanitization
- Full backup restore and text import now pass through one shared sanitization layer before becoming live app state.
- Invalid negative counts, money, writing output, dates and history values are clamped to safe ranges.
- Order progress is normalized to 0–100 and recalculated from target/actual when a target exists.
- Linked notebook/proofreading order indexes are normalized after order count validation.
- Six-cycle structure is reasserted after restore/import.


## v11.9 – Full Integration State Integrity
- Centralized post-restore/import reconciliation now validates schedule values and actual start time.
- Weekly plan cycle counts are normalized to the fixed six-cycle model.
- Notebook/proofreading text, dates, and order links are normalized together.
- Invalid or reversed vacation ranges are disabled instead of affecting work-day calculations.
- Day-closing state is reconciled with the real six-cycle completion state.
- History strings and counters are normalized before statistics use.


## v12.0 — Approved Design Fidelity / S23 Ultra Pass
- Rechecked the approved 12-screen reference and the Galaxy S23 Ultra proportion reference directly.
- Kept the 412-wide logical phone artboard, which maps the S23 Ultra view to the approved tall-phone proportions without stretching.
- Tightened the persistent bottom navigation from 70 to 64 logical pixels to match the approved reference and recover body space.
- Adjusted navigation icon/text vertical rhythm for the more compact bar.
- Changed the main “יומן הסופר” masthead wordmark to a restrained serif display face, closer to the approved traditional/luxury reference while keeping body UI text clean sans-serif.
- Added a subtle second antique-gold masthead edge rather than bright/glossy gold.
- Preserved navy / cream / muted antique-gold palette, curved masthead, thin borders, botanical strokes, and fixed five-tab RTL navigation.
- This is a source-level visual fidelity pass; it is not claimed as pixel-perfect until a compiled build is visually checked on the target device.


## v12.1 — Build Readiness / Android 15 Audit
- Bumped app version to 12.1.0 (versionCode 131).
- Explicitly compiles Java source/target at Java 17 to match AGP 8.7.3 and the GitHub build workflow.
- Kept compileSdk/targetSdk 35 and audited Android 13–15 notification/foreground-service declarations.
- TimerService is explicitly non-exported, marked to survive task removal (`stopWithTask=false`), and retains the declared `specialUse` foreground-service subtype/property.
- Disabled cleartext network traffic; the app is designed for local/offline operation.
- No storage permission is required for backup import because the app uses Android's Storage Access Framework.
- Source/package/resource/manifest references were statically checked.
- This stage is build-readiness validation only; an Android SDK compile/device run is still required before claiming APK verification.


## v12.2 — APK Build Attempt & CI Verification
- Performed an actual local build-environment check: Java is available, but this execution environment has no Android SDK and no Gradle executable, so a local APK cannot honestly be produced here.
- Strengthened the GitHub Actions build path with explicit Java/Gradle/Android-35 toolchain verification before compilation.
- Added an explicit non-empty APK output verification step after `assembleDebug`.
- The workflow uploads the APK only after the build and output verification succeed.
- Version: 132 / 12.2.0.


## v12.3 — Release Candidate Build Gate
- CI now runs Android lint before assembling the debug APK.
- The produced APK is verified to be non-empty and to carry the exact standalone package `il.yomanhasofer.goldnew` and versionCode 133.
- CI emits a SHA-256 checksum alongside the APK and uploads the lint report for final review.
- Local source preflight found no Java syntax-form diagnostics; full Android compilation still requires the Android SDK/Gradle toolchain.


## v12.4.0 — Final build handoff
- Release-candidate source bumped to versionCode 134 / versionName 12.4.0.
- CI now performs a source-input preflight before Android lint/build.
- APK identity gate updated to versionCode 134.
- Local execution environment was rechecked: Java is available, but no local Gradle executable, Android SDK, or Gradle wrapper is present, so an APK cannot be honestly produced in this environment.
- The GitHub Actions workflow remains the authoritative build path and will publish the APK only after lint, assemble, package identity, version, and SHA-256 checks pass.


## v12.5 – Final CI Compile Gate
- Version 135 / 12.5.0.
- CI now compiles Java sources explicitly before lint/APK assembly, so source compilation errors are surfaced separately and immediately.
- APK identity gate updated to versionCode 135.
- This remains a source/CI handoff until a real GitHub Actions or Android Studio build completes.


## v12.6 – Self-contained CI Android toolchain
- CI now explicitly installs/validates Android 35 platform and Build Tools 35.0.0 via sdkmanager before compilation.
- Added an explicit merged-manifest processing gate before lint/APK assembly.
- APK identity gate updated to versionCode 136 / versionName 12.6.0.
- This is a build-pipeline hardening change; an APK is only considered built after GitHub Actions completes successfully.
